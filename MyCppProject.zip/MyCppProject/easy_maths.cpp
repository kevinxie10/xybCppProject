#include <bits/stdc++.h>
#include <cstdlib>
#include <unistd.h>
using namespace std;
int t=60,tm,x,y;
int ans;
//long long lans;
float fans,inans;
char c;
int main(){
    srand(time(0));
    while(true){
    while(t--){
        tm=1;
        x=rand()%1000;y=rand()%1000;
        c=rand()%3;
        switch(c){
            case 0:ans=x+y;printf("%d+%d=?",x,y);break;
            case 1:ans=x-y;printf("%d-%d=?",x,y);break;
            case 2:x%=100,y%=100;ans=x*y;printf("%d*%d=?",x,y);break;
            //case 3:x%=100000;y%=5000;fans=(float)(x)/(float)(y);printf("%d/%d=",x,y);break;
        }
        printf("\n\n您输入的答案可以与原答案有0.01的差距。\n\n请输入一个实数！请不要输入分数！\n\n");
        cin>>inans;
        if(c!=3){
            if(abs(inans-ans)<0.01)printf("\n\n您的答案正确！恭喜！");
            else{printf("\n\n您的答案错误！正确答案为%d",ans);tm=4;}
        }
        else{
            if(abs(inans-ans)<0.00001)printf("\n\n您的答案正确！恭喜！");
            else{printf("\n\n您的答案错误！正确答案为%.12f",fans);tm=4;}
        }
        if(tm==4)t=60;
        printf("\n\n接下来开始下一题！！！\n\n");
        sleep(tm);
        system("clear");
        printf("\n\n接下来还剩%d道题！！！\n\n",t);
    }
    printf("恭喜您完成全部题目！！！");
    }
    return 0;
}