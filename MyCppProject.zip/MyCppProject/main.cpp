#include <cstdio>
#define lc p<<1
#define rc p<<1|1
const int N=100010;
typedef long long ll;
struct Node{
    ll l,r,sum,mul,add;
}tr[N<<2];
ll n,q,mod,a[N],op,x,y,k;
void calc(Node &t,ll m,ll a){
    t.sum=(t.sum*m+(t.r-t.l+1)*a)%mod;
    t.mul=t.mul*m%mod;
    t.add=(t.add*m+a)%mod;
}
void pushup(ll p){
    tr[p].sum=(tr[lc].sum+tr[rc].sum)%mod;
}
void pushdown(ll p){
    calc(tr[lc],tr[p].mul,tr[p].add);
    calc(tr[rc],tr[p].mul,tr[p].add);
    tr[p].add=0;
    tr[p].mul=1;
}
void build(ll p,ll l,ll r){
    tr[p]={l,r,a[r],1,0};
    if(l==r)return ;
    ll mid=(l+r)>>1;
    build(lc,l,mid);
    build(rc,mid+1,r);
    pushup(p);
}
void query(ll p,ll l, ll r){
    
}
int main(){
    scanf("%lld%lld%lld",&n,&q,&mod);
    for(int i=1;i<=n;i++)scanf("%lld",a+i);
    build(1,1,n);
    while(q--){
        scanf("%lld%lld%lld",&op,&x,&y);
        switch(op){
            case 1:scanf("%lld",&k);break;
            case 2:scanf("%lld",&k);break;
            case 3:break;
        }
    }
    return 0;
}
