#include "maze_map.h"
#include <cstdio>
#include <cstdlib>
#include <math.h>
#include <unistd.h>
inline char readchar(void){
    c=getchar();
    while(c!=-1){
        if(c=='#'||c=='.'||c=='@'||c=='&')return c;
        c=getchar();
    }
    return -1;
}
inline void _print_(int xx,int yy){
    usleep(tm*1e6);
	system("clear");
	for(int i=1;i<=xx;i++){
		for(int j=1;j<=yy;j++)
            printf("%c",mp[t][i][j]);
		printf("\n");
	}
}
inline void dfs(int n,int m,int ex,int ey){
    _print_(sizex[t],sizex[t]);//输出目前迷宫
    if(mp[t][n][m]=='&'){//判断终点
        mp[t][n][m]='$';_print_(sizex[t],sizey[t]);
        if(n==ex&&m==ey){printf("\n\n\n已到达终点！\n\n");exit(0);}
        else{printf("\n\n\n您输入的迷宫有多个终点！\n\n");exit(0);}
    }
    if(mp[t][n][m]=='*'){//后退
        if(ROAD(mp[t][n-1][m])){dfs(n-1,m,ex,ey);}
        if(ROAD(mp[t][n+1][m])){dfs(n+1,m,ex,ey);}
        if(ROAD(mp[t][n][m-1])){dfs(n,m-1,ex,ey);}
        if(ROAD(mp[t][n][m+1])){dfs(n,m+1,ex,ey);}
        if(WALKED(mp[t][n-1][m])){mp[t][n][m]='-';dfs(n-1,m,ex,ey);}
        if(WALKED(mp[t][n+1][m])){mp[t][n][m]='-';dfs(n+1,m,ex,ey);}
        if(WALKED(mp[t][n][m-1])){mp[t][n][m]='-';dfs(n,m-1,ex,ey);}
        if(WALKED(mp[t][n][m+1])){mp[t][n][m]='-';dfs(n,m+1,ex,ey);}
    }
    mp[t][n][m]='*';
    if(WALL(mp[t][n-1][m])&&WALL(mp[t][n+1][m])&&WALL(mp[t][n][m-1])&&WALL(mp[t][n][m+1])){printf("\n\n迷宫无法到达终点!");exit(0);}//四面都是墙
    if((WALL(mp[t][n-1][m])&&WALL(mp[t][n+1][m])&&WALL(mp[t][n][m-1]))&&(mp[t][n][m]=='*')){mp[t][n][m]='-';dfs(n,m+1,ex,ey);}//退
    if((WALL(mp[t][n-1][m])&&WALL(mp[t][n+1][m])&&WALL(mp[t][n][m+1]))&&(mp[t][n][m]=='*')){mp[t][n][m]='-';dfs(n,m-1,ex,ey);}//退
    if((WALL(mp[t][n][m-1])&&WALL(mp[t][n][m+1])&&WALL(mp[t][n-1][m]))&&(mp[t][n][m]=='*')){mp[t][n][m]='-';dfs(n+1,m,ex,ey);}//退
    if((WALL(mp[t][n][m-1])&&WALL(mp[t][n][m+1])&&WALL(mp[t][n+1][m]))&&(mp[t][n][m]=='*')){mp[t][n][m]='-';dfs(n-1,m,ex,ey);}//退
    if(mp[t][n-1][m]=='&'){mp[t][n-1][m]='$';_print_(sizex[t],sizey[t]);exit(0);}//上边为终点
    if(mp[t][n+1][m]=='&'){mp[t][n+1][m]='$';_print_(sizex[t],sizey[t]);exit(0);}//下边为终点
    if(mp[t][n][m-1]=='&'){mp[t][n][m-1]='$';_print_(sizex[t],sizey[t]);exit(0);}//左边为终点
    if(mp[t][n][m+1]=='&'){mp[t][n][m+1]='$';_print_(sizex[t],sizey[t]);exit(0);}//右边为终点
    if(mp[t][n-1][m]=='.')dfs(n-1,m,ex,ey);//上边为路
    if(mp[t][n+1][m]=='.')dfs(n+1,m,ex,ey);//下边为路
    if(mp[t][n][m-1]=='.')dfs(n,m-1,ex,ey);//左边为路
    if(mp[t][n][m+1]=='.')dfs(n,m+1,ex,ey);//右边为路
}
int main(){
    loop:printf("请输入是否使用已编写好的迷宫，使用请输入迷宫序号，自己输入迷宫请输入0。\n\n");
    scanf("%d",&t);
    printf("\n\n请根据选择迷宫的大小选择每步间隔时间(单位：秒)（可输入小数）\n\n");
    scanf("%f",&tm);
    switch(t){
        case 1:dfs(fx[1],fy[1],ex[1],ey[1]);return 0;
        case 2:dfs(fx[2],fy[2],ex[2],ey[2]);return 0;
        //case 3:dfs(mp3,mp3x,mp3y,mp3ex,mp3ey);return 0;
        //case 4:dfs(mp4,mp4x,mp4y,mp4ex,mp4ey);return 0;
        //case 5:dfs(mp5,mp5x,mp5y,mp5ex,mp5ey);return 0;
        case 0:goto leep;
        default:printf("\n\n您输入的序号不正确！\n\n请重新输入！\n\n");goto loop;
    }
    leep:printf("\n\n请先输入迷宫的长和宽，再输入一个迷宫，#为墙壁，.为可走的路，@为起点，&为终点。\n\n");
	scanf("%d%d",&sizex[0],&sizey[0]);
    if(sizex[0]<1||sizey[0]<1){printf("您输入的数字不正确！\n请重新输入！\n\n");goto leep;}
    for(int i=1;i<=sizex[0];i++)
        for(int j=1;j<=sizey[0];j++){
            mp[t][i][j]=readchar();
            if(mp[t][i][j]==-1){printf("\n您输入的迷宫地图有误！\n\n请重新输入！\n\n");goto leep;}
            if(mp[t][i][j]=='&')ex[0]=i,ey[0]=j;
            if(mp[t][i][j]=='@')fx[0]=i,fy[0]=j;
        }
    if(ex[0]==-1&&ey[0]==-1&&fx[0]==-1&&fy[0]==-1){printf("\n\n您输入的起点和终点均不正确！\n\n");goto leep;}
    if(ex[0]==-1||ey[0]==-1){printf("\n\n您输入的终点不正确！\n\n");goto leep;}
    if(fx[0]==-1||fy[0]==-1){printf("\n\n您输入的起点不正确！\n\n");goto leep;}
    if(WALL(mp[t][fx[0]-1][fy[0]])&&WALL(mp[t][fx[0]+1][fy[0]])&&WALL(mp[t][fx[0]][fy[0]-1]))dfs(fx[0],fy[0]+1,ex[0],ey[0]);
    if(WALL(mp[t][fx[0]-1][fy[0]])&&WALL(mp[t][fx[0]+1][fy[0]])&&WALL(mp[t][fx[0]][fy[0]+1]))dfs(fx[0],fy[0]-1,ex[0],ey[0]);
    if(WALL(mp[t][fx[0]][fy[0]-1])&&WALL(mp[t][fx[0]][fy[0]+1])&&WALL(mp[t][fx[0]-1][fy[0]]))dfs(fx[0]+1,fy[0],ex[0],ey[0]);
    if(WALL(mp[t][fx[0]][fy[0]-1])&&WALL(mp[t][fx[0]][fy[0]+1])&&WALL(mp[t][fx[0]+1][fy[0]]))dfs(fx[0]-1,fy[0],ex[0],ey[0]);
    dfs(fx[0],fy[0],ex[0],ey[0]);
    return 0;
}