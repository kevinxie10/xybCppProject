#include <cstdio>
int t;
char c;
char read(){
    char ch=getchar();
    while(ch<'a'||ch>'z')ch=getchar();
    return ch;
}
int main(){
    scanf("%d",&t);
    while(t--){
        c=read();
        switch(c){
            case 'c':printf("YES\n");break;
            case 'o':printf("YES\n");break;
            case 'd':printf("YES\n");break;
            case 'e':printf("YES\n");break;
            case 'f':printf("YES\n");break;
            case 'r':printf("YES\n");break;
            case 's':printf("YES\n");break;
            default :printf("NO\n");
        }
    }
    return 0;
}