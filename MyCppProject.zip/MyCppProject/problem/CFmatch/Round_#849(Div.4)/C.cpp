#include <cstdio>
//char s[2010];
int t,n,l,r;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d %s",&n,s);
        l=0,r=n-1;
        while(l<r){
            if((s[l]-'0')^(s[r]-'0'))n-=2,l++,r--;
            else break;
        }
        printf("%d\n",n);
    }
    return 0;
}