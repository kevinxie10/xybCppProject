#include <cstdio>
//long long n,sum[200010][30],t;
char c;
char read(){
    char ch=getchar();
    while(ch<'a'||ch>'z')ch=getchar();
    return ch;
}
void solve(){
    int ans=0;
    scanf("%lld",&n);
    for(int i=1;i<=n;i++){
        c=read();
        for(int j=0;j<26;j++)sum[i][j]=sum[i-1][j];
        sum[i][c-'a']++;
    }
    for(int i=1;i<=n;i++){
        int cntl=0,cntr=0;
        for(int j=0;j<26;j++)
            cntl+=(sum[i][j]!=0),cntr+=(sum[n][j]>sum[i][j]);
        ans=(cntl+cntr>ans?cntl+cntr:ans);
    }
    printf("%d\n",ans);
    return ;
}
int main(){
    scanf("%lld",&t);
    while(t--)solve();
    return 0;
}