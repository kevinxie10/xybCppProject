#include <cstdio>
#include <cstring>
//long long t,n,m,tr[30],tl[30],ans,cntl,cntr;
//char c[200010];
char read(){
    char ch=getchar();
    while(ch<'a'||ch>'z')ch=getchar();
    return ch;
}
void solve(){
    ans=cntl=cntr=0,memset(tr,0,sizeof tr),memset(tl,0,sizeof tl);
    scanf("%lld",&n);
    for(int i=1;i<=n;i++){
        c[i]=read();
        if(!tr[c[i]-'a'])cntr++;
        tr[c[i]-'a']++;
    }
    for(int i=1;i<=n;i++){
        tr[c[i]-'a']--;
        if(!tl[c[i]-'a'])cntl++;
        tl[c[i]-'a']=1;
        if(!tr[c[i]-'a'])cntr--;
        ans=(cntl+cntr>ans?cntl+cntr:ans);
    }
    printf("%lld\n",ans);
    return ;
}
int main(){
    scanf("%lld",&t);
    while(t--)solve();
    return 0;
}