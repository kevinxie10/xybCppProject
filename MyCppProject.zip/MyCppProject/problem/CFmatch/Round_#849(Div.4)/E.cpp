#include<cstdio>
#define MAX(x,y) (((x)>(y))?(x):(y))
//long long t,n,x,a[200010],dp[200010][2];
void solve(){
    scanf("%lld%lld",&n,a+1),dp[1][0]=a[1],dp[1][1]=-1e18;
    for(int i=2;i<=n;i++){
        scanf("%lld",a+i);
        dp[i][0]=MAX(dp[i-1][0],dp[i-1][1])+a[i];
        dp[i][1]=MAX(dp[i-1][0]-a[i-1]-a[i-1]-a[i],dp[i-1][1]-a[i]+a[i-1]+a[i-1]);
    }
    printf("%lld\n",MAX(dp[n][0],dp[n][1]));
}
int main(){
    scanf("%lld",&t);
    while(t--)solve();
    return 0;
}