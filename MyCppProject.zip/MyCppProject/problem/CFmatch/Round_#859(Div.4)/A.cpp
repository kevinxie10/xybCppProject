#include <cstdio>
int t,a,b,c;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d%d%d",&a,&b,&c);
        printf("%c\n",(a+b==c?'+':'-'));
    }
    return 0;
}