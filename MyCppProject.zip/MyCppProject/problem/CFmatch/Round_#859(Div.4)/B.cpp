#include <cstdio>
int m,b,t,n,temp;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
        scanf("%d",&temp);
        ((temp&1)?b+=temp:m+=temp);}
        if(m>b)printf("YES\n");
        else printf("NO\n");
        m=b=0;
    }
    return 0;
}