#include <cstdio>
#include <cstring>
using namespace std;
int t,n,tong[30][2023],pt[30];
char c;
void solve(int i,char c){
    for(int j=0;j<tong[c][pt[c]];j++)
        if((i-tong[c][j])&1){
            printf("NO\n");
            return ;
        }
    printf("YES\n");
    return ;
}
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            scanf("%c",&c),c-='a';
            tong[c][pt[c]++]=i;
            solve(i,c);
        }
        memset(tong,0,sizeof tong);
    }
}