#include <cstdio>
#include <cstring>
int t,n,q,l,r,temp;
long long k,sum[200010];
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&q);
        for(int i=1;i<=n;i++){
            scanf("%d",&temp);
            sum[i]=sum[i-1]+temp;
        }
        while(q--){
            scanf("%d%d%lld",&l,&r,&k);
            if((sum[n]-(sum[r]-sum[l-1])+(r-l+1)*k)%2==1)printf("YES\n");
            else printf("NO\n");
        }
        memset(sum,0,sizeof sum);
    }
    return 0;
}