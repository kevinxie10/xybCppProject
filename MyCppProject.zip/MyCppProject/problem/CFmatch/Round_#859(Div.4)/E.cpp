#include <cstdio>
int t,n,m,a[1000010],ans;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=1;i<=n;i++)scanf("%d",a+i);
        int l=1,r=n;
        ans=n;
        while(l<r){
            int mid=(l+r)/2,sum=0;
            printf("? ");
            printf("%d ",mid-l+1);
            for(int i=1;i<=mid;i++)printf("%d ",i),sum+=a[i];
            printf("\n");
            scanf("%d",&m);
            (sum==m)?l=mid+1:ans=mid,r=mid-1;
        }
        printf("! %d\n",ans);
    }
    return 0;
}