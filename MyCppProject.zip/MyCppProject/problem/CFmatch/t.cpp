#include <bits/stdc++.h>
using namespace std;
int main(){
    string s;
    s.resize(30);
    scanf("%s",&s[0]);
    cout<<s;
}