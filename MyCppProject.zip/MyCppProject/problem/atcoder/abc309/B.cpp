#include <cstdio>
int n;
char a[110][110],t;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)
        scanf("%s",a[i]);
    t=a[0][n-1];
    for(int i=n-1;i>0;i--)a[0][i]=a[0][i-1];
    for(int i=0;i<n;i++)a[i][0]=a[i+1][0];
    for(int i=0;i<n;i++)a[n-1][i]=a[n-1][i+1];
    for(int i=n-1;i>1;i--)a[i][n-1]=a[i-1][n-1];
    a[1][n-1]=t;
    for(int i=0;i<n;i++)printf("%s\n",a[i]);
    return 0;
}