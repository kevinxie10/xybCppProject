#include <iostream>
#include <algorithm>
using namespace std;
int n;
struct BOX{
    int h,w,d;
}b[200010];
bool cmp(BOX a,BOX b){
    return (a.h==b.h?(a.w==b.w?a.d<b.d:a.w<b.w):a.h<b.h);
}
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d%d%d",&b[i].h,&b[i].w,&b[i].d);
        if(b[i].h<b[i].w){
            if(b[i].w>b[i].d)swap(b[i].w,b[i].d);
            if(b[i].h>b[i].w)swap(b[i].h,b[i].w);
        }
        else{
            swap(b[i].h,b[i].w);
            if(b[i].w>b[i].d)swap(b[i].w,b[i].d);
            if(b[i].h>b[i].w)swap(b[i].h,b[i].w);
        }
    }
    sort(b,b+n,cmp);
    for(int i=0;i<n-1;i++)
        if((b[i].h<b[n-1].h)&&(b[i].w<b[n-1].w)&&(b[i].d<b[n-1].d)){
            printf("Yes\n");
            return 0;
        }
    printf("No\n");
    return 0;
}