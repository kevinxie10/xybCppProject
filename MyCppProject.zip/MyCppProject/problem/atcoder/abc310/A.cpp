#include <cstdio>
int n,p,q,t,mn=1e9;
int main(){
    scanf("%d%d%d",&n,&p,&q);
    for(int i=0;i<n;i++)scanf("%d",&t),mn=(t<mn?t:mn);
    printf("%d",(p>q+mn?q+mn:p));
    return 0;
}