#include <cstdio>
#include <algorithm>
int n,m;
struct PRODUCT{
    int p,c,f[110];
    bool operator<(const PRODUCT &a)const{
        return p>a.p;
    }
}a[110];
int main(){
    scanf("%d %d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("%d %d",&a[i].p,&a[i].c);
        for(int j=1;j<=a[i].c;j++)scanf("%d",&a[i].f[j]);
    }
    std::sort(a+1,a+1+n);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){
            if(i==j)continue;
            if(a[i].p<a[j].p)continue;
            bool ok=true;
            for(int x=1;x<=a[i].c;x++){
                bool flag=true;
                for(int y=1;y<=a[j].c;y++)
                    if(a[i].f[x]==a[j].f[y]){
                        flag=false;
                        break;
                    }
                if(flag){ok=false;break;}
            }
            if(ok)
                if(a[i].c<a[j].c&&a[i].p>a[j].p){
                    printf("Yes\n");
                    return 0;
                }
        }
    printf("No\n");
    return 0;
}