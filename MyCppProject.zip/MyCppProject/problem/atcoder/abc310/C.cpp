#include <iostream>
#include <map>
#include <string>
#include <algorithm>
using namespace std;
int n,cnt;
string s[(int)2e5];
map<string,int>mp;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)cin>>s[i];
    for(int i=0;i<n;++i){
        string str=s[i];
        reverse(s[i].begin(),s[i].end());
        if(mp[s[i]]||mp[str])continue;
        mp[s[i]]++;
        mp[str]++;
        cnt++;
    }
    printf("%d",cnt);
    return 0;
}