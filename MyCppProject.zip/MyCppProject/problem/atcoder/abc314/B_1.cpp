#include <cstdio>
#include <cstring>
int n,c[110],a[110][40],x,mnlen=1e9,ans[110],p;
bool flag[110];
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",c+i);
        for(int j=0;j<c[i];j++)scanf("%d",&a[i][j]);
    }
    scanf("%d",&x);
    for(int i=0;i<n;i++){
        for(int j=0;j<c[i];j++)
            if(a[i][j]==x&&c[i]<=mnlen){
                if(c[i]<mnlen){
                    mnlen=c[i];
                    memset(flag,0,sizeof flag);
                    flag[i]=true;
                }
                flag[i]=true;
            }
    }
    for(int i=0;i<n;i++)
        if(flag[i])ans[p++]=i;
    printf("%d\n",p);
    for(int i=0;i<p;i++)printf("%d ",ans[i]+1);
    return 0;
}