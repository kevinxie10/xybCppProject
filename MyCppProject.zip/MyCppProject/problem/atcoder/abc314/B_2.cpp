#include <iostream>
#include <algorithm>
#include <utility>
#include <vector>
using namespace std;
vector<pair<int,int>>v;
int n,c[110],a[110][40],x,cnt;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",c+i);
        for(int j=0;j<c[i];j++)scanf("%d",&a[i][j]);
    }
    scanf("%d",&x);
    for(int i=0;i<n;i++)
        for(int j=0;j<c[i];j++)
            if(a[i][j]==x)v.push_back({c[i],i});
    sort(v.begin(),v.end());
    for(auto i:v){
        if(i.first!=v.front().first)break;
        cnt++;
    }
    printf("%d\n",cnt);
    for(int i=0;i<cnt;i++)printf("%d ",v[i].second+1);
    return 0;
}