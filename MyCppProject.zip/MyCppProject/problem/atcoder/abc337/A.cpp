#include <cstdio>
int n,x,y,sumx,sumy;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d%d",&x,&y),sumx+=x,sumy+=y;
    if(sumx>sumy)printf("Takahashi\n");
    else if(sumx<sumy)printf("Aoki\n");
    else printf("Draw\n");
    return 0;
}