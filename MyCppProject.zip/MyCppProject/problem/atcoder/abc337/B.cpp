#include <iostream>
using namespace std;
string s;
int main(){
    cin>>s;
    for(int i=0;i<s.length()-1;i++){
        if(s[i]=='B'&&s[i+1]=='A'){printf("No");return 0;}
        if(s[i]=='C'&&s[i+1]!='C'){printf("No");return 0;}
    }
    printf("Yes");
    return 0;
}