#include <iostream>
using namespace std;
int n,a;
struct people{
    int id;
    struct people *next=nullptr;
}p[300010],head;
void list(struct people *node){
    while(node->next!=nullptr){
        printf("%d ",node->id);
        node=node->next;
    }
    /*if(node->id)printf("%d ",node->id);
    if(node->next!=nullptr)list(node->next);*/
    return ;
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",&a);
        if(a==-1)head.id=i,head.next=&p[i];
        else p[a].id=i,p[a].next=&p[i];
    }
    list(&head);
    return 0;
}