#include<iostream>
int n,h[5010];
int slove(int l,int r){
	if(l<0||r<0||l>r)return 0;
	if(l==r)return (h[l]<1?h[l]:1);
	int mn=2147483647,p=0;
	for(int i=l;i<=r;i++)h[i]<mn?mn=h[i],p=i:mn=mn;
	int t=h[p];
	for(int i=l;i<=r;i++)h[i]-=t;
	return std::min(t+slove(l,p-1)+slove(p+1,r),r-l+1);
}
int main(){
	scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",h+i);
	printf("%d",std::min(n,slove(0,n-1)));
	return 0;
}