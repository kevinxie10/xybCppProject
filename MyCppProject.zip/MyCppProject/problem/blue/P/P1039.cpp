#include<iostream>
#include<map>
using namespace std;
map<string,int>nm;
int n,m,p,num[30];
string name[30],s[30][255],t,sen;
bool crap(string tmp){
    if(tmp==" I am guilty.")return false;
    if(tmp==" I am not guilty.")return false;
    if(tmp==" Today is Monday.")return false;
    if(tmp==" Today is Tuesday.")return false;
    if(tmp==" Today is Wednesday.")return false;
    if(tmp==" Today is Thursday.")return false;
    if(tmp==" Today is Friday.")return false;
    if(tmp==" Today is Saturday.")return false;
    if(tmp==" Today is Sunday.")return false;
    for(int i=1;i<=m;i++)
        if(tmp==" "+name[i]+" is guilty."||tmp==" "+name[i]+" is not guilty.")return false;
    return true;
}
bool judge(int guilty,int day){
    int ans;
    for(int i=1;i<=m;i++){
        ans=0;
        for(int j=1;j<=num[i];j++){
            if(s[i][j]==" I am guilty."&&guilty!=i){ans++;}
            if(s[i][j]==" I am not guilty."&&guilty==i){ans++;}
            if(s[i][j]==" Today is Monday."&&day!=1){ans++;}
            if(s[i][j]==" Today is Tuesday."&&day!=2){ans++;}
            if(s[i][j]==" Today is Wednesday."&&day!=3){ans++;}
            if(s[i][j]==" Today is Thursday."&&day!=4){ans++;}
            if(s[i][j]==" Today is Friday."&&day!=5){ans++;}
            if(s[i][j]==" Today is Saturday."&&day!=6){ans++;}
            if(s[i][j]==" Today is Sunday."&&day!=7){ans++;}
            for(int k=1;k<=m;k++){
                if(s[i][j]==" "+name[k]+" is guilty."&&guilty!=k){ans++;}
                if(s[i][j]==" "+name[k]+" is not guilty."&&guilty==k){ans++;}
            }
        }
        if(ans!=num[i]&&ans!=0)return false;
    }
    return true;
}
int check(int guilty,int day){
    int ans=0;
    bool flag;
    for(int i=1;i<=m;i++)
        for(int j=1;j<=num[i];j++){
            flag=0;
            if(s[i][j]==" I am guilty."&&guilty!=i){ans++;break;}
            if(s[i][j]==" I am not guilty."&&guilty==i){ans++;break;}
            if(s[i][j]==" Today is Monday."&&day!=1){ans++;break;}
            if(s[i][j]==" Today is Tuesday."&&day!=2){ans++;break;}
            if(s[i][j]==" Today is Wednesday."&&day!=3){ans++;break;}
            if(s[i][j]==" Today is Thursday."&&day!=4){ans++;break;}
            if(s[i][j]==" Today is Friday."&&day!=5){ans++;break;}
            if(s[i][j]==" Today is Saturday."&&day!=6){ans++;break;}
            if(s[i][j]==" Today is Sunday."&&day!=7){ans++;break;}
            for(int k=1;k<=m;k++){
                if(s[i][j]==" "+name[k]+" is guilty."&&guilty!=k){ans++;flag=1;break;}
                if(s[i][j]==" "+name[k]+" is not guilty."&&guilty==k){ans++;flag=1;break;}
            }
            if(flag==1) break;
        }
    if(ans!=n)
        for(int i=1;i<=m;i++){
            if(num[i]==0) ans++;
            if(ans==n) break;
        }
    return ans;
}
string getline(){
    string s,t;
    do{
        cin>>t;
        s=s+" "+t;
    }
    while(t[t.length()-1]!='.'&&t[t.length()-1]!='?'&&t[t.length()-1]!='!'&&t[t.length()-1]!=',');
    return s;
}
int main(){
    scanf("%d%d%d",&m,&n,&p);
    for(int i=1;i<=m;i++){
        cin>>t;
        nm[t]=i,name[i]=t;
    }
    for(int i=1;i<=p;i++){
        cin>>t;
        t.pop_back();
        sen=getline();
        if(crap(sen))continue;
        num[nm[t]]++;
        s[nm[t]][num[nm[t]]]=sen;
    }
    int flag=0;
    for(int i=1;i<=m;i++)
        for(int j=1;j<=7;j++)
            if(check(i,j)==n&&judge(i,j)){
                if(flag){
                    cout<<"Cannot Determine"<<endl;
                   return 0;
                }
                else{
                    flag=i;
                    break;
                }
            }
    if(flag==0)cout<<"Impossible"<<endl; else cout<<name[flag]<<endl;
   return 0;
}