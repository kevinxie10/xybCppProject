#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define ll long long
const int score[10][10]={
    {0,0,0,0,0,0,0,0,0,0},
    {0,6,6,6,6,6,6,6,6,6},
    {0,6,7,7,7,7,7,7,7,6},
    {0,6,7,8,8,8,8,8,7,6},
    {0,6,7,8,9,9,9,8,7,6},
    {0,6,7,8,9,10,9,8,7,6},
    {0,6,7,8,9,9,9,8,7,6},
    {0,6,7,8,8,8,8,8,7,6},
    {0,6,7,7,7,7,7,7,7,6},
    {0,6,6,6,6,6,6,6,6,6}
};
int row[10][10],col[10][10],area[10][10],sdk[10][10],cntrow[10],cntcolor[10],cnt,ans=-1;
inline int id(int i,int j){return (i-1)/3*3+1+(j-1)/3;}
inline int calc(){
    int tmp=0;
    for(int i=1;i<=9;++i)
        for(int j=1;j<=9;++j)tmp+=score[i][j]*sdk[i][j];
    return tmp;
}
void dfs(int r,int c,int cpl){    
    if(cpl==81){
        ans=max(ans,calc());
        return ;
    }
    for(int k=1;k<=9;++k){
        if(row[r][k]||col[c][k]||area[id(r,c)][k]) continue;
        row[r][k]=true;
        col[c][k]=true;
        area[id(r,c)][k]=true;
        cntrow[r]++,cntcolor[c]++;
        sdk[r][c]=k;
        int tmpr=-1,nxt_r=0,tmpc=-1,nxt_c=0;
        for(int i=1;i<=9;++i)
            if(cntrow[i]>tmpr&&cntrow[i]<9)
                tmpr=cntrow[i],nxt_r=i;
        for(int j=1;j<=9;++j)
            if(cntcolor[j]>tmpc&&(!sdk[nxt_r][j]))
                tmpc=cntcolor[j],nxt_c=j;
        dfs(nxt_r,nxt_c,cpl+1);
        row[r][k]=false;
        col[c][k]=false;
        area[id(r,c)][k]=false;
        cntrow[r]--,cntcolor[c]--;
        sdk[r][c]=0;
    }
}
int main(){    
    for(int i=1;i<=9;i++)
        for(int j=1;j<=9;j++){
            scanf("%d",&sdk[i][j]);
            if(sdk[i][j]!=0){
                row[i][sdk[i][j]]=true;
                col[j][sdk[i][j]]=true;
                area[id(i,j)][sdk[i][j]]=true;
                cntrow[i]++,cntcolor[j]++;
                cnt++;
            }
        }
    int tmpr=-1,r,tmpc=-1,c;
    for(int i=1;i<=9;i++)
        if(cntrow[i]>cntrow[i-1]&&cntrow[i]<9)tmpr=cntrow[i],r=i;
    for(int j=1;j<=9;j++)
        if(cntcolor[j]>tmpc&&(!sdk[r][j]))tmpc=cntcolor[j],c=j;
    dfs(r,c,cnt);
    cout<<ans<<endl;
}