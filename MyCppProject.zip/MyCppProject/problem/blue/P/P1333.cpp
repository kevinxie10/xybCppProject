#include<map>
#include<string>
#include<iostream>
using namespace std;
string a,b;
map<string,int>mp;
map<string,string>fa;
int cnt;
string find(string x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
void merge(string x,string y){
    fa[find(x)]=find(y);
	return ;
}
int main(){
    while(cin>>a>>b){
        if(!mp[a])fa[a]=a;
        if(!mp[b])fa[b]=b;
        mp[a]++,mp[b]++;
        merge(a,b);
    }
    for(auto i:mp)cnt+=(i.second%2);
    if(cnt>2){
        printf("Impossible");
        return 0;
    }
	a=find(a);
    for(auto i:mp)
        if(find(i.first)!=a){cout<<"Impossible";return 0;}
    printf("Possible");
    return 0;
}