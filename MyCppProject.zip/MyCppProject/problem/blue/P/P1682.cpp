#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
struct edge{
    int u,v;
};
int n,m,k,f,a,b,fa[100010],num[100010],ans=2147483647;
bool vis[500][500];
vector<edge>g;
int find(int x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
void merge(int x,int y){
    int fx=find(x),fy=find(y);
    if(fx!=fy)fa[fx]=fy;
    return ;
}
int main(){
    scanf("%d%d%d%d",&n,&m,&k,&f);
    for(int i=0;i<n;i++)fa[i]=i;
    for(int i=0;i<m;i++)scanf("%d%d",&a,&b),g.push_back({a,b});
    for(int i=0;i<f;i++)scanf("%d%d",&a,&b),merge(a,b);
    for(int i=0;i<m;i++){
        int u=find(g[i].u),v=g[i].v;
        if(!vis[u][v])num[u]++,vis[u][v]=true;
    }
    for(int i=0;i<n;i++)
        if(num[i])ans=(num[i]<ans?num[i]:ans);
    printf("%d",(n<ans+k?n:ans+k));
    return 0;
}