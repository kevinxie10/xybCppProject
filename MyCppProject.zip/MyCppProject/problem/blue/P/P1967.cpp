#include <cstdio>
#include <algorithm>
using namespace std;
const int MAXN=100005,MAXM=MAXN,inf=1000000007;
int n,m,E,ter[MAXM],lnk[MAXN],nxt[MAXM],w[MAXM],dep[MAXN],fa[MAXN][21],d[MAXN][21],f[MAXN];
struct edge{
    int x,y,z;
}e[MAXM];
inline bool cmp(edge a,edge b){return a.z>b.z;}
inline void add(int x,int y,int z){ter[++E]=y,nxt[E]=lnk[x],lnk[x]=E,w[E]=z;}
inline void dfs(int p,int las){
    for(int i=1;(1<<i)<=dep[p];i++){
        fa[p][i]=fa[fa[p][i-1]][i-1];
        d[p][i]=min(d[p][i-1],d[fa[p][i-1]][i-1]);
    }
    for(int i=lnk[p];i;i=nxt[i])
        if(ter[i]!=las){
            dep[ter[i]]=dep[p]+1;
            fa[ter[i]][0]=p;
            d[ter[i]][0]=w[i];
            dfs(ter[i],p);
        }
}
int query(int x,int y){
    if(dep[x]<dep[y])swap(x,y);
    int res=dep[x]-dep[y],ret=inf;
    for(int i=20;i>=0;i--)
        if((res>>i)&1){
            ret=min(ret,d[x][i]);
            x=fa[x][i];
        }
    if(x==y)return ret;
    for(int i=20;i>=0;i--)
        if(fa[x][i]!=fa[y][i]){
            ret=min(ret,min(d[x][i],d[y][i]));
            x=fa[x][i],y=fa[y][i];
        }
    return min(ret,min(d[x][0],d[y][0]));
}
inline int find(int x){return (f[x]==x?x:f[x]=find(f[x]));}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)scanf("%d%d%d",&e[i].x,&e[i].y,&e[i].z);
    sort(e+1,e+m+1,cmp);
    for(int i=1;i<=n;i++)f[i]=i;
    for(int i=1;i<=m;i++){
        int x=find(e[i].x),y=find(e[i].y);
        if(x!=y)add(x,y,e[i].z),add(y,x,e[i].z),f[x]=y;
    }
    for(int i=1;i<=n;i++)if(find(i)==i)dfs(i,0);
    int q,x,y;
    scanf("%d",&q);
    for(int i=1;i<=q;i++){
        scanf("%d%d",&x,&y);
        if(find(x)!=find(y)){printf("-1\n");continue;}
        printf("%d\n",query(x,y));
    }
    return 0;
}