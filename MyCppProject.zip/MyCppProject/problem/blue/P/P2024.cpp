#include <cstdio>
int n,m,ans,fa[150030],a,x,y;
int find(int x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
void Union(int x,int y){
    x=find(x),y=find(y);
    if(x!=y)fa[y]=x;
}
bool same(int x,int y){return find(x)==find(y);}
int main(){
    scanf("%d%d",&m,&n);
    for(int i=1;i<3*m;i++)fa[i]=i;
    for(int i=1;i<=n;i++){
        scanf("%d%d%d",&a,&x,&y);
        if(x>m||y>m){ans++;continue;}
        if(a==1){
            if(same(x+m,y)||same(x+m+m,y))ans++;
            else Union(x,y),Union(x+m,y+m),Union(x+m+m,y+m+m);
        }
        else{
            if(x==y||same(x,y)||same(x+m+m,y))ans++;
            else Union(x,y+m+m),Union(x+m,y),Union(x+m+m,y+m);
        }
    }
    printf("%d",ans);
    return 0;
}