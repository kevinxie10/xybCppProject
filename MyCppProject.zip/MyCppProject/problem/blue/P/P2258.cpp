#include <cstdio>

int main(){
    
}