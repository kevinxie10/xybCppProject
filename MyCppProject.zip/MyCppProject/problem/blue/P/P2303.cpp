#include <cstdio>
unsigned long long n,sum,i;
unsigned long long phi(unsigned long long n){
    unsigned long long ans=n;
    for(int i=2;i*i<=n;i++){
        if(n%i==0){
            ans=ans/i*(i-1);
            while(n%i==0)n/=i;
        }
    }
    if(n>1)ans=ans/n*(n-1);
    return ans;
}
int main(){
    scanf("%llu",&n);
    for(i=1;i*i<n;i++)
        if(n%i==0)sum+=i*phi(n/i)+(n/i)*phi(i);
    if(i*i==n)sum+=i*phi(i);
    printf("%llu",sum);
    return 0;
}
/*#include <iostream>
#include <map>
using namespace std;
const int N=1<<16;
//map<int,long long>phi;
long long n,sum,p[N],phi[N],cnt;
void euler(){
	phi[1]=1;
	for(int i=2;i<=N;i++){
		if(!phi[i])p[++cnt]=i,phi[i]=i-1;
		for(int j=1;j<=cnt&&i*p[j]<=N;j++){
			if(i%p[j]==0){
				phi[i*p[j]]=phi[i]*p[j];
				break;
			}
			else phi[i*p[j]]=phi[i]*phi[p[j]];
		}
	}
}
int main(){
    scanf("%lld",&n);
    euler();
    for(int i=1;i*i<=n;i++){
        if(n%i==0){
            sum+=i*phi[n/i];
            if(i*i!=n)sum+=(n/i)*phi[i];
        }
    }
    printf("%lld",sum);
    return 0;
}*/