#include <iostream>
#include <queue>
#include <map>
using namespace std;
struct node{
    int x,y,step;
    string st;
};
char c[10][10];
int t,dx[]={2,2,-2,-2,1,1,-1,-1},dy[]={1,-1,1,-1,2,-2,2,-2};
string e="111110111100*110000100000";
int check(string s){
    int cnt=0;
    for(int i=0;i<25;i++)cnt+=(s[i]!=e[i]);
    return cnt;
}
void solve(){
    map<string,int>mp;
    queue<node>q;
    string s="";
    int sx,sy;
    for(int i=0;i<5;i++)
        for(int j=0;j<5;j++){
            cin>>c[i][j];
            s+=c[i][j];
            if(c[i][j]=='*')sx=i,sy=j;
        }
    mp[s]=1;
    q.push({sx,sy,0,s});
    while(!q.empty()){
        node k=q.front();
        q.pop();
        for(int w=0;w<8;w++){
            int xx=k.x+dx[w],yy=k.y+dy[w];
            if(xx<0||xx>4||yy<0||yy>4)continue;
            for(int i=0;i<5;i++)
                for(int j=0;j<5;j++)c[i][j]=k.st[i*5+j];
            swap(c[xx][yy],c[k.x][k.y]);
            s="";
            for(int i=0;i<5;i++)
                for(int j=0;j<5;j++)s+=c[i][j];
            swap(c[xx][yy],c[k.x][k.y]);
            if(s==e){printf("%d\n",k.step+1);return ;}
            if(!mp[s]&&k.step+check(s)<=15)q.push({xx,yy,k.step+1,s}),mp[s]=1;
        }
    }
    printf("-1\n");
    return ;
}
int main(){
    scanf("%d",&t);
    while(t--){
        solve();
    }
    return 0;
}