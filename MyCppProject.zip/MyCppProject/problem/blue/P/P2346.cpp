#include <iostream>
#include <map>
#include <queue>
#include <string>
using namespace std;
map<string,bool>mp;
char c[10][10];
struct node{
    int x,y,X,Y,op,step;
    string s;
};
queue<node>q;
bool check(string s){
    for(int i=1;i<=4;i++)
        for(int j=1;j<=4;j++)c[i][j]=s[(i-1)*4+(j-1)];
    for(int i=1;i<=4;i++){
        if(c[1][1]==c[1][2]&&c[1][2]==c[1][3]&&c[1][3]==c[1][4])return true;
        if(c[1][4]==c[2][3]&&c[2][3]==c[3][2]&&c[3][2]==c[4][1])return true;
        for(int i=2;i<=4;i++){
            if()
        }
    }
}
void bfs(int x,int y,int X,int Y,int op,int step,string s){
    q.push({x,y,X,Y,op,step,s})
    while(!q.empty()){
        node k=q.front();
        if(check()){ans=min(ans,step);return ;}
        for(int i=1;i<=4;i++)
            for(int j=1;j<=4;j++)c[i][j]=s[(i-1)*4+(j-1)];
        for(int i=0;i<4;i++){
            int xx=dx[i]+x;
            int yy=dy[i]+y;
            if(xx<1||yy<1||xx>4||yy>4)continue;
            string ss="";
            if(op==1&&c[xx][yy]=='B'){
                swap(c[xx][yy],c[x][y]);
                for(int i=1;i<=4;i++)
                    for(j=1;j<=4;j++)ss+=c[i][j];
                swap(c[xx][yy],c[x][y]);
                if(mp[ss]==1)continue;
                mp[ss]=1;

        }
    }
}

int a1,a2,b1,b2;
int main(){
    for(int i=1;i<=4;i++)
        for(int j=1;j<=4;j++){
            scanf("%c",&c[i][j]);
            if(c[i][j]=='O'){
                if(!a1)a1=i,a2=j;
                else a2=i,b2=j;
            }
        }
    bfs(a1,b1,a2,b2,1,0,s);
}