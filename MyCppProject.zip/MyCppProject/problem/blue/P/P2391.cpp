#include<cstdio>
#include<algorithm>
using namespace std;
long long n,m,p,q,flag[1000010];
int main(){
    scanf("%lld%lld%lld%lld",&n,&m,&p,&q);
    for(int i=m;i>=1;i--){
        int l=(i*q+p)%n+1,r=(i*p+q)%n+1;
        if(l>r)swap(l,r);
        for(int j=l;j<=r&&!flag[j];j++)flag[j]=i;
        for(int j=r;j>=l&&!flag[j];j--)flag[j]=i;
    }
    for(int i=1;i<=n;i++)printf("%lld\n",flag[i]);
    return 0;
}