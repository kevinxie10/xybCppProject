#include<cstdio>
const int N=100010;
long long n,ans,cnt,phi[N],p[N];
void euler(){
	phi[1]=1;
	for(int i=2;i<=N;i++){
		if(!phi[i])p[++cnt]=i,phi[i]=i-1;
		for(int j=1;j<=cnt&&i*p[j]<=N;j++){
			if(i%p[j]==0){
				phi[i*p[j]]=phi[i]*p[j];
				break;
			}
			else phi[i*p[j]]=phi[i]*phi[p[j]];
		}
	}
}
signed main(){
    scanf("%lld",&n);
	euler();
	for(int i=1;i<=n;i++)ans+=phi[i]*(n/i)*(n/i);
	printf("%lld",ans);
	return 0;
}