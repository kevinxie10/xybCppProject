#include<bits/stdc++.h>
#define int long long
using namespace std;
const int M=114514;
long long c[M],p[M],l[M],x,y,k;
int gcd(int a,int b){
	if(b==0) return a;
	return gcd(b,a%b);
}
void exgcd(int a,int b){
	if(b==0){
		x=1;
		y=0;
		return ;
	}
	exgcd(b,a%b);
	long long tmp=x;
	x=y;
	y=tmp-a/b*y;
	return ;
}
bool check(int m,int n,int a,int b,int l,int life){
	int g=gcd(a-b+l,l);
	if(!((n-m+l)%g)){
		exgcd((a-b+l)/g,l/g);
		x=x*(n-m+l)/g;
		x=(x%(l/g)+(l/g))%(l/g);
		if(x>life)return 1;
		return 0;
	}else{
		return 1;
	}
}
signed main(){
	cin>>k;
	int mx=0;
	for(int i=1;i<=k;i++){
		cin>>c[i]>>p[i]>>l[i];
		mx = max(c[i], mx);
	}
	for(int i= mx;i<=1000000;i++){
		int flag=1;
		for(int j1=1;j1<=k;j1++){
			for(int j2=j1+1;j2<=k;j2++){
				if(!check(c[j1],c[j2],p[j1],p[j2],i,min(l[j1],l[j2]))){
					flag=0;
					j1=k;
					break;
				}
			}
		}
		if(flag){
			cout<<i;
			return 0;
		}
	}
	return 0;
}