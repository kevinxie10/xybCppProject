#include <cmath>
#include <iostream>
using std::abs;
const int N=15;
int l,r,num[N],f[N][10],cnt,res,lst=-2;
void init(){
    for(int i=0;i<10;i++)f[1][i]=1;
    for(int i=2;i<N;i++)
        for(int j=0;j<10;j++)
            for(int k=0;k<10;k++)
                if(abs(j-k)>=2)f[i][j]+=f[i-1][k];
    return ;
}
int dp(int x){
    if(!x)return 0;
    cnt=res=0,lst=-2;
    while(x)num[++cnt]=x%10,x/=10;
    for(int i=cnt;i>=1;i--){
        for(int j=(i==cnt);j<num[i];j++)//最高位从1开始
            if(abs(j-lst)>=2)res+=f[i][j];
        if(abs(num[i]-lst)<2)break;
        lst=num[i];
        if(i==1)res++;
    }
    for(int i=1;i<cnt;i++)
        for(int j=1;j<10;j++)res+=f[i][j];
    return res;
}
int main(){
    init();
    scanf("%d%d",&l,&r);
    printf("%d",dp(r)-dp(l-1));
    return 0;
}