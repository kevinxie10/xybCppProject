#include <iostream>
#include <vector>
#include <stack>
using namespace std;
const int N=10010;
vector<int>e[N];
stack<int>s;
int dfn[N],low[N],tot,scc[N],stk[N],top,cnt,din[N],dout[N],n,u,v,cntin,cntout;
bool instk[N];
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    stk[++top]=x,instk[x]=true;
    for(int y:e[x]){
        if(!dfn[y])tarjan(y),low[x]=min(low[x],low[y]);
        else if(instk[y])low[x]=min(low[x],dfn[y]);
    }
    if(dfn[x]==low[x]){
        int y;
        cnt++;
        do{
            y=stk[top--];
            instk[y]=0;
            scc[y]=cnt;
        }while(x!=y);
    }
    return ;
}
int main(){
    scanf("%d",&n);
    for(int i=1,t;i<=n;i++)
        while(cin>>t,t)e[i].push_back(t);
    for(int i=1;i<=n;i++)
        if(!dfn[i])tarjan(i);
    for(int x=1;x<=n;x++)
        for(auto y:e[x])
            if(scc[x]!=scc[y])din[scc[y]]++,dout[scc[x]]++;
    for(int i=1;i<=cnt;i++){
        if(!din[i])cntin++;
        if(!dout[i])cntout++;
    }
    printf("%d\n",cntin);
    if(cnt==1)printf("0");
    else printf("%d\n",(cntin>cntout?cntin:cntout));
    return 0;
}