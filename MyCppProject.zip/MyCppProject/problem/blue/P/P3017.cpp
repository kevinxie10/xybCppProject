#include <cstdio>
int n,m,r,c,cntx,cnty,x,y;
long long a[510][510];
long long sum(int x,int y,int xx,int yy){
    return a[xx][yy]-a[xx][y-1]-a[x-1][yy]+a[x-1][y-1];
}
bool check(int k){
    x=1,cnty=cntx=0;
    for(int i=1;i<=n;i++){
        y=1,cnty=0;
        for(int j=1;j<=m;j++)
            if(sum(x,y,i,j)>=k)cnty++,y=j+1;
        if(cnty>=c)cntx++,x=i+1;
    }
    return cntx>=r;
}
int main(){
    scanf("%d%d%d%d",&n,&m,&r,&c);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            scanf("%lld",&a[i][j]),a[i][j]+=a[i-1][j]+a[i][j-1]-a[i-1][j-1];
    int l=0,r=a[n][m],ans=0;
    while(l<=r){
        int mid=(l+r)>>1;
        if(check(mid))ans=mid,l=mid+1;
        else r=mid-1;
    }
    printf("%d",ans);
    return 0;
}