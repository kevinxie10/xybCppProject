#include <iostream>
#include <vector>
using namespace std;
const int N=100010;
vector<int>g[N];
long long dfn[N],low[N],ans[N],s[N],tot,root,m,n,a,b;
bool cut[N];
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    s[x]=1;
    int child=0,sum=0;
    for(auto y:g[x]){
        if(!dfn[y]){
            tarjan(y);
            s[x]+=s[y];
            low[x]=min(low[x],low[y]);
            if(low[y]>=dfn[x]){
                ans[x]+=s[y]*(n-s[y]);
                sum+=s[y];
                child++;
                if(x!=1||child>=2)cut[x]=true;
            }
        }
        else low[x]=min(low[x],dfn[y]);
    }
    if(!cut[x])ans[x]=(n-1)<<1;
    else ans[x]+=(n-sum-1)*(sum+1)+(n-1);
}
int main(){
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%lld%lld",&a,&b);
        g[a].push_back(b);
        g[b].push_back(a);
    }
    tarjan(1);
    for(int i=1;i<=n;i++)printf("%lld\n",ans[i]);
    return 0;
}