#include <iostream>
#include <vector>
using namespace std;
int n,m,q,t;
vector<int>g[1000010];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",&t),g[t].push_back
}