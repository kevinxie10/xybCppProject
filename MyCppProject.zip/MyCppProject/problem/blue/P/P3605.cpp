#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
const int N=100010;
long long n,m,ans[N],cnt,c[N<<1],l[N],r[N],mx,a[N],b[N];
vector<int> g[N];
struct node{
	int x,y;
	bool operator<(const node &t)const{return x>t.x;}
}p[N];
void add(int i,int k){for(;i<=n;i+=(i&-i))c[i]+=k;}
int find(int i){
	int sum=0;
	for(;i>0;i-=(i&-i))sum+=c[i];
	return sum;
}
void dfs(int x,int f){
	l[x]=++cnt;
	p[cnt].x=a[x],p[cnt].y=x;
	for(int i:g[x]){
		if(i==f)continue;
		dfs(i,x);
	}
	r[x]=cnt;
	return ;
}
int main(){
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)scanf("%lld",a+i),b[i]=a[i];
	for(int i=2,v;i<=n;i++)scanf("%d",&v),g[i].push_back(v),g[v].push_back(i);
	dfs(1,0);
	sort(p+1,p+1+n);
	for(int i=1;i<=n;i++)ans[p[i].y]=find(r[p[i].y])-find(l[p[i].y]-1),add(l[p[i].y],1);
	for(int i=1;i<=n;i++)printf("%lld\n",ans[i]);
	return 0;
}