#include<cstdio>
#include<algorithm>
#include<vector>
#include<functional>
#define lowbit(x) ((x)&(-(x))) 
using namespace std;
const int N=200010;
int n,ans[N],tot,c[N],l[N],r[N];
pair<int,int>a[N];
vector<int> g[N];
void add(int i){
	for(;i<=n;i+=lowbit(i))c[i]++;
}
int find(int i){
	int sum=0;
	for(;i>0;i-=lowbit(i))sum+=c[i];
	return sum;
}
void dfs(int x,int f){
	l[x]=++tot;
	for(int i:g[x]){
		dfs(i,x);
	}
	r[x]=tot;
	return ;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i].first),a[i].second=i;
	for(int i=2,v;i<=n;i++)scanf("%d",&v),g[v].push_back(i);
	dfs(1,0);
	sort(a+1,a+1+n,greater<pair<int,int>>());
	for(int i=1;i<=n;i++){
		ans[a[i].second]=find(r[a[i].second])-find(l[a[i].second]-1);
		add(l[a[i].second]);
	}
	for(int i=1;i<=n;i++)printf("%d\n",ans[i]);
	return 0;
}