#include <cstring>
#include <iostream>
using namespace std;
const int N=11000010,P=131;
int n,res,ans=1,l,r;
unsigned long long p[N],h1[N],h2[N];
char c[N];
bool check(int l,int r){
    if(l<1||r>n)return false;
    return h1[r]-h1[l-1]*p[r-l+1]==h2[l]-h2[r+1]*p[r-l+1];
}
int main(){
    scanf("%s",c+1);
    n=strlen(c+1);
    p[0]=1;
    for(int i=1;i<=n;i++){
        p[i]=p[i-1]*P;
        h1[i]=h1[i-1]*P+c[i];
    }
    for(int i=n;i>=1;i--)h2[i]=h2[i+1]*P+c[i];
    for(int i=1;i<=n;i++){
        while(check(i-res,i+res))res++;
        while(check(i-ans+1,i+ans))ans++;
    }
    printf("%d",max(((res-1)<<1)+1,(ans-1)<<1));
    return 0;
}