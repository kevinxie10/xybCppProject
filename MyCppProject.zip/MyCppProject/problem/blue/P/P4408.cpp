#include <iostream>
#include <vector>
using namespace std;
const int N=200010;
long long n,m,u,v,w,dis[N],disA[N],disB[N],A,B,mx;//A:从1号点出发找到的最远点
vector<pair<long long,long long>>g[N];
void dfs(long long u,long long f){
	for(auto i:g[u]){
		if(i.second==f)continue;
		dis[i.second]=dis[u]+i.first;
		if(dis[i.second]>dis[A])A=i.second; 
		dfs(i.second,u);
	}
}
void dfsA(long long u,long long f){
	for(auto i:g[u]){
		if(i.second==f)continue;
		disA[i.second]=disA[u]+i.first;
		if(disA[i.second]>disA[B])B=i.second;
		dfsA(i.second,u);
	}
}
void dfsB(long long u,long long f){
	for(auto i:g[u]){
		if(i.second==f)continue;
		disB[i.second]=disB[u]+i.first;
		//if(disB[i.second]>disA[B])B=i.second;
		dfsB(i.second,u);
	}
}
int main(){
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%lld%lld%lld",&u,&v,&w);
		g[u].push_back({w,v});
		g[v].push_back({w,u});
	}
	dfs(1,0);
	dfsA(A,0);
	dfsB(B,0);
	
	for(int i=1;i<=n;i++)mx=max(mx,min(disA[i],disB[i]));
	printf("%lld",mx+disA[B]);
	return 0;
}