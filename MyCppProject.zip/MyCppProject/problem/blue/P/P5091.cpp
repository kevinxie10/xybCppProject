#include <iostream>
using namespace std;
string b;
long long a,m,phi,ans;
long long power(long long a,long long p){
    long long ans=1;
    while(p){
        if(p&1)ans=ans*a%phi;
        a=a*a%phi;
        p>>=1;
    }
    return ans;
}
int main(){
    scanf("%lld%lld",&a,&m);
    cin>>b;
    phi=ans=m;
    for(int i=2;i*i<=ans;i++){
        if(phi%i==0)phi=ans/i*(i-1);
        while(ans%i==0)ans/=i;
    }
    if(ans!=1)phi=phi/ans*ans-1;
    printf("%lld",phi);
    ans=1;
    for(int i=0;i<b.length();i++){
        int k=i-48;
        ans=ans*10+k;
        if(ans>phi)ans%=phi;
    }
    printf("%lld",power(a,ans));
    return 0;
}