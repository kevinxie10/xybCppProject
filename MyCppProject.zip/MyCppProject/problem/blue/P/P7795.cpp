#include<cstdio>
long long n,k,a[300010];
double sum[300010],l=0,r=1000000;
bool check(double x){
	for(int i=1;i<=n;i++)sum[i]=sum[i-1]+a[i]-x;
	double mn=0;
	for(int i=k;i<=n;i++){
		mn=(sum[i-k]<mn?sum[i-k]:mn);
		if(sum[i]>=mn)return true;
	}
	return false;
}
int main(){
	scanf("%lld%lld",&n,&k);
	for(int i=0;i<n;i++)scanf("%lld",a+i);
	while(r-l>=1e-6){
		double mid=(l+r)/2;
		if(check(mid))l=mid;
		else r=mid;
	}
	printf("%.6lf\n",(l+r)/2);
	return 0;
}