#include <cstdio>
int n,a[110],s[110],sum;
int main(){
    while(scanf("%d",a+n)!=EOF)n++;
    n--;
    for(int i=0;i<n;i++)s[i]=a[i+1]-a[i]-1;
    for(int i=0;i<n;i+=2)sum^=s[i];
    if(!sum){printf("-1");return 0;}
    for(int i=0;i<n;i++)
        for(int step=1;step<a[i+1]-a[i];step++){
            s[i]-=step;
            if(i)s[i-1]+=step;
            sum=0;
            for(int cnt=0;cnt<n;cnt+=2)sum^=s[cnt];
            if(!sum){printf("%d %d",a[i],a[i]+step);break;}
            s[i]+=step;
            if(i)s[i-1]-=step;
        }
    return 0;
}