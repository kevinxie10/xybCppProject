#include <iostream>
#include <algorithm>
using namespace std;
int n,a[510],M,m,fa[150010],x,y,cnt;
long long ans;
struct NODE{
    int x,y;
    long long w;
    bool operator<(const NODE &a){
        return w>a.w;
    }
}e[150010];
long long qpow(long long a,long long b){
    long long ans=1;
    while(b){
        if(b&1)ans*=a;
        a*=a;
        ans%=M;
        a%=M;
        b>>=1;
    }
    return ans;
}
int find(int x){
    return fa[x]==x?x:fa[x]=find(fa[x]);
}
int main(){
    scanf("%d%d",&n,&M);
    for(int i=1;i<=n;i++)fa[i]=i,scanf("%d",a+i);
    for(int i=1;i<=n;i++)
        for(int j=i+1;j<=n;j++)
            e[++m]={i,j,(qpow(a[i],a[j])+qpow(a[j],a[i]))%M};
    sort(e+1,e+1+m);
    for(int i=1;i<=m;i++){
        x=find(e[i].x),y=find(e[i].y);
        if(x==y)continue;
        fa[x]=y;
        cnt++;
        ans+=e[i].w;
        if(cnt>=n-1){printf("%lld",ans);return 0;}
    }
    return 0;
}