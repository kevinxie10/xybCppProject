#include <iostream>
using namespace std;
int h,w;
char mp[510][510],mp1[510][510],mp2[510][510];
int main(){
    scanf("%d%d",&h,&w);
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++)mp1[i][j]='.';
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++)mp2[i][j]='.';
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++){
            cin>>mp[i][j];
            if(mp[i][j]=='#'){
                if(i&1)mp1[i][j]='#';
                else mp2[i][j]='#';
            }
        }
    for(int i=0;i<h;i++)mp1[i][0]=mp2[i][w-1]='#';
    for(int i=0;i<h;i+=2)
        for(int j=1;j<w-1;j++)mp1[i][j]='#';
    for(int i=1;i<h;i+=2)
        for(int j=1;j<w-1;j++)mp2[i][j]='#';
    for(int i=0;i<h;i++,printf("\n"))
        for(int j=0;j<w;j++)cout<<mp1[i][j];
    printf("\n");
    for(int i=0;i<h;i++,printf("\n"))
        for(int j=0;j<w;j++)cout<<mp2[i][j];
    return 0;
}