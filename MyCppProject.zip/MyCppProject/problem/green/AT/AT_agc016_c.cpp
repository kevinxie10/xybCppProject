#include <cstdio>
int m,d;
int main(){
    scanf("%d%d",&m,&d);
    printf("%s",(!(m%d)?"YES":"NO"));
    return 0;
}