#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
int n,m,r,x,y,cnt;
vector<int>g[200010];
bool st[200010];
void dfs(int x){
	r=max(x,r),st[x]=true;
    for(auto i:g[x])
        if(!st[i]){
            st[i]=true;
            dfs(i);
    	}
}
int main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		g[x].push_back(y);
		g[y].push_back(x);
	}
	for(int i=1;i<=n;i++){
		if(i<r&&!st[i])cnt++;
		if(!st[i])dfs(i);
	}
	printf("%d",cnt);
	return 0;
}