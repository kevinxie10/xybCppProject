#include <iostream>
using namespace std;
const int P=131,N=1000010;
unsigned long long h[N],p[N];
string s;
int n,a[N],cnt;
bool check(int i){
    for(int j=2;j<n-a[i];j++)
        if(h[a[i]]==h[j+a[i]]-p[a[i]]*h[j])return true;
    return false;
}
int main(){
    cin>>s;
    n=s.length();
    s=' '+s,p[0]=1;
    for(int i=1;i<=n;i++){
        h[i]=h[i-1]*P+s[i];
        p[i]=p[i-1]*P;
    }
    for(int i=1;i<n-1;i++)
        if(h[i]==h[n]-h[n-i]*p[i])a[++cnt]=i;
    int l=0,r=cnt,ans=0;
    while(l<=r){
        int mid=(l+r)>>1;
        if(check(mid))l=mid+1,ans=mid;
        else r=mid-1;
    }
    if(ans)cout<<s.substr(1,a[ans]);
    else puts("Just a legend");
    return 0;
}