#include<iostream>
#include<algorithm>
using namespace std;
long long sum,ans,a1[200010],a2[200010],a[200010],s1[200010],s2[200010],res,n,m;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		res=1e9;
		sum=0;
		scanf("%lld%lld",&n,&m);
		int c1=0,c2=0;
		for(int i=1;i<=n;i++){
			scanf("%lld",a+i);
			sum+=a[i];
		}
		for(int i=1;i<=n;i++){
			int x;
			scanf("%d",&x);
			if(x==1)a1[++c1]=a[i];
			else a2[++c2]=a[i];
		}
		if(sum<m){
			printf("-1\n");
			continue;
		}
		sort(a1+1,a1+1+c1,greater<int>());
		sort(a2+1,a2+1+c2,greater<int>());
		for(int i=1;i<=c1;i++)s1[i]=s1[i-1]+a1[i];
		for(int i=1;i<=c2;i++)s2[i]=s2[i-1]+a2[i];
		for(int i=0;i<=c1;i++){
			int p=lower_bound(s2,s2+1+c2,m-s1[i])-s2;
			if(p==c2+1)continue;
			ans=i+p+p;
			res=min(ans,res);
		}
		printf("%lld\n",res);
	}
	return 0;
}