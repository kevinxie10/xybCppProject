#include <iostream>
#include <map>
#include <ctime>
using namespace std;
const int N=200010;
int T,n,m;
long long x,a[N],b[N],h1[N],l1[N],h2[N],l2[N];
map<pair<long long,long long>,int>mph,mpl;
int main(){
    scanf("%d",&T);
    while(T--){
        srand(time(0));
        mph.clear(),mpl.clear();
        scanf("%d%d",&n,&m);
        for(int i=1;i<=n*m;i++)a[i]=rand(),b[i]=rand();
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++){
                scanf("%lld",&x);
                h1[i]+=a[x];
                h2[i]+=b[x];
                l1[j]+=a[x];
                l2[j]+=b[x];
                if(j==m)mph[{h1[i],h2[i]}]=1,h1[i]=h2[i]=0;
                if(i==n)mpl[{l1[j],l2[j]}]=1,l1[j]=l2[j]=0;
            }
        bool flag=false;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++){
                scanf("%lld",&x);
                h1[i]+=a[x];
                h2[i]+=b[x];
                l1[j]+=a[x];
                l2[j]+=b[x];
                if(j==m){
                    if(!mph[{h1[i],h2[i]}])flag=1;
                    h1[i]=h2[i]=0;
                }
                if(i==n){
                    if(!mpl[{l1[j],l2[j]}])flag=1;
                    l1[j]=l2[j]=0;
                }
            }
        if(flag)puts("NO");
        else puts("YES");
    }
    return 0;
}