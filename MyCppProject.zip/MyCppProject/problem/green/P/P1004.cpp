#include <iostream>
using namespace std;
int n,mp[20][20],dp[20][20][20][20],xx,yy,v;
int main(){
    scanf("%d",&n);
    while(true){
        scanf("%d%d%d",&xx,&yy,&v);
        if(xx==0&&yy==0&&v==0)break;
        mp[xx][yy]=v;
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            for(int x=1;x<=n;x++)
                for(int y=1;y<=n;y++){
                    dp[i][j][x][y]=max(max(dp[i-1][j][x-1][y],dp[i][j-1][x][y-1]),max(dp[i-1][j][x][y-1],dp[i][j-1][x-1][y]))+mp[i][j];
                    if(i!=x&&j!=y)dp[i][j][x][y]+=mp[x][y];
                }
    printf("%d",dp[n][n][n][n]);
    return 0;
}