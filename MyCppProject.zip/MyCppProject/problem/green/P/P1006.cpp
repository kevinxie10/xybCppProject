#include <iostream>
using namespace std;
int n,m,v[60][60],dp[110][60][60];
int main(){
    scanf("%d%d",&m,&n);
    for(int i=1;i<=m;i++)
        for(int j=1;j<=n;j++)scanf("%d",&v[i][j]);
    for(int l=2;l<=n+m;l++)
        for(int y=1;y<=m&&y<l;y++)
            for(int i=1;i<=m&&i<l;i++){
                int x=l-y,j=l-i;
                dp[l][i][y]=max(max(dp[l-1][i][y],dp[l-1][i-1][y]),max(dp[l-1][i][y-1],dp[l-1][i-1][y-1]))+v[i][j];
                if(i!=y||j!=x)dp[l][i][y]+=v[y][x];
            }
    printf("%d",dp[m+n][m][m]);
    return 0;
}