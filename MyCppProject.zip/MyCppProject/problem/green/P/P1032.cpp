#include <iostream>
#include <queue>
#include <map>
#include <string>
using namespace std;
string s,t,x[10],y[10];
int n=1;
struct node{
    string s;
    int step;
};
queue<node>q;
map<string,int>mp;
int main(){
    cin>>s>>t;
    while(cin>>x[++n]>>y[n])n++;
    mp[s]=1;
    if(s==t){printf("0\n");return 0;}
    q.push({s,0});
    while(!q.empty()){
        node k=q.front();
        q.pop();
        string ss=k.s;
        for(int i=1;i<=n;i++){
            int p=k.s.find(x[i]);
            if(p!=-1){
                ss.replace(p,x[i].length()+p,y[i]);
                cout<<ss<<'\n';
                if(ss==t){cout<<k.step+1<<'\n';return 0;}
                if(mp[k.s]==0)q.push({ss,k.step+1});
                mp[ss]=1;
            }
        }
    }
    return 0;
}