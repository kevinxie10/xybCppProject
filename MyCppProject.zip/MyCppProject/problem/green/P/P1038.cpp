#include <iostream>
#include <vector>
#include <queue>
using namespace std;
const int N=110;
int n,p,c[N],u[N],x,y,w,din[N],dout[N];
bool flag; 
vector<pair<int,int>>g[N];
int main(){
	scanf("%d%d",&n,&p);
	for(int i=1;i<=n;i++)
		scanf("%d%d",c+i,u+i);
	for(int i=1;i<=p;i++){
		scanf("%d%d%d",&x,&y,&w);
		g[x].push_back({w,y}),dout[x]++,din[y]++;
	}
	queue<int>q;
	for(int i=1;i<=n;i++){
		if(!din[i])u[i]=0,q.push(i);
		c[i]-=u[i];
	}	
	while(!q.empty()){
		int k=q.front();
		q.pop();
		if(c[k]>0)
			for(auto i:g[k]){
				c[i.second]+=c[k]*i.first;
				if(!--din[i.second])q.push(i.second);
			}
	}
	for(int i=1;i<=n;i++)
		if(!dout[i]&&c[i]>0){
			printf("%d %d\n",i,c[i]);
			flag=true;
		}
	if(!flag)puts("NULL");
	return 0; 
}