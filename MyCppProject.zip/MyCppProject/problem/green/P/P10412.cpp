#include <cstdio>
#include <algorithm>
using namespace std;
const int N=100010;
long long n,p,q,r,a[N],s[N],ans,temp;
int main(){
    scanf("%lld%lld%lld%lld",&n,&p,&q,&r);
    for(int i=1;i<=n;i++)scanf("%lld",a+i);
    for(int i=1;i<=n;i++)s[i]=s[i-1]+a[i];
    if(s[n]>=0){puts("0");return 0;}
    sort(a+1,a+1+n);
    temp=s[n];
    for(int i=1;i<=n-1;i++){
        if(a[i]>=0||temp>=0)break;
        ans+=min(min(-temp,-a[i])*p,q),temp+=-a[i];
    }
    if(temp<0)ans+=p*-temp;
    printf("%lld",ans);
}