#include <iostream>
#include <vector>
using namespace std;
const int N=100010;
int n,a,b,ans,dis1[N],dis0[N];
bool col[N];
vector<int>g[N];
void dfs(int x,int fa){
	(col[x]?dis1[x]:dis0[x])=0;
	for(auto i:g[x]){
		if(i==fa)continue;
		dfs(i,x);
		if(dis0[x]>=0&&dis1[i]>=0)ans=max(ans,dis1[i]+dis0[x]+1);
		if(dis1[x]>=0&&dis0[i]>=0)ans=max(ans,dis0[i]+dis1[x]+1);
		dis1[x]=max(dis1[x],dis1[i]+1);
		dis0[x]=max(dis0[x],dis0[i]+1);
	}
	return ;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",col+i),dis1[i]=dis0[i]=-2147483648;
	for(int i=1;i<n;i++){
		scanf("%d%d",&a,&b);
    	g[a].push_back(b);
    	g[b].push_back(a);
	}
	dfs(1,0);
	printf("%d",ans);
	return 0;
}