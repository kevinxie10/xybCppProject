#include <cstdio>
#include <iostream>
using namespace std;
int fa[30005],ans[30005],num[30005],t,x,y;
char c[3];
int find(int x){
    if(fa[x]==x)return x;
    int f=find(fa[x]);
    ans[x]+=ans[fa[x]];
    return fa[x]=f;
}
void Union(int x,int y){
    int fx=find(x),fy=find(y);
    if(fx==fy)return ;
    fa[fx]=fy;ans[fx]+=num[fy];
    num[fy]+=num[fx];
    return ;
}
int main(){
    scanf("%d",&t);
    for(int i=1;i<=30000;i++)fa[i]=i,num[i]=1;
    while(t--){
        scanf("%s",c);
        scanf("%d%d",&x,&y);
        if(c[0]=='M'){
            int fx=find(x),fy=find(y);
            if(fx!=fy){
                fa[fx]=fy;
                ans[fx]+=num[fy];
                num[fy]+=num[fx];
            }
        }
        else{
            int fx=find(x),fy=find(y);
            if(find(x)!=find(y))printf("-1\n");
            else printf("%d\n",abs(ans[x]-ans[y])-1);
        }
    }
    return 0;
}