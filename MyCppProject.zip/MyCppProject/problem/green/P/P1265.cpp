#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
struct NODE{
    double x,y;
    double dis(const NODE &a){
        return sqrt((x-a.x)*(x-a.x)+(y-a.y)*(y-a.y));
    }
}p[5010];
int n,mnj;
double dis[5010],mni,ans;
bool vis[5010];
int main(){
    scanf("%dis",&n);
    for(int i=1;i<=n;i++)scanf("%lf%lf",&p[i].x,&p[i].y);
    for(int i=2;i<=n;i++)dis[i]=2147483647;
    for(int i=1;i<=n;i++){
        mni=2147483647;
        for(int j=1;j<=n;j++)
            if(!vis[j]&&dis[j]<mni)mnj=j,mni=dis[j];
        ans+=mni;
        vis[mnj]=true;
        for(int j=1;j<=n;j++)
            if(p[j].dis(p[mnj])<dis[j])dis[j]=p[j].dis(p[mnj]);
    }
    printf("%.2lf\n",ans);
    return 0;
}
