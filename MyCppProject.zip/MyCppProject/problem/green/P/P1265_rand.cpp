#include <cmath>
#include <iostream>
#include <algorithm>
#define RAND 1000
using namespace std;
long long n,m,fa[10000010],x,y,cnt,cnt1;
double ans;
struct NODE{
    double x,y;
    bool operator<(const NODE &a){
        return (x==a.x?y<a.y:x<a.x);
    }
    double dis(NODE a){
        return sqrt((x-a.x)*(x-a.x)+(y-a.y)*(y-a.y));
    }
}p[5010];
struct EDGE{
    long long x,y;
    double z;
    bool operator<(const EDGE &a){
        return z<a.z;
    }
}e[10000010];
long long find(long long x){
    return (x==fa[x]?x:fa[x]=find(fa[x]));
}
int main(){
    scanf("%lld",&n);
    for(long long i=1;i<=n;i++)fa[i]=i,scanf("%lf%lf",&p[i].x,&p[i].y);
    sort(p+1,p+1+n);
    for(long long i=1;i<n;i++)
        for(long long j=i+1;j<=min(n,i+RAND);j++){
            cnt++;
            e[cnt].x=i,e[cnt].y=j;
            e[cnt].z=p[i].dis(p[j]);
        }
    sort(e+1,e+1+cnt);
    for(long long i=1;i<=cnt;i++){
        x=find(e[i].x),y=find(e[i].y);
        if(x==y)continue;
        fa[x]=y;
        cnt1++;
        ans+=e[i].z;
        if(cnt1>=n-1){printf("%.2lf",ans);return 0;}
    }
    return 0;
}