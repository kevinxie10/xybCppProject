#include <cstdio>
int a[510],n,m,minn=1e9,sum;

int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        scanf("%d",a+i),minn=(a[i]<minn?a[i]:minn),sum+=a[i];
    for(int k=minn;k<=sum;k++){
        int ans=0,cnt=0;
        for(int i=1;i<=n;i++){
            if(ans+a[i]>k)cnt++,ans=0;
            else ans+=a[i];
        }
        if(cnt<=m){
            printf("1 ");
            for(int i=1;i<=n;i++){
                if(ans+a[i]>k)printf("%d\n%d ",i-1,i);
                else ans+=a[i];
            }
            break;
        }
    }
}