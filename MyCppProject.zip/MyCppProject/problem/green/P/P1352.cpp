#include <iostream>
#include <vector>
using namespace std;
const int N=6010;
int n,r[N],u,v,f[N][2],root=1;//f[N][1或0]表示选或不选u
bool fa[N];
vector<int>g[N];
void dfs(int x){
    f[x][1]=r[x];//选x的快乐指数
    for(auto i:g[x]){
        int child=i;//取x的子节点g[x][i]
        dfs(child);
        f[x][0]+=max(f[child][0],f[child][1]);
        f[x][1]+=f[child][0];
    }
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",r+i);
    for(int i=0;i<n-1;i++){
        scanf("%d%d",&u,&v);
        g[v].push_back(u);
        fa[u]=true;//x有父节点
    }
    while(fa[root])root++;//没有父节点的就是根节点
    dfs(root);
    printf("%d",max(f[root][0],f[root][1]));
    return 0;
}
/*
#include <iostream>
using namespace std;
const int N=6010;
int n,r[N],l,k,u,v,f[N][2],a[N][N],b[N],root=1;
bool fa[N];
void dfs(int x){
    f[x][1]=r[x];
    for(int i=0;i<b[x];i++){
        int child=a[x][i];//取x的子节点
        dfs(child);
        f[x][0]+=max(f[child][0],f[child][1]);
        f[x][i]+=f[child][0];
    }
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",r+i);
    for(int i=0;i<n-1;i++){
        scanf("%d%d",&u,&v);
        a[v][b[v]++]=u;//把y的邻接点x存入数组a，y的邻接点个数存入数组b
        fa[u]=true;//x有父节点
    }
    while(fa[root])root++;
    dfs(root);
    printf("%d",max(f[root][0],f[root][1]));
    return 0;
}
*/