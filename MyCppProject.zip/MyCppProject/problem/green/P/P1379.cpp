#include<iostream>
#include<queue>
#include<map>
#include<string>
using namespace std;
struct node{
	string s;
	int step,z;
}k,t;
int dx[]={-3,-1,1,3};
map<string,bool>f;
queue<node>q;
int main(){
	cin>>k.s;
	k.step=0;
	for(int i=0;i<=8;i++)
		if(k.s[i]=='0'){k.z=i;break;}
	q.push(k);
	while(!q.empty()){
		k=q.front();q.pop();
		t=k;
		if(f[k.s])continue;
		f[k.s]=1;
		if(k.s=="123804765"){cout<<k.step;return 0;}
		for(int i=0;i<4;i++){
			t.z=k.z+dx[i];
			if(t.z<0||t.z>8||(k.z%3==2&&i==2)||(k.z%3==0)&&i==1)continue;
			swap(t.s[t.z],t.s[k.z]);
			t.step=k.step+1;
			q.push(t);
			swap(t.s[t.z],t.s[k.z]);
		}
	}
	return 0;
}