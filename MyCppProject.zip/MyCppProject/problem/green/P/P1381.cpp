#include <iostream>
#include <map>
using namespace std;
map<string,int>sum;
map<string,bool>flag;
int ans1,ans2,n,m,l=1;
string s[100005],s1; 
int main(){
    scanf("%d",&n);
	for(int i=1;i<=n;i++,flag[s1]=true)cin>>s1;
    scanf("%d",&m);
	for(int r=1;r<=m;r++){
		cin>>s[r];
		if(flag[s[r]])sum[s[r]]++;
		if(sum[s[r]]==1)ans1++,ans2=r-l+1;
		while(l<=r){
			if(!flag[s[l]]){l++;continue;}
			if(sum[s[l]]>=2){sum[s[l]]--,l++;continue;}
			break;
		}
		ans2=(r-l+1<ans2?r-l+1:ans2);
	}
    printf("%d\n%d",ans1,ans2);
	return 0;
}