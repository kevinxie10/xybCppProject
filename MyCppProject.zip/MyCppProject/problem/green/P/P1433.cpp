#include <bits/stdc++.h>
#define N 17
struct node{
	double d;
	int num;
};
double x[N],y[N];
bool vis[N];
node dis[N][N];
double minn=100000000.0;
int n;
int l=0;
bool cmp(node a,node b){
	return a.d<b.d;
}
void dfs(int cnt,int now,double sum){
	l++;
	if(l>=30000000){
		int t=clock();
		if(t>=940){
			printf("%.2lf",minn);
			exit(0);
		}
	}
	if(sum>=minn)return;
	if(cnt==n){
		minn=sum<minn?sum:minn;
		return ;
	}
	for(int i=1;i<=n;i++){
		if(vis[dis[now][i].num]==true||now==dis[now][i].num)continue;
		vis[dis[now][i].num]=true;
		dfs(cnt+1,dis[now][i].num,sum+dis[now][i].d);
		vis[dis[now][i].num]=false;
	}
}
int main() {
	scanf("%d",&n);
	for(int i=2;i<=n+1;i++)scanf("%lf%lf",x+i,y+i);
	n++;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++)dis[i][j].d=sqrt((x[j]-x[i])*(x[j]-x[i])+(y[j]-y[i])*(y[j]-y[i])),dis[i][j].num=j;
		std::sort(dis[i]+1,dis[i]+n+1,cmp);
	}
	vis[1]=true;
	dfs(1,1,0.0);
	printf("%.2lf",minn);
	return 0;
}
/*
#include <algorithm>
#include <cmath>
#include <cstdio>
struct Point{
    double x,y;
    double dis(const Point &a){
        return std::sqrt((x-a.x)*(x-a.x)+(y-a.y)*(y-a.y));
    }
}p[20];
double ans,mnans=1e9;
int n,id[20];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%lf%lf",&p[i].x,&p[i].y);
    for(int i=1;i<=n;i++)id[i]=i;
    do{
        for(int i=0;i<n;i++)ans+=p[id[i]].dis(p[id[i+1]]);
        mnans=(ans<mnans?ans:mnans);
        ans=0;
    }while(std::next_permutation(id+1,id+1+n));
    printf("%.2lf",mnans);
    return 0;
}
*/