#include <iostream>
#include <map>
using namespace std;
map<int,int>mp;
int n,p1[100010],p2[100010],dp[100010],len;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",p1+i),mp[p1[i]]=i;
    for(int i=1;i<=n;i++)scanf("%d",p2+i);
    for(int i=1;i<=n;i++){
        if(mp[p2[i]]>dp[len]){
            dp[++len]=mp[p2[i]];
            continue;
        }
        int k=lower_bound(dp+1,dp+1+len,mp[p2[i]])-dp;
        dp[k]=mp[p2[i]];
    }
    printf("%d",len);
    return 0;
}

/*#include<cstring>
#include<iostream>
#include <map>
using namespace std;
map<int,int>mp;
int n,p1[100010],p2[100010],dp[100010];
int main(){
    memset(dp,0x3f3f3f3f,sizeof dp);
    scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",p1+i),mp[p1[i]]=i;
	for(int i=1;i<=n;i++)scanf("%d",p2+i);
	int len=0;
	dp[0]=0;
	for(int i=1;i<=n;i++){
		int l=0,r=len,mid;
		if(mp[p2[i]]>dp[len])dp[++len]=mp[p2[i]];
		else 
		{
		while(l<r){	
		    int mid=(l+r)>>1;
		    if(dp[mid]>mp[p2[i]])r=mid;
			else l=mid+1; 
		}
		dp[l]=(mp[p2[i]]<dp[l]?mp[p2[i]]:dp[l]);
     	}
    }
    printf("%d",len);
    return 0
}*/