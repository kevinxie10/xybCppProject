#include <iostream>
#include <bitset>
using namespace std;
bitset<20>bs;
int n;
int main(){
    scanf("%d",&n);
    for(int i=0;i<(1<<n);i++){
        bs=i;
        for(int j=n-1;j>=0;j--)cout<<bs[j];
        printf("\n");
    }
    return 0;
}