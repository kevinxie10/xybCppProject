#include <cstdio>
#include <algorithm>
long long x,y,m,n,l,xx,yy,g,md;
long long gcd(long long a,long long b){return b?gcd(b,a%b):a;}
void exgcd(long long a,long long b){
    if(b==0){xx=1,yy=0;return ;}
    exgcd(b,a%b);
    long long tmp=xx;
    xx=yy;
    yy=tmp-a/b*yy;
    return ;
}
int main(){
    scanf("%lld%lld%lld%lld%lld",&x,&y,&m,&n,&l);
    g=gcd(m-n,l),md=(l/g<0?-l/g:l/g);
    exgcd(m-n,l);
    if((y-x)%g){printf("Impossible");return 0;}
    printf("%lld",((xx*(y-x)/g)%md+md)%md);
    return 0;
}