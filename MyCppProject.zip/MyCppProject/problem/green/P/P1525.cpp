#include<iostream>
#include<algorithm>
using namespace std;
struct node{
	int x;
    int y;
    int z;
}a[100010];
int fa[40010],n,m;
bool cmp(node a, node b){return a.z>b.z;}
int find(int x){
	if(fa[x]==x)return x;
	return fa[x]=find(fa[x]);
}
void merge(int x,int y){fa[find(x)]=find(y);}
int main(){
    scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].z);
	for(int i=1;i<=n+n;i++)fa[i]=i;
	sort(a+1,a+m+1,cmp);
	for(int i=1;i<=m;i++){
		if(find(a[i].x)==find(a[i].y)){
			printf("%d",a[i].z);
			return 0;
		}
		else{
			merge(a[i].x,a[i].y+n);
			merge(a[i].x+n,a[i].y);
		}
	}
	printf("0");
	return 0;
}