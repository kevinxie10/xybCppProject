#include <iostream>
int l,a,b,c,t,o;
char op;
struct node{
    int l,r,tag;
    bool val;
}tree[100010*3][31];
void build(int i,int l,int r){
    tree[i][1].l=l,tree[i][1].r=r;
    for(int j=1;j<=t;j++)tree[i][j].tag=1e9;
}
int main(){
    scanf("%d%d%d",&l,&t,&o);
    while(o--){
        scanf("%c%d%d",&op,&a,&b);
        if(a>b)std::swap(a,b);
        if(op=='C'){
            scanf("%d",&c);
        }
        else{
        }
    }
}