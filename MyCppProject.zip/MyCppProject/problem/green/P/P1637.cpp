#include <iostream>
#include <algorithm>
#include <cstring>
#define lowbit(x) ((x)&(-(x)))
using namespace std;
const int N=200010;
long long n,m,a[N],c[N],l[N],r[N],st[N],sum,op,x,y,k,ans;
void add(int x){
    for(;x<N;x+=lowbit(x))c[x]++;
}
int find(int x){
    for(sum=0;x>0;x-=lowbit(x))sum+=c[x];
    return sum;
}
int main(){
    scanf("%lld",&n);
    for(int i=1;i<=n;i++)scanf("%lld",a+i);
    for(int i=1;i<=n;i++){
		l[i]=find(a[i]-1);
		add(a[i]);
	}
	memset(c,0,sizeof c);
    for(int i=n;i>=1;i--)r[i]=find(N-1)-find(a[i]),add(a[i]);
	for(int i=1;i<=n;i++){
		ans+=l[i]*r[i]; 
	}
	printf("%lld",ans);
    return 0;
}