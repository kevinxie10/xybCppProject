#include <iostream>
int n,a[100010];
long long sum=0;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i);  
    while(n>3)sum+=std::min((a[1]<<1)+a[n]+a[n-1],a[1]+(a[2]<<1)+a[n]),n-=2;
    if(n==2)sum+=a[2];
    if(n==3)sum+=a[1]+a[2]+a[3];
    printf("%lld",sum);
    return 0;
}