#include<bits/stdc++.h>
#include<algorithm>
#include<iostream>
using namespace std;
const int mxn=1000+10;
int n,a[1010],dpmx[1010][1010],dpmn[1010][1010],mx=0,mn=1e9;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i),a[i+n]=a[i];
    for(int i=2;i<=2*n;i++)a[i]+=a[i-1]; 
    memset(dpmx,0,sizeof dpmx);
    for(int i=2*n-1;i>=1;i--)
        for(int j=i+1;j<=2*n;j++){
			int b=1e9;
            for(int k=i;k<j;k++){
                dpmx[i][j]=max(dpmx[i][j],dpmx[i][k]+dpmx[k+1][j]+a[j]-a[i-1]);
                b=min(b,dpmn[i][k]+dpmn[k+1][j]+a[j]-a[i-1]);
            }
            dpmn[i][j]=b;
        }
    for(int i=1;i<=n;i++)mx=max(mx,dpmx[i][i+n-1]),mn=min(mn,dpmn[i][i+n-1]);
    cout<<mn<<"\n"<<mx;
    return 0;
}