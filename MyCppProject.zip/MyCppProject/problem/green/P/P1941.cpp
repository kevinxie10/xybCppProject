#include <iostream>
#include <cstring>
using namespace std;
const int N=10010;
int n,m,k,x[N],y[N],l[N],h[N],dp[N][2024],p,ans=0x3f3f3f3f,cnt,res;
bool flag[N];
int main(){
    scanf("%d%d%d",&n,&m,&k),cnt=n;
    for(int i=1;i<=n;i++)scanf("%d%d",x+i,y+i),l[i]=1,h[i]=m;
    for(int i=1;i<=k;i++){
        scanf("%d",&p);
        scanf("%d%d",l+p,h+p);
        flag[p]=1,l[p]++,h[p]--;
    }
    memset(dp,0x3f,sizeof dp);
    for(int i=0;i<=m;i++)dp[0][i]=0;
    for(int i=1;i<=n;i++){
        for(int j=x[i]+1;j<=m+x[i];j++)dp[i][j]=min(dp[i-1][j-x[i]],dp[i][j-x[i]])+1;
        for(int j=m+1;j<=m+x[i];j++)dp[i][m]=min(dp[i][j],dp[i][m]);
        for(int j=1;j<=m-y[i];j++)dp[i][j]=min(dp[i-1][j+y[i]],dp[i][j]);
        for(int j=1;j<l[i];j++)dp[i][j]=0x3f3f3f3f;
        for(int j=h[i]+1;j<=m;j++)dp[i][j]=0x3f3f3f3f;
    }
    for(int i=1;i<=m;i++)ans=min(ans,dp[n][i]);
    if(ans<0x3f3f3f3f){printf("1\n%d",ans);return 0;}
	for(int j;cnt>=1;cnt--){
		for(j=1;j<=m&&dp[cnt][j]>=0x3f3f3f;j++);
		if(j<=m)break;
	}
	ans=0;
	for(int j=1;j<=cnt;j++)
		if(flag[j])ans++;
	printf("0\n%d\n",ans);
    return 0;
}