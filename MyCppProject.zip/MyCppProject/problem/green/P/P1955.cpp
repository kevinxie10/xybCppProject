#include <cstdio>
#include <algorithm>
#include <map>
using namespace std;
int t,n;
map<int,int> fa;
struct node{
    int x;
    int y;
    bool flag;
}a[100100];
inline int find(int x){
	if(x==fa[x])return x;
	return fa[x]=find(fa[x]);
}
inline void merge(int x,int y){
	fa[find(x)]=find(y);
	return ;
}
bool cmp(node a,node b){
    return a.flag>b.flag;
}
int main(){
	scanf("%d",&t);
	while(t--){
        fa.clear();
        bool flag=true;
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].flag);
            fa[a[i].x]=a[i].x;
            fa[a[i].y]=a[i].y;
        }
        sort(a+1,a+1+n,cmp);
        for(int i=1;i<=n;i++){
            if(a[i].flag)merge(a[i].x,a[i].y);
            else{
                if(find(a[i].x)==find(a[i].y)){
                    printf("NO\n");
                    flag=false;
                    break;
                }
            }
        }
        if(flag)printf("YES\n");
    }
	return 0;
}