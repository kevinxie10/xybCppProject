#include <cstdio>
#include <iostream>
#include <cstring>
#include <queue>
#include <vector>
#define MAX(x,y) ((x)^(((x)^(y))&(-((x)<(y))))) 
using namespace std;
int t[1010][1010],n,m,ans,rd[1010],x;
bool vis[1010],pd[1010][1010];
queue<pair<int,int>>q;
vector<int>g[1010];
inline int read(){
    char c;
    int num=0;
    while(c=getchar(),c<'0'||c>'9');
    num=c-48;
    while(c=getchar(),c>='0'&&c<='9')num=(num<<3)+(num<<1)+(c^48);
    return num;
}
int main(){
    n=read();m=read();
    for(int i=1;i<=m;i++){
        t[i][0]=read();
        memset(vis,false,sizeof(vis));
        for(int j=1;j<=t[i][0];j++){
            x=read();
            t[i][j]=x;
            vis[x]=true;
        }
        for(int j=t[i][1];j<=t[i][t[i][0]];j++){
            if(vis[j])continue;
            for(int k=1;k<=t[i][0];k++)
                if(!pd[j][t[i][k]]){
                    rd[t[i][k]]++;
                    g[j].push_back(t[i][k]);
                    pd[j][t[i][k]]=true;
                }
        }
    }
    for(int i=1;i<=n;i++)
        if(!rd[i])q.push(make_pair(i,1));
    ans=1;
    while(!q.empty()){
        int u=q.front().first,v=q.front().second+1;
        q.pop();
        for(int i=0;i<g[u].size();i++){;
            if(!(--rd[g[u][i]]))q.push(make_pair(g[u][i],v)),ans=MAX(ans,v);
        }
    }
    printf("%d",ans);
    return 0;
}