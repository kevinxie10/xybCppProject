#include <cstdio>
int n,m,x,ans,a,b=0b1111111111111111111111111111111;//0x7fffffff
char op[5];
int main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s%d",op,&x);
		switch(*op){
			case 'A':a&=x,b&=x;break;
			case 'O':a|=x,b|=x;break;
			case 'X':a^=x,b^=x;break;
		}
	}
	printf("%d %d\n",a,b); 
	for(int i=1;i<=0b111111111111111111111111111111;i<<=1){
		if(a&i)ans+=i;
		else if(b&i&&i<m)ans+=i;
	}
	printf("%d",ans);
	return 0;
}