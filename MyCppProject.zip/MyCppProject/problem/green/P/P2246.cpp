#include <iostream>
#define DP(x) (dp[(x)]=(dp[(x)]+dp[((x)-1)])%1000000007)
using namespace std;
string t,s;
long long dp[11];
int main(){
    while(cin>>t){
        for(int i=0;i<t.size();i++)
            if('A'<=t[i]&&t[i]<='Z')t[i]+='a'-'A';
        s+=t;
    }
    for(int i=0;i<s.length();i++){
        switch(s[i]){
            case 'h':dp[1]++;break;
            case 'e':DP(2);break;
            case 'l':DP(9);DP(4);DP(3);break;
            case 'o':DP(7);DP(5);break;
            case 'w':DP(6);break;
            case 'r':DP(8);break;
            case 'd':DP(10);break;
        }
    }
    printf("%lld",dp[10]);
    return 0;
}