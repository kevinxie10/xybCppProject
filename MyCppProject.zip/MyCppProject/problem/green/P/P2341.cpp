#include <iostream>
#include <vector>
#include <stack>
using namespace std;
const int N=10010;
vector<int>e[N];
stack<int>s;
int dfn[N],low[N],tot,stk[N],scc[N],sz[N],cnt,top,outd[N],n,m,u,v,sum,cnt0;
bool instk[N];
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    //stk[++top]=x;
    s.push(x);
    instk[x]=true;
    for(auto y:e[x]){
        if(!dfn[y])tarjan(y),low[x]=min(low[x],low[y]);
        else if(instk[y])low[x]=min(low[x],dfn[y]);
    }
    if(dfn[x]==low[x]){
        int y;
        cnt++;
        do{
            //y=stk[top--];
            y=s.top();
            s.pop();
            instk[y]=false;
            scc[y]=cnt;
            ++sz[cnt];
        }while(x!=y);
    }
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    while(m--){
        scanf("%d%d",&u,&v);
        e[u].push_back(v);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i])tarjan(i);
    for(int x=1;x<=n;x++)
        for(auto y:e[x])
            if(scc[x]!=scc[y])++outd[scc[x]];
    for(int i=1;i<=cnt;i++)
        if(!outd[i])sum=sz[i],cnt0++;
    if(cnt0>1)sum=0;
    printf("%d",sum);
    return 0;
}