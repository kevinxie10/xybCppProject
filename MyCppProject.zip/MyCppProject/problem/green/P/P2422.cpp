#include <cstdio>
#include <list>
using namespace std;
const int N=1000010;
long long n,a[N],l[N],r[N],sum[N],ans;
list<int>L;
int main(){
    scanf("%lld",&n);
    L.push_back(0);//a[0]=-1e9-10;
    for(int i=1;i<=n;i++){
        scanf("%lld",a+i),sum[i]=a[i]+sum[i-1];
        while(!L.empty()&&a[i]<=a[L.back()])L.pop_back();
        l[i]=L.back(),L.push_back(i);
    }
    while(!L.empty())L.pop_front();
	L.push_back(n+1);
	for(int i=n;i>=1;i--){
		while(!L.empty()&&a[i]<=a[L.back()])L.pop_back();
		r[i]=L.back(),L.push_back(i);
	}
	for(int i=1;i<=n;i++)ans=(a[i]*(sum[r[i]-1]-sum[l[i]])>ans?a[i]*(sum[r[i]-1]-sum[l[i]]):ans);
    printf("%lld\n",ans);
	return 0;
}