#include <cstdio>
#include <cstring>
const int N=15;
long long a,b,f[N][10][10],num[N],ans,n;
long long power(int a,int p){
    long long ans=1;
    while(p){
        if(p&1)ans*=a;
        a*=a;
        p>>=1;
    }
    return ans;
}
void init(){
    for(int i=0;i<10;i++)f[1][i][i]=1;
    for(int i=2;i<N-1;i++)
        for(int j=0;j<10;j++){
            for(int k=0;k<10;k++)
                for(int cnt=0;cnt<10;cnt++)f[i][j][cnt]+=f[i-1][k][cnt];
            f[i][j][j]+=power(10,i-1);
        }
}
long long dp(long long x,int cnt){
    ans=n=0,memset(num,0,sizeof num);
    while(x)num[++n]=x%10,x/=10;
    for(int i=1;i<n;i++)
        for(int j=1;j<10;j++)ans+=f[i][j][cnt];
    for(int i=1;i<num[n];i++)ans+=f[n][i][cnt];
    for(int i=n-1;i>=1;i--){
        for(int j=0;j<num[i];j++)ans+=f[i][j][cnt];
        for(int j=n;j>i;j--)
            if(num[j]==cnt)ans+=num[i]*power(10,i-1);
    }
    return ans;
}
int main(){
    init();
    scanf("%lld%lld",&a,&b);
    for(int i=0;i<10;i++)printf("%lld ",dp(b+1,i)-dp(a,i));
    return 0;
}