#include<cstdio>
const int N=1000010;
long long n,a[N],sum[N],mnq[N],mnz[N],ans;
int main(){
    scanf("%lld",&n),mnq[0]=1e17;mnz[n+1]=1e17;
    for(int i=1;i<=n;i++)scanf("%lld",a+i),sum[i]=sum[i-1]+a[i],mnq[i]=(sum[i]<mnq[i-1]?sum[i]:mnq[i-1]);
    for(int i=n;i>=1;i--)mnz[i]=(sum[i]<mnz[i+1]?sum[i]:mnz[i+1]);
    for(int i=1;i<=n;i++)ans+=((mnz[i]-sum[i-1]>=0)&&(mnq[i-1]+sum[n]-sum[i-1]>=0));
    printf("%lld\n",ans);
    return 0;
}