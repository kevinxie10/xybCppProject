#include <iostream>
using namespace std;
int n,m,x,sum[200010];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("%d",&x);
        x-=m;
        sum[i]=sum[i-1]+x;
    }
    return 0;
}