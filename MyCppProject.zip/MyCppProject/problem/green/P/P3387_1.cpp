#include <iostream>
#include <vector>
#include <stack>
#include <queue>
using namespace std;
const int N=100010;
int n,m,a[N];
vector<int>g[N],newg[N];
int dfn[N],low[N],tot,fa[N],rd[N],dp[N],ans,u,v;
bool in[N];
stack<int>s;
queue<int>q;
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    s.push(x);
    in[x]=true;
    for(auto y:g[x]){
        if(!dfn[y])tarjan(y),low[x]=min(low[x],low[y]);
        else if(in[y])low[x]=min(low[x],low[y]);
    }
    if(dfn[x]==low[x]){
        int y;
        do{
            y=s.top();
            s.pop();
            in[y]=false;
            fa[y]=x;
            if(x!=y)a[x]+=a[y];
        }while(x!=y);
    }
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&u,&v);
        g[u].push_back(v);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i])tarjan(i);
    for(int i=1;i<=n;i++)
        for(auto j:g[i])
            if(fa[i]!=fa[j]){
                newg[fa[i]].push_back(fa[j]);
                rd[fa[j]]++;
            }
    for(int i=1;i<=n;i++)
        if(!rd[i]&&fa[i]==i)q.push(i),dp[i]=a[i];
    while(!q.empty()){
        int k=q.front();
        q.pop();
        for(auto i:newg[k]){
            dp[i]=max(dp[i],dp[k]+a[i]);
            if(!--rd[i])q.push(i);
        }
    }
    for(int i=1;i<=n;i++)ans=max(dp[i],ans);
    printf("%d",ans);
    return 0;
}