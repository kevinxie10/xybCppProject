#include <iostream>
using namespace std;
int a[100010],l[100010],r[100010],n,m,ans;
char c;
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            cin>>c;
            a[j]=(c=='F'?a[j]+1:0);
            l[j]=r[j]=j;
        }
        for(int j=1;j<=m;j++)
            while(a[l[j]-1]>=a[j]&&l[j]!=1)l[j]=l[l[j]-1];
        for(int j=m;j>=1;j--)
            while(a[r[j]+1]>=a[j]&&r[j]!=m)r[j]=r[r[j]+1];
        for(int j=1;j<=m;j++)ans=max((r[j]-l[j]+1)*a[j],ans);
    }
    printf("%d",(ans<<1)+ans);
    return 0;
}