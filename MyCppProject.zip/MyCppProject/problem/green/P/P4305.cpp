#include <bits/stdc++.h>
using namespace std;
inline int read(){
	char c=getchar();
	int x=0,f=1;
	while(c>'9'||c<'0'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0')x=(x<<3)+(x<<1)+(c^48),c=getchar();
	return x*f;
}
int T,n,x;
unordered_map<int,bool>s;
int main(){
	T=read();
	while(T--){
		s.clear(),n=read();
		for(int i=1;i<=n;i++){
			x=read();
			if(!s[x])printf("%d ",x),s[x]=1;
		}
		printf("\n");
	}
	return 0;
}