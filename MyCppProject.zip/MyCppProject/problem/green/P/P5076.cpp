#include <iostream>
#include <algorithm>
#define bx(op) (op##er_bound(((a)+1),((a)+(tot)+1),(x)))
using namespace std;
int q,op,x,tot,a[10010],t;
inline int read(){
	int x=0;
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x;
}
int main(){
    q=read();
    while(q--){
        op=read();
        x=read();
        switch(op){
            case 1:printf("%ld\n",bx(low)-a);break;
            case 2:printf("%d\n",a[x]);break;
            case 3:printf("%d\n",(bx(low)-a==1?-2147483647:a[bx(low)-a-1]));break;
            case 4:printf("%d\n",(bx(upp)-a==tot+1?2147483647:a[bx(upp)-a]));break;
            case 5:{
                t=bx(low)-a;
                if(t==tot+1)a[++tot]=x;
                else{
                    for(int i=tot;i>=t;i--)a[i+1]=a[i];
                    a[t]=x,tot++;
                }
            }
        }
    }
    return 0;
}