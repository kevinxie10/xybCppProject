#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N=50100;
ll c[N][2],ans,n;
struct node{
    int x,v;
}a[N];
bool cmp(const node &a,const node &b){return a.v>b.v;}
int lowbit(int x){return x&-x;}
void add(int x,ll k,int p){
    for(int i=x;i<N;i+=lowbit(i))c[i][p]+=k;
}
ll find(int x,int p){
    ll sum=0;
    for(int i=x;i>0;i-=lowbit(i))sum+=c[i][p];
    return sum;
}
int main(){
    scanf("%lld",&n);
    for(int i=1;i<=n;i++){
        scanf("%d%d",&a[i].v,&a[i].x);
        add(a[i].x,1,0),add(a[i].x,a[i].x,1);
    }
    sort(a+1,a+1+n,cmp);
    for(int i=1;i<=n;i++){
        ll cntl=find(a[i].x-1,0);
        ll cntr=find(N-1,0)-find(a[i].x,0);
        ll suml=find(a[i].x-1,1);
        ll sumr=find(N-1,1)-find(a[i].x,1);
        ans+=(cntl*a[i].x-suml)*a[i].v;
        ans+=(sumr-cntr*a[i].x)*a[i].v;
        add(a[i].x,-1,0);
        add(a[i].x,-a[i].x,1);
    }
    printf("%lld",ans);
    return 0;
}