#include <iostream>
#include <vector>
#include <queue>
using namespace std;
const int N=100010;
int n,k,u,v,din[N],cnt,tong[N],dep[N],mx,ans;
vector<int>g[N],tp;
int main(){
	scanf("%d%d",&n,&k);
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		g[u].push_back(v),din[v]++;
		g[v].push_back(u),din[u]++;
	}
	queue<int> q;
	for(int i=1;i<=n;i++)
		if(din[i]==1)q.push(i);
	while(q.size()){
		int x=q.front();
		q.pop();
		tp.push_back(x);
		for(auto i:g[x])
			if(--din[i]==1){
				q.push(i);
				dep[i]=max(dep[x]+1,dep[i]);
				mx=max(mx,dep[i]);
			}
	}
	for(int i=1;i<=n;i++)tong[dep[i]]++;
	for(int i=mx;i>=0;i--){
		cnt+=tong[i];
		if(cnt>k){printf("%d",i+1);return 0;}
	}
	return 0;
}