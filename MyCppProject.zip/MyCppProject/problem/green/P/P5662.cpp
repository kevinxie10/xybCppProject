#include <cstdio>
#include <cstring>
#define MAX(x,y) (((x)>(y))?(x):(y))
//int n,m,t,k,dp[200010],v[200010],w[200010],g[210][210];
int main(){
    scanf("%d%d%d",&t,&n,&m);
    if(t==1){printf("%d",m);return 0;}
    if(n==1){
        for(int i=1;i<=t;i++){
            scanf("%d",v+i);
            if(i>1&&v[i]>v[i-1]){
                m=(m/v[i-1])*v[i]+m%v[i-1];
            }
        }
        printf("%d",m);
        return 0;
    }
    for(int i=1;i<=t;i++){
        for(int j=1;j<=n;j++){
            scanf("%d",&g[i][j]);
            if(i>1)
                if(g[i][j]>g[i-1][j])
                    for(int k=g[i-1][j];k<=m;k++)
                        dp[k]=MAX(dp[k],dp[k-g[i-1][j]]+g[i][j]-g[i-1][j]);
        }
        m+=dp[m];
        memset(dp,0,sizeof dp);
    }
    printf("%d",m);
    return 0;
}