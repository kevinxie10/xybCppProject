#include <iostream>
using namespace std;
int n,l[2024][2024],r[2024][2024],h[2024][2024],t,ans;
bool vis[2024][2024];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            scanf("%d",&t);
            if(t)l[i][j]=j;
            else{
                vis[i][j]=true;
                h[i][j]=h[i-1][j]+1;
                l[i][j]=l[i][j-1];
            }
        }
        for(int j=n+1;j>=1;j--)r[i][j]=(vis[i][j]?r[i][j+1]:j);
    }
    for(int i=2;i<=n;i++)
        for(int j=1;j<=n;j++)
            if(vis[i][j]&&vis[i-1][j])
                l[i][j]=max(l[i-1][j],l[i][j]),r[i][j]=min(r[i-1][j],r[i][j]);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)ans=max(ans,h[i][j]*(r[i][j]-l[i][j]-1));
    printf("%d",ans);
}