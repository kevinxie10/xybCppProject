#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
long long ans,n,t,tong[100010],x,y;
queue<long long> q1,q2;
long long read(){ 
	long long x=0;
    char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
	return x;
}
long long solve(){
    long long x=0;
	if(q2.empty()||(!q1.empty()&&q1.front()<q2.front()))x=q1.front(),q1.pop();
	else x=q2.front(),q2.pop();
    return x;
}
int main(){
	memset(tong,0,sizeof(tong));
	n=read();
	for(int i=1;i<=n;i++)t=read(),tong[t]++;
	for(int i=1;i<=100000;i++)
		for(int j=1;j<=tong[i];j++)q1.push(i);
	for(int i=1;i<n;i++){
		x=solve(),y=solve();
		ans+=x+y,q2.push(x+y);
	}
	printf("%lld",ans);
	return 0;
}