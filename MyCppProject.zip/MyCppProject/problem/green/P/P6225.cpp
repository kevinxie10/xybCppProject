#include <cstdio>
int n,q,a[200010],op,x,y,ans;
class Tree_Array{
private:
	int lowbit(int x){return x&-x;}
public:
	int fa[200010];
	void add(int x,int k){
	    for(int i=x;i<=n;i+=lowbit(i))fa[i]^=k;
	}
	int find(int x){
    	int sum=0;
    	for(int i=x;i>0;i-=lowbit(i))sum^=fa[i];
    	return sum;
	}
}tree[2];
int main(){
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)scanf("%d",a+i),tree[i&1].add(i,a[i]);
	while(q--){
		scanf("%d%d%d",&op,&x,&y);
		if(op==1)tree[x&1].add(x,y^a[x]),a[x]=y;
		else printf("%d\n",(!((x&1)^(y&1))?tree[x&1].find(y)^tree[x&1].find(x-1):0));
		//1
		//1^2^1^2
		//1^2^3^1^2^2^3^1^2^3
		//1^2^3^4^1^2^2^3^3^4^1^2^3^2^3^4^1^2^3^4
		//1^2^3^4^5^1^2^2^3^3^4^4^5^1^2^3^2^3^4^3^4^5^1^2^3^4^2^3^4^5^1^2^3^4^5 
	}
	return 0;
}
/*
3 3
1 2 3
2 1 3
1 1 3
2 1 3

5 6
1 2 3 4 5
2 1 3
1 1 3
2 1 5
2 4 4
1 1 1
2 4 4
*/