#include <iostream>
#include <string>
#include <stack>
using namespace std;
const int N=1000010;
string s;
stack<int> q;
int g[N][2],k,flag[N],a[N],n,nod[N];
void dfs(int x){
    flag[x]=1;
    if(x<=n)return ;
    if(nod[x]==1){
        if(a[g[x][0]])dfs(g[x][1]);
        if(a[g[x][1]])dfs(g[x][0]);
    }
    if(nod[x]==2){
        if(!a[g[x][0]])dfs(g[x][1]);
        if(!a[g[x][1]])dfs(g[x][0]);
    }
    if(nod[x]==3)dfs(g[x][0]);
    return ;
}
int main(){
    getline(cin,s);
    scanf("%d",&n),k=n;
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    for(int i=0;i<s.length();i++){
        if(s[i]=='x'){
            i++;
            int w=0;
            while(s[i]>='0'&&s[i]<='9')w=w*10+s[i++]-'0';
            q.push(w);
        }
        if(s[i]=='&'){
            int x=q.top();q.pop();
            int y=q.top();q.pop();
            q.push(++k);
            g[k][0]=x,g[k][1]=y,nod[k]=1,a[k]=(a[x]&a[y]);
        }
        if(s[i]=='|'){
            int x=q.top();q.pop();
		    int y=q.top();q.pop();
		    q.push(++k);
		    g[k][0]=x,g[k][1]=y,nod[k]=2,a[k]=(a[x]|a[y]);
        }
        if(s[i]=='!'){
            int x=q.top();q.pop();
		    q.push(++k);
		    g[k][0]=x,nod[k]=3,a[k]=!a[x]; 
        }
    }
    dfs(k);
    int q;
    scanf("%d",&q);
    while(q--){
        int x;
        scanf("%d",&x);
        printf("%d\n",(flag[x]^a[k]));
    }
    return 0;
}


//30分：

/*#include <iostream>
#include <string>
#include <stack>
using namespace std;
string s;
stack<int> st;
int n,a[100010],q;
int main(){
    getline(cin,s);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    scanf("%d",&q);
    while(q--){
        int w;
        scanf("%d",&w);
        for(int i=0;i<s.length();i++){
            if(s[i]=='x'){
                i++;
                int k=0;
                while(s[i]>='0'&&s[i]<='9')k=k*10+s[i++]-'0';
                if(k==w)st.push(!a[k]);
                else st.push(a[k]);
            }
            if(s[i]=='&'){
                int x=st.top();
                st.pop();
                int y=st.top();
                st.pop();
                st.push(x&y);
            }
            if(s[i]=='|'){
                int x=st.top();
                st.pop();
                int y=st.top();
                st.pop();
                st.push(x|y);
            }
            if(s[i]=='!'){
                int x=st.top();
                st.pop();
                st.push(!x);
            }
        }
        printf("%d\n",st.top());
        st.pop();
    }
    return 0;
}*/