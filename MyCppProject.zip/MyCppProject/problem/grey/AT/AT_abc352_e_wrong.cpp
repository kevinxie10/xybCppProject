#include <iostream>
#include <algorithm>
using namespace std;
long long n,m,cnt,k[400010],c[400010],fa[400010],flag[400010],res,ans;
struct NODE{
    long long x,c,flag;//flag 元素x最小的c值
    bool operator<(const NODE &a){
        return (c==a.c&&flag<a.flag||c<a.c);
    }
}e[400010];
inline int find(int x){
    if(fa[x]==x)return x;
    else return fa[x]=find(fa[x]);
}
inline void merge(int x,int y){
    fa[find(x)]=find(y);
    return; 
}
int main(){
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=n;i++)fa[i]=i,flag[i]=1e9;
    for(int i=1;i<=m;i++){
        scanf("%lld%lld",k+i,c+i);
        for(int j=1;j<=k[i];j++){
            scanf("%lld",&e[++cnt].x);
            e[cnt].c=c[i];
            flag[e[cnt].x]=min(flag[e[cnt].x],c[i]);
        }
    }
    sort(e+1,e+1+cnt);
    for(int i=2;i<=cnt;i++){
        if(find(e[i].x)==find(e[i-1].x))continue;
        merge(e[i].x,e[i-1].x);
        ans+=e[i-1].c;
        res++;
    }
    if(res==n-1)printf("%lld",ans);
    else puts("-1");
}