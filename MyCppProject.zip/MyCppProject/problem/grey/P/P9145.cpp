#include <cstdio>
int main(){
    puts("China");
    return 0;
}