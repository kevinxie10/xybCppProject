#include <iostream>
using namespace std;
const int N=1000010;
int n,q,x[N<<1],y[N<<1],w=1000001,op,k;
char c;
int main(){
    scanf("%d%d",&n,&q);
    for(int i=w;i<=n+w;i++)x[i]=i-w+1;
    while(q--){
        scanf("%d",&op);
        if(op==2)scanf("%d",&k),printf("%d %d\n",x[w+k-1],y[w+k-1]);
        else{
            w--;
            cin>>c;
            x[w]=x[w+1];
            y[w]=y[w+1];
            switch(c){
                case 'U':y[w]++;break;
                case 'D':y[w]--;break;
                case 'L':x[w]--;break;
                case 'R':x[w]++;break;
            }
        }
    }
    return 0;
}