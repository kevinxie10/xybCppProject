#include <iostream>
using namespace std;
int n,h[100010],dp[100010];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",h+i);
    dp[2]=abs(h[1]-h[2]);
    for(int i=3;i<=n;i++)dp[i]=min(dp[i-1]+abs(h[i]-h[i-1]),dp[i-2]+abs(h[i]-h[i-2]));
    printf("%d",dp[n]);
    return 0;
}