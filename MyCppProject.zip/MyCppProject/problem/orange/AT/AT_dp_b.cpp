#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
int n,k,dp[100010],h[100010];
int main(){
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)scanf("%d",h+i);
    memset(dp,0x3f,sizeof(dp));
    dp[1]=0;
    for(int i=2;i<=n;i++)
        for(int j=max(1,i-k);j<i;j++)
            dp[i]=min(dp[i],dp[j]+abs(h[i]-h[j]));
    printf("%d",dp[n]);
    return 0;
}