#include <cstdio>
int n,m,b[1010][1010];
char mp[1010][1010];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        scanf("%s",mp[i]+1);
    b[0][1]=1;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++){
            if(mp[i][j]!='#')b[i][j]=(b[i-1][j]+b[i][j-1])%1000000007;
        }
    printf("%d",b[n][m]);
    return 0;
}