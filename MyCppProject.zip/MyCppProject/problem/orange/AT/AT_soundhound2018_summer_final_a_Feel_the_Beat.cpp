#include <iostream>
using namespace std;
long long c,d,l=140,r=170,ans;
int main(){
    scanf("%lld%lld",&c,&d);
    while(l<=d)ans+=max(min(r,d)-max(l,c),0ll),l<<=1,r<<=1;
    printf("%lld\n",ans);
    return 0;
}