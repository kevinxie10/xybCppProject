#include<bits/stdc++.h>
using namespace std;
int n,m,a,l,r;
int c[500010];
int lowbit(int x){return (x&(-x));}
void add(int x,int k){for(int i=x;i<=n;i+=lowbit(i))c[i]+=k;}
int find(int x){
    int sum=0;
    for(int i=x;i>0;i-=lowbit(i))sum+=c[i];
    return sum;
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",&a),add(i,a);
    scanf("%d",&m);
    while(m--){
        scanf("%d%d",&l,&r);
        printf("%d\n",find(r)-find(l-1));
    }
    return 0;
}