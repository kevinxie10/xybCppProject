#include <algorithm>
#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
int t,n,m,u,v;
vector<int>g[500010];
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&m);
        for(int i=1;i<=m;i++){
            scanf("%d%d",&u,&v);
            g[u].push_back(v);
        }
        for(int i=1;i<=n;i++){
            sort(g[i].begin(),g[i].end());
            for(int j=0;j<g[i].size();j++)printf("%d ",g[i][j]);
            printf("\n");
        }
        for(int i=1;i<=n;++i)g[i].clear();
    }
    return 0;
}