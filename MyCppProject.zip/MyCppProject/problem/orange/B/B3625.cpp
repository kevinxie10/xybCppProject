#include <iostream>
#include <queue>
using namespace std;
int dx[]={0,0,-1,1},dy[]={-1,1,0,0};
struct Point{
    int x,y;
};
queue<Point>q;
int n,m;
char mp[110][110];
bool vis[110][110];
void bfs(int x,int y){
    q.push({x,y}),vis[x][y]=true;
    while(!q.empty()){
        Point k=q.front();
        q.pop();
        if(k.x==n&&k.y==m){printf("Yes");return ;}
        for(int i=0;i<4;i++){
            int xx=k.x+dx[i],yy=k.y+dy[i];
            if(mp[xx][yy]=='.'&&!vis[xx][yy])q.push({xx,yy}),vis[xx][yy]=true;
        }
    }
    printf("No");
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)cin>>mp[i][j];
    bfs(1,1);
    return 0;
}