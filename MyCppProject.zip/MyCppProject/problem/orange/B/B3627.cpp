#include <cstdio>
#include <cmath>
long double n;
int main(){
    scanf("%Lf",&n);
    printf("%lld",(long long)std::cbrt(n));
    return 0;
}