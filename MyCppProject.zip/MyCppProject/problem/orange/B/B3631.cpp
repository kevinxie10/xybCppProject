#include<iostream>
using namespace std;
typedef struct NODE{
    int e;
    struct NODE *next;
}T_NODE;
T_NODE *head;
void insert(int x,int y){
    T_NODE *p=head;
    while(p->e!=x&&p->next!=NULL)p=p->next;  //找到x节点，p指向x节点
    T_NODE *q=new T_NODE;
    q->e=y;
    q->next=p->next;
    p->next=q;
}
int whatback_x(int x){
    T_NODE *p=head;
    while(p->e!=x&&p->next!=NULL)p=p->next; //找到x节点，p指向x节点
    if(p->next==NULL)return 0;
    return p->next->e;
}
void deleteback_x(int x){
    T_NODE *p=head;
    while(p->e!=x&&p->next!=NULL)p=p->next; //找到x节点，p指向x节点
    T_NODE *q=p->next;
    p->next=q->next;
    delete q;
}
void deleteALL(){//清空链表
    T_NODE *p=head->next;
    while(p){
        head->next=p->next;
        delete p;
        p=head->next;
    }
    delete head;
}
void printALL(){//调试
    T_NODE *p=head;
    cout<<endl<<"Link: " ;
    while(p){
        cout<<p->e<<" " ;
        p=p->next;
    }
    cout<<endl;
}
int main(){
    head=new T_NODE;
    head->e=1;
    head->next=NULL;
    int n,op,x,y;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>op;
        switch(op){
            case 1:cin>>x>>y;insert(x,y);break;
            case 2:cin>>x;cout<<whatback_x(x)<<endl;break;
            case 3:cin>>x;deleteback_x(x);break;
        }
    }
    deleteALL();
    return 0;
}