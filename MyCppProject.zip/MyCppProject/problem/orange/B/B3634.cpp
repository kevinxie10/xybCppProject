#include <cstdio>
long long Gcd(long long m,long long n){
	if(m==n)return m;
	if(m<n)return Gcd(n,m);
	if(!(m&1))return !(n&1)?Gcd(m>>1,n>>1)<<1:Gcd(m/2,n);
	return !(n&1)?Gcd(m,n/2):Gcd(n,m-n);
}
long long m,n,g;
int main(){
	scanf("%lld%lld",&m,&n);
	g=Gcd(m,n);
	printf("%lld %lld",g,m*n/g);
	return 0;
}