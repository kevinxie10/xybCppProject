#include <iostream>
int n,dp[1000010]={0,1,2,3,4,1,2,3,4,5,2,1};
int main(){
    scanf("%d",&n);
    if(n<=11){printf("%d",dp[n]);return 0;}
    for(int i=12;i<=n;i++){
        dp[i]=std::min(std::min(dp[i-1],dp[i-5]),dp[i-11])+1;
    }
    printf("%d",dp[n]);
    return 0;
}