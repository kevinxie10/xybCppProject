#include <iostream>
int n,dp[1000010]={0,0};
int main(){
    scanf("%d",&n);
    for(int i=2;i<=n;i++)dp[i]=(i&1?dp[i-1]:std::min(dp[i-1],dp[i>>1]))+1;
    printf("%d",dp[n]);
    return 0;
}