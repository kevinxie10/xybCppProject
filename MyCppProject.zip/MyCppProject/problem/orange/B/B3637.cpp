#include<cstdio>
int n,ans,a[5010],dp[5010];
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d",a+i);
    for(int i=0;i<n;i++){
        dp[i]=1;
        for(int j=0;j<i;j++)
            if(a[j]<a[i])dp[i]=(dp[j]+1>dp[i]?dp[j]+1:dp[i]); 
    }
    for(int i=0;i<n;i++)ans=(dp[i]>ans?dp[i]:ans);
    printf("%d",ans);
    return 0;
}