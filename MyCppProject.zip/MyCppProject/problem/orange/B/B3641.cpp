#include <iostream>
using namespace std;
string s1,s2;
int a1,b1,c1,a2,b2,c2;
int stoint(string t){
    if(t.empty()||t=="+")return 1;
    else if(t=="-")return -1;
    else return stoi(t);
}
void solve(string s,int &a,int &b,int &c){
    auto x=s.find('x'),y=s.find('y');
    string t=s.substr(0,x);
    a=stoint(t);
    t=s.substr(x+1,y-x-1);
    b=stoint(t);
    t=s.substr(s.find('=')+1);
    c=stoi(t);
}
int main(){
    cin>>s1>>s2;
    solve(s1,a1,b1,c1);
    solve(s2,a2,b2,c2);
    printf("%d\n%d",(c1*b2-c2*b1)/(a1*b2-a2*b1),(a1*c2-a2*c1)/(a1*b2-a2*b1));
    return 0;
}
