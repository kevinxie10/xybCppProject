#include <iostream>
#include <vector>
#include <queue>
using namespace std;
const int N=110;
int n,t,din[N];
vector<int>g[N],tp;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		while(cin>>t){
			if(t==0)break;
			g[i].push_back(t);
			din[t]++;
		}
	}
	queue<int>q;
	for(int i=1;i<=n;i++){
		if(!din[i])q.push(i);
	}
	while(!q.empty()){
		int k=q.front();
		q.pop();
		tp.push_back(k);
		for(auto i:g[k]){
			if(!--din[i])q.push(i);
		}
	}
	for(auto i:tp)printf("%d ",i);
	return 0;
}