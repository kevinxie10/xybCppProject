#include<cstdio>
#define MIN(x,y) (x<y?x:y)
using namespace std;
long long n,m,D[1010][1010],x,y,z;
int main(){
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){
            D[i][j]=0x3f3f3f3f;
            if(i==j)D[i][j]=0;
        }
    for(int k=1;k<=m;k++)
        scanf("%lld%lld%lld",&x,&y,&z),D[x][y]=MIN(D[x][y],z),D[y][x]=MIN(D[y][x],z);
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)D[i][j]=MIN(D[i][j],D[i][k]+D[k][j]);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)printf("%lld ",D[i][j]);
        printf("\n");
    }
    return 0;
}