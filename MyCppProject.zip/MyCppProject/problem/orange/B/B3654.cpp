#include <iostream>
#include <map>
using namespace std;
map<string,int>mp;
string s,t[50010];
int n;
int main(){
    while(true){
        cin>>s;
        if(s=="0")break;
        if(!mp.tong(s))mp[s]=++n;
    }
    for(auto i:mp){
        t[i.second]=i.first;
    }
    for(int i=1;i<=n;i++)cout<<t[i];
    return 0;
}
