#include <cstdio>
#define V(x,y) cnt>=x&&cnt<y
int n,v[6],t,cnt,ans;
int main(){
    scanf("%d",&n);
    for(int i=0;i<6;i++)scanf("%d",v+i);
    for(int i=1;i<=n;i++){
        scanf("%d",&t);
        if(!t)cnt=0;
        else{
            cnt++;
            if(V(1,3))ans+=v[0];
            else if(V(3,7))ans+=v[1];
            else if(V(7,30))ans+=v[2];
            else if(V(30,120))ans+=v[3];
            else if(V(120,365))ans+=v[4];
            else ans+=v[5];
        }
    }
    printf("%d",ans);
    return 0;
}
