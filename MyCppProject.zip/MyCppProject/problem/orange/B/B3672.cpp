#include <iostream>
#include <string>
using namespace std;
int n,q,len,cnt;
string book[1010],s;
int main(){
    scanf("%d%d",&n,&q);
    for(int i=0;i<n;i++)cin>>book[i];
    for(int i=0;i<q;i++){
        cin>>len>>s;
        for(int j=0;j<n;j++){
            if(book[j].rfind(s)!=string::npos&&book[j].rfind(s)==book[j].length()-len)cnt++;
        }
        printf("%d\n",cnt);
        cnt=0;
    }
    return 0;
}