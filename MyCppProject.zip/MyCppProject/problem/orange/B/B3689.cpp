#include <iostream>
#include <vector>
using namespace std;
int n,k;
string s;
int main(){
    cin>>n>>s>>k;
    vector<int>a(n);
    for(int i=n-s.length(),t=n-s.length();i<n;i++)a[i]=s[i-t]-'0';
    for(int i=0;i<n;i++){
        if(a[i])
    }
}