#include <iostream>
using namespace std;
string s,t;
int main(){
    cin>>s>>t;
    printf("%s",(s>t?"abcdefghijklmnopqrstuvwxyz":"zyxwvutsrqponmlkjihgfedcba"));
    return 0;
}