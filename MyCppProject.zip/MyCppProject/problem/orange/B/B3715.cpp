#include <cstdio>
long long t,n;
int main(){
    scanf("%lld",&t);
    while(t--){
        scanf("%lld",&n);
        if(n==1){printf("1\n");continue;}
        for(long long i=2;i*i<=n;i++)
            if(n%i==0)
                while(n%i==0)printf("%lld ",i),n/=i;
        if(n>1)printf("%lld",n);
        printf("\n");
    }
    return 0;
}