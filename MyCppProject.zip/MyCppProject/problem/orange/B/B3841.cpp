#include <cmath>
#include <cstdio>
int t,n,nn,p,sum;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n),sum=p=0,nn=n;
        while(nn)nn/=10,p++;
        nn=n;
        while(nn)sum+=std::pow(nn%10,p),nn/=10;
        printf("%c\n",(sum==n?'T':'F'));
    }
    return 0;
}