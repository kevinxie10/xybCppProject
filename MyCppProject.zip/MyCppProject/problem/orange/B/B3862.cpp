#include <iostream>
#include <vector>
using namespace std;
int n,m,u,v,mx;
vector<int>g[1010];
void dfs(int x){
    mx=max(mx,x);
    for(int i:g[x])dfs(i);
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&u,&v);
        g[u].push_back(v);
    }
    for(int i=1;i<=n;i++){
        dfs(i);
        printf("%d ",mx);
        mx=0;
    }
    return 0;
}