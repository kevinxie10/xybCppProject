#include <iostream>
using namespace std;
string s,t;
int n,k;
void work(){
	cin>>n>>s>>t;
	int sum=0,c1=-1,c2=-1;
	for(int i=0;i<n;i++){
		if(s[i]!=t[i])sum++,(c1==-1?c1=i:c2=i);
		if(sum>2){printf("No\n");return;}
	}
	if(sum!=2){printf("No\n");return;}
	if(s[c1]==s[c2]&&t[c2]==t[c1]){printf("Yes\n");return;}
	printf("No\n");
}
int main(){
	cin>>k;
	while(k--)work();
	return 0;
}