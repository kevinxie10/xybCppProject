#include <cstdio>
int t,n,a[60];
bool flag;
int main(){
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		flag=false;
		scanf("%d%d",a+1,a+2);
		if(n==2){puts("YES");continue;}
		for(int i=3;i<=n;i++)scanf("%d",a+i);
		for(int i=3;i<=n;i++)
			if((a[i]&1)^(a[((i&1)^1)+1]&1)){puts("NO");flag=true;break;}
		if(!flag)puts("YES");
	}
	return 0;
}