#include <iostream>
#include <string>
using namespace std;
int t,n;
string s,ss;
bool flag;
int main(){
	scanf("%d",&t);
	while(t--){
		cin>>n>>s;
		flag=false; 
		if(s.find('R')==string::npos&&s.find('B')==string::npos){
			puts("YES");
			continue;
		}
		auto p=s.find('W');
		if(p==string::npos){
			if(s.find('R')==string::npos||s.find('B')==string::npos)puts("NO");
			else puts("YES");
			continue;
		}
		s="W"+s+"W";
		while(!s.empty()){
			auto p=s.find('W');
			if(p==string::npos)break;
			cout<<p<<endl<<s<<endl;
			for(int i=p+1;s[i]=='W';i++){
				cout<<s<<endl;
				s.erase(i,1);
			}
			ss=s.substr(0,p);
			if(ss.empty())break;
			s.erase(0,s.find('W')+1);
			cout<<ss<<endl<<s<<endl;
			if(ss.find('R')==string::npos||ss.find('B')==string::npos){
				puts("NO");
				flag=true;
				break;
			}
		}
		if(!flag)puts("YES");
	}
	return 0;
}