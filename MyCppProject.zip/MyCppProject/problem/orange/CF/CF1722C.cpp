#include <iostream>
#include <map>
using namespace std;
int q,n,cnt,score[3];
string s[3][1010];
map<string,bool>c[3];
int main(){
	scanf("%d",&q);
	while(q--){
		scanf("%d",&n);
		for(int i=0;i<3;i++)
			for(int j=0;j<n;j++){
				cin>>s[i][j];
				c[i][s[i][j]]=true;
			}
		for(int i=0;i<3;i++)
			for(int j=0;j<n;j++){
				for(int k=0;k<3;k++)
					if(k!=i&&c[k][s[i][j]])cnt++;
				if(cnt==0)score[i]+=3;
				else if(cnt==1)score[i]++;
				//printf("i=%d cnt=%d   ",i,cnt);
				//for(int i=0;i<3;i++)printf("%d ",score[i]);
				//puts(""); 
				cnt=0;
				
			}
		for(int i=0;i<3;i++)printf("%d ",score[i]),score[i]=0;
		for(int i=0;i<3;i++)c[i].clear();
		puts("");
	}
	return 0;
}