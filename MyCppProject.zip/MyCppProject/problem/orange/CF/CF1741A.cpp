#include<cstdio>
#include<cstring>
/int t,zip1,zip2,len1,len2;
//char s1[105],s2[105];
int main(){
	scanf("%d",&t);
	while(t--){
		scanf("%s%s",s1,s2);
		len1=strlen(s1),len2=strlen(s2);
		if(s1[len1-1]=='M')zip1=0;
		if(s1[len1-1]=='S')zip1=-len1;
		if(s1[len1-1]=='L')zip1=len1;
		if(s2[len2-1]=='M')zip2=0;
		if(s2[len2-1]=='S')zip2=-len2;
		if(s2[len2-1]=='L')zip2=len2;
		if(zip1<zip2)printf("<\n");
		if(zip1>zip2)printf(">\n");
        if(zip1==zip2)printf("=\n");
	}
	return 0;
}