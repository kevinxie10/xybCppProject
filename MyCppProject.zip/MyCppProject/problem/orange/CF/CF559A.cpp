#include <cstdio>
#include <algorithm>
int a[10];
int main(){
    for(int i=0;i<6;i++)scanf("%d",a+i);
    int n=a[0]+a[1]+a[2];//(1+(n*2-1))*n/2==n*n
    printf("%d",n*n-a[0]*a[0]-a[2]*a[2]-a[4]*a[4]);
    return 0;
}