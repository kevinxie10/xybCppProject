#include <cstdio>
int n,fx[100010],fy[100010],ex[100010],ey[100010],x,y,ans=-1;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d%d%d%d",fx+i,fy+i,ex+i,ey+i);
        ex[i]+=fx[i],ey[i]+=fy[i];
    }
    scanf("%d%d",&x,&y);
    for(int i=1;i<=n;i++)
        if(fx[i]<=x&&ex[i]>=x&&fy[i]<=y&&ey[i]>=y)ans=i;
    printf("%d",ans);
    return 0;
}