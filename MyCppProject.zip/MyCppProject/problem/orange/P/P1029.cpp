#include<cstdio>
#include<cmath>
long long m,n,ans;
long long Gcd(long long m,long long n){
	if(m==n)return m;
	if(m<n)return Gcd(n,m);
	if(!(m&1))return !(n&1)?Gcd(m>>1,n>>1)<<1:Gcd(m/2,n);
	return !(n&1)?Gcd(m,n/2):Gcd(n,m-n);
}
int main(){
    scanf("%lld%lld",&m,&n),ans-=(m==n),n*=m;
	for(long long i=1,k=sqrt(n);i<=k;i++)
        if(!(n%i)&&Gcd(i,n/i)==m)ans+=2;
    printf("%lld",ans);
	return 0;
}