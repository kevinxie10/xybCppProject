#include<stdio.h>
const int c[10]={6,2,5,5,4,5,6,3,7,6};
int a[2023]={6},n,s;
int main(){
    scanf("%d",&n);
    for(int i=1,j=1;i<=2000;j=++i)
        while(j>=1)a[i]+=c[j%10],j=j/10;
    for(int i=0;i<=1000;i++)
        for(int j=0;j<=1000;j++)s+=(a[i]+a[j]+a[i+j]+4==n);
    printf("%d",s);
    return 0;
}