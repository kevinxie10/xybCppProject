#include <cstdio>
#include <algorithm>
int n;
long long t,ans;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%lld",&t),ans^=t;
	printf("%lld",ans);
	return 0;
}