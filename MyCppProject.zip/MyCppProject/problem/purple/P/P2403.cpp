#include <algorithm>
#include <iostream>
#include <map>
#include <queue>
using namespace std;
const int N=1e5+10,V=N<<1,E=1e6+10,dx[8]={0,0,1,1,1,-1,-1,-1},dy[8]={1,-1,-1,0,1,-1,0,1};
struct edge{
    int nxt,to;
}e[E],ne[E];
int fir[V],nfir[V],cnt,ncnt,row[N],col[N],totr,totc,n,r,c,x[N],y[N],opt[N],dfn[V],clo,_cnt,trea[V],sta[V],bel[V],top,ind[V],dist[V],ans;
bool inq[V];
queue<int>q;
map<pair<int,int>,int>point;
inline void add(int x,int y){
    e[++cnt].to=y;
    e[cnt].nxt=fir[x];
    fir[x]=cnt;
    return ;
}
inline void nadd(int x,int y){
    ne[++ncnt].to=y;
    ne[ncnt].nxt=nfir[x];
    nfir[x]=ncnt;
    return ;
}
inline int dfs(int u){
    dfn[u]=++clo;
    int lowu=dfn[u],lowv,v;
    sta[++top]=u;
    for(int i=fir[u];i;i=e[i].nxt){
        v=e[i].to;
        if(!dfn[v]){lowv=dfs(v);lowu=min(lowu,lowv);}
        else if(!bel[v])lowu=min(lowu,dfn[v]);
    }
    if(lowu==dfn[u]){
        int cur=0;
        _cnt++;
        while(cur!=u){
            cur=sta[top--];
            bel[cur]=_cnt;
            if(cur<=n)trea[_cnt]++;
        }
    }
    return lowu;
}
int main(){
    scanf("%d%d%d",&n,&r,&c);
    for(int i=1;i<=n;i++){
        scanf("%d%d%d",x+i,y+i,opt+i);
        if(opt[i]==1)row[++totr]=x[i];
        if(opt[i]==2)col[++totc]=y[i];
        point[make_pair(x[i],y[i])]=i;
    }
    sort(row+1,row+totr+1);
    totr=unique(row+1,row+totr+1)-row-1;
    sort(col+1,col+totc+1);
    totc=unique(col+1,col+totc+1)-col-1;
    int p,nx,ny;
    for(int i=1;i<=n;i++){
        p=lower_bound(row+1,row+totr+1,x[i])-row;
        if(row[p]==x[i]){
            add(n+p,i);
            if(opt[i]==1)add(i,n+p);
        }
        p=lower_bound(col+1,col+totc+1,y[i])-col;
        if(col[p]==y[i]){
            add(n+totr+p,i);
            if(opt[i]==2)add(i,n+totr+p);
        }
        if(opt[i]==3){
            for(int j=0;j<9;j++){
                nx=x[i]+dx[j],ny=y[i]+dy[j];
                if(!point.tong(make_pair(nx,ny)))continue;
                p=point[make_pair(nx,ny)];
                add(i,p);
            }
        }
    }
    for(int i=1;i<=n;i++)if(!dfn[i])dfs(i);
    for(int i=1;i<=n+totc+totr;i++){
        for(int j=fir[i];j;j=e[j].nxt){
            int u=e[j].to;
            if(bel[i]!=bel[u])nadd(bel[i],bel[u]),ind[bel[u]]++;
        }
    }
    for(int i=1;i<=_cnt;i++)
        if(!ind[i])q.push(i),inq[i]=1,dist[i]=trea[i];
    int u,v;
    while(!q.empty()){
        u=q.front();inq[u]=0;q.pop();
        for(int i=nfir[u];i;i=ne[i].nxt){
            v=ne[i].to;
            if(dist[v]<dist[u]+trea[v]){
                dist[v]=dist[u]+trea[v];
                if(!inq[v]){inq[v]=1;q.push(v);}
            }
        }
    }
    for(int i=1;i<=_cnt;i++)ans=max(ans,dist[i]);
    printf("%d",ans);
    return 0;
}
