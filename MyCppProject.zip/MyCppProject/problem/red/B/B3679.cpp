#include <cstdio>
#include <cmath>
struct Machine{
    double x,y;
    bool flag;
    double dis(const Machine &a){
        return sqrt((x-a.x)*(x-a.x)+(y-a.y)*(y-a.y));
    }
}a[1010];
int n,k,T,mxp,ans;
double mx,u,v;
int main(){
    scanf("%d%d%d",&n,&k,&T);
    for(int i=1;i<=n;i++)scanf("%lf%lf",&a[i].x,&a[i].y);
    for(int i=1;i<=k;i++){
        scanf("%lf%lf",&u,&v);
        for(int j=1;j<=n;j++)
            if(a[j].x==u&&a[j].y==v){a[j].flag=true;break;}
    }
    while(T--){
        scanf("%lf%lf",&u,&v),mx=-1;
        for(int i=1;i<=n;i++)
            if(a[i].dis({u,v})>mx)mx=a[i].dis({u,v}),mxp=i;
        if(a[mxp].flag)ans++;
    }
    printf("%d",ans);
    return 0;
}
