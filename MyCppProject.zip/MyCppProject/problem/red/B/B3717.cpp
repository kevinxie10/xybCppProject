#include <cstdio>
#include <cmath>
int n,m,r,cnt,x,y;
bool vis[110][110];
int main(){
    scanf("%d%d%d",&n,&m,&r);
    while(m--){
        scanf("%d%d",&x,&y),vis[x][y]=1;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(sqrt((x-i)*(x-i)+(y-j)*(y-j))<=r)vis[i][j]=true;
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            if(vis[i][j])cnt++;
    printf("%d",cnt);
    return 0;
}
