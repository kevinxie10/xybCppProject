#include <iostream>
using std::max;
long long n,a[500010];
long long max(long long a[],long long l,long long r){
    long long mx=-214748368;
    for(long long i=l;i<=r;i++)mx=max(mx,a[i]);
    return mx;
}
long long M(long long l,long long r){
    if(abs(r-l)>5)return M(l,(l+r)>>1)%max(M(((l+r)>>1)+1,r),7LL)+a[(l+r)>>1]-1;
    else return max(a,l,r);
}
int main(){
    scanf("%lld",&n);
    for(long long i=1;i<=n;i++)scanf("%lld",a+i);
    printf("%lld",M(1,n));
    return 0;
}
