#include <cstdio>
int sum,s1,s2,s3;
int main(){
    for(int i=1,s;i<=8;i++)scanf("%d",&s),s1+=s,sum+=s;
    if(s1<80){printf("%d",sum);return 0;}
    for(int i=1,s;i<=4;i++)scanf("%d",&s),s2+=s,sum+=s;
    if(s2<40){printf("%d",sum);return 0;}
    for(int i=1,s;i<=3;i++)scanf("%d",&s),sum+=s;
    printf("%d",sum);
    return 0;
}