#include<cstdio>
int a,b,odd,even,ans;
bool flag=true;
int main(){
    scanf("%d%d",&a,&b);
	for(int i=a,p=a;i<=b;ans+=(odd==even),i++,p=i,odd=even=0)
		while(p>0){
			if(flag)odd+=p%10,flag=false;
			else even+=p%10,flag=true;
			p/=10;
        }
    printf("%d",ans);
    return 0;
}