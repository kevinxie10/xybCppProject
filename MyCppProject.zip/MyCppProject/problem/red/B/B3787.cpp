#include <cstdio>
int h1,m1,s1,ms1,h2,m2,s2,ms2;
int main(){
    scanf("%d:%d:%d.%d",&h1,&m1,&s1,&ms1);
    scanf("%d:%d:%d.%d",&h2,&m2,&s2,&ms2);
    printf("%d",(((h2-h1)*60+m2-m1)*60+s2-s1)*100+ms2-ms1);
    return 0;
}