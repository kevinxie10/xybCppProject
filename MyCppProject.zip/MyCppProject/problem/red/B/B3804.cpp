#include <cstdio>
int a,b,c;
int main(){
    scanf("%d%d%d",&a,&b,&c);
    printf("%s",(a+b+c<=100&&!(b%5)&&!(c%7)&&a-b>b-c?"Yes":"No"));
    return 0;
}
