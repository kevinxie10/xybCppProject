#include <cstdio>
int n,t,ans;
bool tong[1000010];
int main(){
    scanf("%d",&n);
    while(n--){
        scanf("%d",&t);
        tong[t]=true;
    }
    for(int i=1;i<=1000000;i++)ans+=tong[i];
    printf("%d",ans);
    return 0;
}
