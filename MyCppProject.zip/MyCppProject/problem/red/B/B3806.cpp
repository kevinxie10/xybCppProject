#include <iostream>
using namespace std;
long long y,w;
char x,z;
int main(){
    cin>>x>>y>>z>>w;
    printf("%s\n",(x==z&&x>='a'&&x<='z'?"valid":"Invalid"));
    printf("%lld",(x==z&&x>='a'&&x<='z'?(y<=w?w-y+1:y-w+1):-1));
    return 0;
}
