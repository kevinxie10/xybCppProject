#include <cstdio>
int n,a[500010],b[500010],k;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d%d",a+i,b+i);
    for(int i=2;i<=n;i++)k=(a[i]-a[i-1]-b[i-1]>k?a[i]-a[i-1]-b[i-1]:k);
    printf("%d",k);
    return 0;
}
