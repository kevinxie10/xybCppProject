#include <cstdio>
int n,k,a[2024],p[20];
int main(){
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n<<1;i++)scanf("%d",a+i),p[i%k]+=a[i];
    for(int i=1;i<=n<<1;i++)
        printf("%d ",(i&1?p[i%k]%i:a[i]));
    return 0;
}
