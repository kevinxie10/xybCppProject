#include <cstdio>
int n,cnt;
int main(){
    scanf("%d",&n);
    for(int i=1;i*i<=n;i++)
        if(!(n%i))cnt++;
    printf("%d",cnt);
    return 0;
}