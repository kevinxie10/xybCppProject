#include <cstdio>
const int m[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int a,b;
int main(){
    scanf("%d%d",&a,&b);
    printf("%d",(b==2?(a%4==0&&a%100||a%400==0?29:28):m[b]));
    return 0;
}