#include <cstdio>
int x,y,z,n,m,c;
int main(){
    scanf("%d%d%d%d%d",&x,&y,&z,&n,&m);
    for(int i=0;i<=m;i++)
        for(int j=0;j<=m-i;j++){
            int k=m-i-j;
            if(i*x+j*y+k/(double)z==n)c++;
        }
    printf("%d",c);
    return 0;
}