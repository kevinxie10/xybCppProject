#include <cstdio>
int n,p;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++,puts(""))
        for(int j=1;j<=i;j++)printf("%c",'A'+p++),p%=26;
}