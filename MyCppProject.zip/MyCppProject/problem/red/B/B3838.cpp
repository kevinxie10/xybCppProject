#include <cstdio>
int h1,m1,h2,m2;
int main(){
    scanf("%d%d%d%d",&h1,&m1,&h2,&m2);
    printf("%d",(m1>m2)?(60*(h2-h1-1)+m2-m1+60):(60*(h2-h1)+m2-m1));
    return 0;
}