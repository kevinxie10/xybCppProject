#include <cstdio>
#include <cstring>
int a,b,prime[1010],cnt,c;
bool isprime[1010];
void init(int n){
    memset(isprime,1,sizeof isprime);
    isprime[0]=isprime[1]=false;
    for(int i=2;i<=n;i++){
        if(isprime[i])prime[++cnt]=i;
        for(int j=1;j<=cnt&&i*prime[j]<=n;j++){
            isprime[i*prime[j]]=false;
            if(i%prime[j]==0)break;
        }
    }
    return ;
}
int main(){
    scanf("%d%d",&a,&b);
    init(b);
    for(int i=a;i<=b;i++)c+=isprime[i];
    printf("%d",c);
    return 0;
}