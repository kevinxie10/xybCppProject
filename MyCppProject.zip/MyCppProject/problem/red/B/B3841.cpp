#include <cstdio>
#include <cmath>
int t,n,sum,nn,num[10],cnt,cntt;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n),sum=cnt=0,nn=n;
        while(nn)num[cnt++]+=(nn%10),nn/=10;
        cntt=cnt;
        while(cntt)sum+=pow(num[cntt--],cnt);
        if(sum==n)printf("T\n");
        else printf("F\n");
    }
    return 0;
}