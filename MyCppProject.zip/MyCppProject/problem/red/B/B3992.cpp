#include <cstdio>
int n,a[1010],sum,cnt;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",a+i);
        if(a[i]%10!=3&&a[i]%3)sum+=a[i],cnt++;
    }
    printf("%d %d",sum,cnt);
    return 0;
}