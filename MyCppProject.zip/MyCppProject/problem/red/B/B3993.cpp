#include <cstdio>
const int month[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int m,d;
int main(){
    scanf("%d%d",&m,&d);
    if(d==month[m]){
        if(m==12)puts("1 1");
        else printf("%d 1",m+1);
    }
    else printf("%d %d",m,d+1);
    return 0;
}