#include <cstdio>
long long n;
int main(){
    scanf("%lld",&n);
    printf("%lld\n%lld",4*n+n*(n-1),n*(n+1)*(2*n+1)/6);
    return 0;
}