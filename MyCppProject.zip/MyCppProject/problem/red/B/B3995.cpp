#include <cstdio>
int n;
int main(){
    scanf("%d",&n);

    printf("|");
    for(int j=2;j<n;j++)printf("-");
    puts("|");

    for(int i=2;i<n;i++){
        printf("|");
        if(i==(n+1)>>1){
            for(int j=2;j<n;j++)
                if(j==(n+1)>>1)printf("x");
                else printf("-");
        }
        else{
            for(int j=2;j<n;j++){
                if(j==(n+1)>>1)printf("|");
                else printf("x");
            }
        }
        puts("|");
    }

    printf("|");
    for(int j=2;j<n;j++)printf("-");
    puts("|");
    return 0;
}