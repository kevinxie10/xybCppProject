#include <cstdio>
#include <cmath>
int n,q,m,x,t,len,ans[1000010],tot;
int main(){
    scanf("%d%d%d",&n,&m,&q);
    while(q--){
        x=n%10,t=n/10,len=-1;
        while(n)n/=10,len++;
        n=(x*x)%10*pow(10,len)+t;
        ans[++tot]=n;
        if(n==m){
            for(int i=1;i<=tot;i++)printf("%d\n",ans[i]);
            return 0;
        }
    }
    puts("-1");
    return 0;
}