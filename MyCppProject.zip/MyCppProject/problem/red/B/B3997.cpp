#include <iostream>
using namespace std;
int cnt,p;
string s,t;
bool huiwen(string t){
    for(int i=0;i<(t.length()>>1);i++)
        if(t[i]!=t[t.length()-i-1])return false;
    return true;
}
int main(){
    cin>>s;
    for(int i=1;p+i<s.length();i++)
        cnt+=huiwen(s.substr(p,i)),p+=i;
    cnt+=huiwen(s.substr(p,s.length()-p));
    printf("%d",cnt);
    return 0;
}