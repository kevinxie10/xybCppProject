#include <cstdio>
int h,m;
int main(){
    scanf("%d:%d",&h,&m);
    if(6<=h){printf("%02d:%02d",h,m);return 0;}
    printf("%02d:%02d",h+24,m);
    return 0;
}