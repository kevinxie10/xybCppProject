#include <cstdio>
int n,l,r,ans;
bool f;
int main(){
    scanf("%d%d",&n,&l);
    for(int i=1;i<n;i++){
        scanf("%d",&r);
        if(r<l)f=true;
        if(r>l&&f==true)ans++,f=false;
        l=r;
    }
    printf("%d",ans);
    return 0;
}