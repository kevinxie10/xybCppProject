#include<cstdio>
bool flag;
int k;
int main(){
    scanf("%d",&k);
    for(int i=10000;i<=30000;i++)
        if(!(i/100%k))
          if(!((i/10-i/10000*1000)%k))
            if(!((i-i/1000*1000)%k))printf("%d\n",i),flag=true;
    if(!flag)printf("No");
    return 0;
}