#include <cstdio>
long long xl,xr,yl,yr;
int main(){
    scanf("%lld%lld%lld%lld",&xl,&xr,&yl,&yr);
    if(xl*yl<-2147483648||xr*yr<-2147483648||xl*yr<-2147483648||xr*yl<-2147483648||xl*yl>2147483647||xl*yr>2147483647||xr*yl>2147483647||xr*yr>2147483647)printf("long long int");
    else printf("int");
    return 0;
}