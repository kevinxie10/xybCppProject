#include <cstdio>
int xz,xm,yz,ym;
int Gcd(int m,int n){
	if(m==n)return m;
	if(m<n)return Gcd(n,m);
	if(!(m&1))return !(n&1)?Gcd(m>>1,n>>1)<<1:Gcd(m/2,n);
	return !(n&1)?Gcd(m,n/2):Gcd(n,m-n);
}
int main(){
    scanf("%d/%d %d/%d",&xz,&xm,&yz,&ym);
    int nz=xz*yz,nm=xm*ym;
    printf("%d %d",nm/Gcd(nz,nm),nz/Gcd(nz,nm));
    return 0;
}