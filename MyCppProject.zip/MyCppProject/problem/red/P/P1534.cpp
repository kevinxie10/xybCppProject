#include <cstdio>
long long n,xue,ban,sum,cnt;
int main(){
    scanf("%lld",&n);
    for(int i=0;i<n;i++){
        scanf("%lld%lld",&xue,&ban);
        cnt=cnt+xue+ban-8;
        sum+=cnt;
    }
    printf("%lld",sum);
    return 0;
}