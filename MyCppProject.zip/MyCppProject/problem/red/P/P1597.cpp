#include<cstdio>
int a[3];
char op1,op2;
int main(){
    while(scanf("%c:=%c;",&op1,&op2)==2)a[op1-'a']=(op2>='0'&&op2<='9'?op2-'0':a[op2-'a']);
    for(int i=0;i<3;i++)printf("%d ",a[i]);
    return 0;
}