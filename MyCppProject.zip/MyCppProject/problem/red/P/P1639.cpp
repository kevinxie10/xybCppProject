#include <iostream>
using namespace std;
int a,b,x,y;
int main(){
    scanf("%d%d%d%d",&a,&b,&x,&y);
    printf("%d",min(abs(a-b),abs(min(a,b)-min(x,y))+abs(max(a,b)-max(x,y))));
    return 0;
}