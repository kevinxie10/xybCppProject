#include <cstdio>
#include <cstring>
int n,l[110],r[110],mx,sum;
bool vis[100010];
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d%d",l+i,r+i);
    }
    for(int i=0;i<n;i++){
        memset(vis,0,sizeof vis);
        for(int j=0;j<n;j++){
            if(j==i)continue;
            for(int k=l[j];k<r[j];k++)vis[k]=true;
        }
        sum=0;
        for(int i=0;i<1000;i++)sum+=vis[i];
        mx=(mx<sum?sum:mx);
    }
    printf("%d",mx);
    return 0;
}