#include <cstdio>
struct city{
    int cnt,num;
}a[110][110];
int n,m,x,y,x_1,y_1,x_2,y_2,xx,yy;
int main(){
    scanf("%d%d%d%d",&n,&m,&x,&y);
    for(int cnt=1;cnt<=x;cnt++){
        scanf("%d%d%d%d",&x_1,&y_1,&x_2,&y_2);
        for(int i=x_1;i<=x_2;i++)
            for(int j=y_1;j<=y_2;j++)a[i][j].cnt++,a[i][j].num=cnt;
    }
    for(int i=1;i<=y;i++){
        scanf("%d%d",&xx,&yy);
        if(a[xx][yy].cnt)printf("Y %d %d\n",a[xx][yy].cnt,a[xx][yy].num);
        else printf("N\n");
    }
    return 0;
}