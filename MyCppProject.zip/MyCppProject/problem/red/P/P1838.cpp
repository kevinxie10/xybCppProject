#include<bits/stdc++.h>
#define xw printf("xiaoa wins.")
#define UW printf("uim wins.")
#define R0 return 0
#define PD1(i) a[i]==1
#define PD2(i) a[i]==2
#define APD1(a,b,c) PD1(a)&&PD1(b)&&PD1(c)
#define APD2(a,b,c) PD2(a)&&PD2(b)&&PD2(c)
#define IF1(a,b,c) if(APD1(a,b,c)){xw;R0;}
#define IF2(a,b,c) if(APD2(a,b,c)){UW;R0;}
using namespace std;
int a[10]={-1},n;
char x;
int main(){
	for(int i=1;i<=9;i++){
		cin>>x;
		n=x-'0';
		a[n]=(i&1?1:2);
		IF1(1,5,9)
		IF1(1,2,3)
		IF1(4,5,6)
		IF1(7,8,9)
		IF1(3,5,7)
		IF1(1,4,7)
		IF1(2,5,8)
		IF1(3,6,9)
    	IF2(1,5,9)
		IF2(1,2,3)
		IF2(4,5,6)
		IF2(7,8,9)
		IF2(3,5,7)
		IF2(1,4,7)
		IF2(2,5,8)
		IF2(3,6,9)
	}
	printf("drew.");
	return 0;
}