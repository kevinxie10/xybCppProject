#include<iostream>
using namespace std;
struct STU{
    int a,b;
}stu[17]={
    {284,220},
    {1210,1184},
    {2924,2620},
    {5564,5020},
    {6386,6232},
    {10856,10744},
    {14595,12285},
    {18416,17296},
    {66992,66928},
    {71145,67095},
    {76084,63020},
    {87633,69615},
    {88730,79750}
};
int s;
int main(){
    scanf("%d",&s);
	for(int i=0;i<=12;i++){
		if(stu[i].b>=s){printf("%d %d",stu[i].b,stu[i].a);return 0;}
		if(stu[i].a>=s){printf("%d %d",stu[i].a,stu[i].b);;return 0;}
    }
	return 0;
}