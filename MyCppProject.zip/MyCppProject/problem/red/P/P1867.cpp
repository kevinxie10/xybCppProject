#include <cstdio>
int n,a,m,t,power=1;
double x,hp=10;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%lf%d",&x,&a);
        hp-=x;
        if(hp<=0)break;
        if(hp>10)hp=10;
        t+=a;
        while(t>=power)t-=power,power<<=1,m++;
    }
    printf("%d %d",m,t);
    return 0;
}