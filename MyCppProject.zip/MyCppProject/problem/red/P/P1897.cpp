#include <iostream>
#include <map>
using namespace std;
map<int,int>tong;
int n,a[100010],mx,t;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d",&t),mx=(t>mx?t:mx),tong[t]++;
    printf("%ld",mx*10+tong.size()*5+n);
    return 0;
}