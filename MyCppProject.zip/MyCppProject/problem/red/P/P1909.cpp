#include<bits/stdc++.h>
using namespace std;
int n,a[3],b[3],x;
int main(){
    scanf("%d",&n);
    for(int i=0;i<3;i++)scanf("%d%d",a+i,b+i);
    x=ceil(n*1.0/a[0])*b[0];
    if(ceil(n*1.0/a[1])*b[1]<x)
        x=ceil(n*1.0/a[1])*b[1];
    if(ceil(n*1.0/a[2])*b[2]<x)
        x=ceil(n*1.0/a[2])*b[2];
    printf("%d",x);
    return 0;
}