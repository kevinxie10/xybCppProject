#include<cstdio>
int n;
char c[100];
int main(){
	scanf("%d %s",&n,c);
	for(int i=0;c[i]!='\0';i++)printf("%c",c[i]+n>'z'?c[i]+n-26:c[i]+n);
	return 0;
}