#include<cstdio>
int n,cnt,prime[10010],t;
bool vis[10010];
void isprime(int n){
    for(int i=2;i<=n;i++){
        if(!vis[i])prime[cnt++]=i;
        for(int j=0;j<cnt&&i*prime[j]<=n;j++){
            vis[i*prime[j]]=true;
            if(!(i%prime[j]))break;
        }
    }
}

int main(){
    scanf("%d",&n);
    isprime(10010);
    for(int i=0;i<cnt&&prime[i]<=n;i++){
        printf("%d ",prime[i]),t=0;
        for(int j=prime[i];j<=n;j*=prime[i])t+=n/j;
        printf("%d\n",t);
    }
    return 0;
}