#include<cstdio>
int n,t,cnt_5,cnt_0;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d",&t),cnt_5+=(t==5),cnt_0+=(t==0);
    if(cnt_5<9)printf("%s",(cnt_0?"0":"-1"));
    else if(!(cnt_5%9)){
        while(cnt_5--)printf("5");
        while(cnt_0--)printf("0");
    }
    else{
        while(cnt_5%9)cnt_5--;
        while(cnt_5--)printf("5");
        while(cnt_0--)printf("0");
        return 0;
    }
    return 0;
}