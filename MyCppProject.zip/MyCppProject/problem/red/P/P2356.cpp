#include<cstdio>
int n,a[1010][1010],mx;
int main(){
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	    for(int j=0;j<n;j++)scanf("%d",&a[i][j]);
	for(int i=0;i<n;i++)
	    for(int j=0;j<n;j++)
	        if(!a[i][j]){
                int sum=0;
	            for(int k=0;k<n;k++)sum+=a[i][k]+a[k][j];
	            mx=mx>sum?mx:sum;
	        }
	printf("%d",mx);
    return 0;
}