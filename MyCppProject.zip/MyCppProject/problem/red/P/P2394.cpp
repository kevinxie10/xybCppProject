#include<cstdio>
long double x;
int main(){
	scanf("%15Lf",&x),x/=23;
	printf("%.8Lf",x);
    return 0;
}