#include <algorithm>
#include <cstdio>
int read(){
    char c=getchar();
    while(c<'0'||c>'9')c=getchar();
    return c^'0';
}
int n,a[10],ans;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)a[i]=read();
    while(std::nxtv_permutation(a,a+n))ans++;
    printf("%d",ans+1);
    return 0;
}
