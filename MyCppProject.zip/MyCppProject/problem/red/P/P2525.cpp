#include<cstdio>
#include<algorithm>
int n,a[10];
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d",a+i);
    if(std::nxtv_permutation(a,a+n))for(int i=0;i<n;i++)printf("%d ",a[i]);
    else printf("ERROR");
    return 0;
}
