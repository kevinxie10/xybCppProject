#include <cstdio>
const int di[8]={-1,-1,-1,0,0,1,1,1},dj[8]={-1,0,1,-1,1,-1,0,1};
int n,m;
char mp[110][110];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%s",mp[i]+1);
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(mp[i][j]=='*'){printf("*");continue;}
            int cnt=0;
            for(int k=0;k<8;k++)cnt+=(mp[i+di[k]][j+dj[k]]=='*');
            printf("%d",cnt);
        }
        printf("\n");
    }
    return 0;
}