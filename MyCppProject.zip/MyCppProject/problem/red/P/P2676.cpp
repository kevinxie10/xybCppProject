#include<cstdio>
#include<algorithm>
using namespace std;
int n,b,h[20010],sum,ans;
bool cmp(int x,int y){return x>y;}
int main(){
    scanf("%d%d",&n,&b);
	for(int i=0;i<n;i++)scanf("%d",h+i);
	sort(h,h+n,cmp);
	while(sum<b)sum+=h[ans++];
    printf("%d",ans);
	return 0;
}