#include<cstdio>
int x1,y1,x2,y2,t,cnt;
char c;
int main(){
    scanf("%d%d%d%d%d",&x1,&y1,&x2,&y2,&t);
    while(t--){
    	scanf(" %c",&c);
		if(c=='E'&&y1<y2)y1++,cnt++;
		if(c=='S'&&x1>x2)x1--,cnt++;
		if(c=='W'&&y1>y2)y1--,cnt++;
    	if(c=='N'&&x1<x2)x1++,cnt++;
		if(x1==x2&&y1==y2){printf("%d",cnt);return 0;}
	}
	printf("-1");
    return 0;
}