#include <cstdio>
int r,b,c,d,e,s;
int main(){
    scanf("%d%d%d%d%d",&r,&b,&c,&d,&e);
    if(c+d>e<<1)s=r*c+b*d;
    else{
        if(r>b)s=(b*e<<1)+(r-b)*c;
        else s=(r*e<<1)+(b-r)*d;
    }
    printf("%d",s);
    return 0;
}