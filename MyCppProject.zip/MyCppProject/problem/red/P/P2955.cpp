#include <cstdio>
int n;
bool read(){
    char c=getchar(),rear;
    while(c<'0'||c>'9')c=getchar();
    while(c>='0'&&c<='9')rear=c,c=getchar();
    return (rear-'0')&1;
}
int main(){
    scanf("%d",&n);
    while(n--)printf("%s\n",(read()?"odd":"even"));
    return 0;
}