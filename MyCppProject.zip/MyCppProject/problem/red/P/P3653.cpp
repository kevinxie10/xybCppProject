#include <iostream>
int n,m;
long long b[60][60],ans[60][60];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)scanf("%lld",&b[i][j]);
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
            for(int x=0;x<n;x++)
                for(int y=0;y<m;y++)
                    if(b[i][j]==b[x][y])
                        ans[i][j]=std::max(ans[i][j],(long long)((i-x)*(i-x)+(j-y)*(j-y)));
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)printf("%lld ",ans[i][j]);
        printf("\n");
    }
    return 0;
}