#include<iostream>
using namespace std;
int n;
string s;
int solve(){
    int cnt=0;
    for(int i=0;i<s.size()-1;i++)if(s[i]=='V'&&s[i+1]=='K')cnt++;
    return cnt;
}
int main(){
    scanf("%d",&n);
    cin>>s;
    int mx=solve();
    for(int i=0;i<n;i++)
        if(s[i]=='V'){s[i]='K';mx=max(mx,solve());s[i]='V';}
        else if(s[i]=='K'){s[i]='V';mx=max(mx,solve());s[i]='K';}
    printf("%d",mx);
    return 0;
}