#include <cstdio>
#include <algorithm>
int n,x[1010],y[1010],cnt;
int main(){
    scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",x+i);
	for(int i=0;i<n;i++)scanf("%d",y+i);
	std::sort(x,x+n),std::sort(y,y+n);
	for(int i=0;i<n;i++)cnt+=(x[i]<=y[i]);
	if(cnt==n)printf("DA");
	else printf("NE");
	return 0;
}