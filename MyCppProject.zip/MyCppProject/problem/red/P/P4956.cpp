#include<cstdio>
long long n;
int main(){
    scanf("%lld",&n),n/=52;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=100;j++)
			if(j*7+i*21==n){printf("%d\n%d",j,i);return 0;}
    return 0;
}