#include<iostream>
#include<map>
using namespace std;
int n,m;
string q,a;
map<string,string>mp;
char d[]={'A','B','C','D'};
int main(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)cin>>q>>a,mp[q]=a;
	for(int i=0;i<m;i++){
		cin>>q;
		for(int j=0;j<4;j++){
			cin>>a;
			if(mp[q]==a)printf("%c\n",d[j]);
		}
	}
	return 0;
}