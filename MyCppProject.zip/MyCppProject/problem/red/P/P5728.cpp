#include<cstdio>
#include<cmath>
int n,sum[1010],ans=0;
struct student{
	int c;
	int m;
	int e;
	int sum;
}stu[1010];
int main(){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%d%d",&stu[i].c,&stu[i].m,&stu[i].e);
		stu[i].sum=stu[i].c+stu[i].m+stu[i].e;
	}
	for(int i=0;i<n;i++)
		for(int j=i+1;j<n;j++)
			ans+=(abs(stu[i].c-stu[j].c)<=5&&abs(stu[i].e-stu[j].e)<=5&&abs(stu[i].m-stu[j].m)<=5&&abs(stu[i].sum-stu[j].sum)<=10);
	printf("%d",ans);
	return 0;
}