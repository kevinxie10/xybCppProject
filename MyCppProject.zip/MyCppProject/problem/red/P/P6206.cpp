#include <cstdio>
long long n,cnt;
int main(){
	scanf("%lld",&n);
	while(n!=1)
		(n&1?n=n*3+1:n/=2),cnt++;
	printf("%lld\n",cnt);
	return 0;
}