#include<cstdio>
long long x;
int main(){
    scanf("%lld",&x);
    printf("%lld",90-x);
    return 0;
}