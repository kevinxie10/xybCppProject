#include <cstdio>
inline int read(){
	int num=0;
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){num=(num<<1)+(num<<3)+(c^'0');c=getchar();}
	return num;
}
int tong[10000010],n,x,t;
long long ans;
int main(){
    n=read();
    while(n--){
        x=read();t=read();
        (!tong[x]&&t>1?ans+=t,tong[x]=1:ans=ans);
    }
    printf("%lld",ans);
    return 0;
}