#include <cstdio>
int t,q,b,s,g,cnt;
int main(){
    for(int i=0;i<5;i++){
        scanf("%d",&t);
        q=t/1000;
        b=t%1000/100;
        s=t/10%10;
        g=t%10;
        cnt+=(q==s&&g==b+1);
    }
    printf("%d",cnt);
    return 0;
}