#include <cstdio>
int ans;
float n,k;
int main(){
    scanf("%f",&n),k=n/2;
    for(int i=1;i<n;i++)ans+=(i*i%(int)n<k);
    printf("%d",ans);
    return 0;
}