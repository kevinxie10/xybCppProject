#include <cstdio>
long long a,b,n,weekt,lastt,weeks;
int main(){
	scanf("%lld%lld%lld",&a,&b,&n),weekt=5*a+b*2,lastt=n%weekt,weeks=n/weekt;
    printf("%lld",n/weekt*7+(lastt<=5*a?(lastt+a-1)/a:(5+(lastt-5*a+b-1)/b)));
	return 0;
}