#include<cstdio>
#include<cmath>
int a,b;
int main(){
    scanf("%d%d",&a,&b);
    unsigned long long p=pow(a,b);
    if(p>1000000000||p==0)printf("-1");
    else printf("%llu",p);
    return 0;
}