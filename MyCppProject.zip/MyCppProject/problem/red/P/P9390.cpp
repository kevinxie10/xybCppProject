#include <iostream>
using namespace std;
typedef long long ll;
long long y,z;
int main(){
    scanf("%lld%lld",&y,&z);
	if(z<1e11)printf("%lld",(ll)1e11+y-z);
	else printf("%lld",min(abs(y-z%(ll)1e6),min(abs(y+(ll)1e6-z%(ll)1e6),abs(y-(ll)1e6-z%(ll)1e6))));
	return 0;
}