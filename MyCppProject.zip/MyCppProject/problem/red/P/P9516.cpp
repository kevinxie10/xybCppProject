#include <cstdio>
int Gray,Blue,Green,Orange,Red,Color;
int main(){
    scanf("%d%d%d%d%d",&Gray,&Blue,&Green,&Orange,&Red);
	Color=Gray+Blue+Green+Orange+Red;
	if(Color<100)printf("Gray");
	if(Color>=100&&Color<130)printf("Blue");
	if(Color>=130&&Color<170)printf("Green");
	if(Color>=170&&Color<230)printf("Orange");
	if(Color>=230)printf("Red");
	return 0;
}