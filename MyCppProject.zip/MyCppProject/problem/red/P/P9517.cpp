#include <cstdio>
int n,l=-1,r=-1;
bool a[100010];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",(int*)(a+i)),l=(l==-1&&a[i]?i:l),r=(a[i]?i:r);
    printf("%d",(l==-1?0:r-l+1));
    return 0;
}