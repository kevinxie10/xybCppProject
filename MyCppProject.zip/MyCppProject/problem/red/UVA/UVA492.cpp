#include<iostream>
using namespace std;
string s;
const char aeiou[10]={'a','e','i','o','u','A','E','I','O','U'};
bool pd(char x){
    for(int i=0;i<10;i++)if(x==aeiou[i])return true;
	return false;
}
char t;
int main(){
	while(getline(cin,s)){
		int i=0;
		while(i<s.size()){
			if(s[i]>='a'&&s[i]<='z'){
				if(!pd(s[i]))t=s[i++];
				while(isalpha(s[i]))printf("%c",s[i++]);
				if(!pd(s[i]))printf("%c",t);
                printf("ay");
			}
			else cout<<s[i++];
		}
        printf("\n");
	}
	return 0;
}