#include <iostream>
#include <vector>
#include <bitset>
using namespace std;
int n,r;
vector<int>v={1,2,3};
void print(vector<int>v){
    for(auto i:v)printf("%3d",i);
    return ;
}
void dfs(vector<int>v,int cnt){
    if(cnt==r){print(v);return ;}
    for(int i=v.back()+1;i<=n;i++)v.pop_back(),v.push_back(i),dfs(v,cnt+1);
    return ;
}
int main(){
    scanf("%d%d",&n,&r);
    dfs(v,0);
    return 0;
}