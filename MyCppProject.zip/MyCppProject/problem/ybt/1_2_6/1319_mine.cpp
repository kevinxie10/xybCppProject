#include<algorithm>
#include <cstdio>
int n;
float s,ave;
struct P{
    float t;
    int num;
    bool operator<(const P &a)const{
        return t<a.t;
    }
}a[1010];
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%f",&a[i].t),a[i].num=i;
    std::sort(a,a+(int)n);
    for(int i=0;i<n;i++){
        printf("%d ",a[i].num+1);
        ave+=s;
        s+=a[i].t;
    }
    printf("\n%.2f",ave/n);
    return 0;
}