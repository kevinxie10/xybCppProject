#include <algorithm>
#include <bits/stdc++.h>
#include <cinttypes>
using namespace std;
int n;
double ans,s;
pair<double,int>a[1010];
int main(){
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i].first;
        a[i].second=i;
    }
    sort(a+1,a+1+n);
    for(int i=1;i<=n;i++){
        ans+=s;
        s+=a[i].first;
    }
    printf("%.2f",ans/n);
    return 0;
}