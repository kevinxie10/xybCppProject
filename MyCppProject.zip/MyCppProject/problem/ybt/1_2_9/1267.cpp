#include <cstdio>
int dp[1010][1010],n,m,w[1010],v[1010];
int main(){
    scanf("%d%d",&m,&n);
    for(int i=1;i<=n;i++)scanf("%d%d",w+i,v+i);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++){
            dp[i][j]=dp[i-1][j];
            if(j>=w[i])dp[i][j]=(dp[i-1][j-w[i]]+v[i]>dp[i][j]?dp[i-1][j-w[i]]+v[i]:dp[i][j]);
        }
    printf("%d",dp[n][m]);
    return 0;
}