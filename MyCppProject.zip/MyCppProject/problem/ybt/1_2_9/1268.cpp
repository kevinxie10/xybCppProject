#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int m,n,w[6010],c[6010],dp[6010][210];
int main(){
    scanf("%d%d",&m,&n);
    for(int i=1;i<=n;i++){
        scanf("%d%d",w+i,c+i);
        int k=m/w[i];
        for(int j=1;j<k;j++,i++,n++)w[i+1]=w[i],c[i+1]=c[i];
    
    }
    for(int i=1;i<=n;i++){
        for(int j=0;j<=m;j++){
            dp[i][j]=dp[i-1][j];
            if(j>=w[i])dp[i][j]=max(dp[i][j],dp[i][j-w[i]]+c[i]);
        }
    }
    printf("max=%d",dp[n][m]);
    return 0;
}