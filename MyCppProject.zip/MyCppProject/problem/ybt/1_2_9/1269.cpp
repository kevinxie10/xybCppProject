#include <cstdio>
const int N=40010;
int m,n,w[N],c[N],s[N],dp[2][N];//滚动数组
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d%d%d",w+i,c+i,s+i);
    for(int i=1;i<=n;i++){
        for(int k=1;k<=s[i];k++){
            for(int j=1;j<=m;j++){
                dp[1][j]=dp[0][j];
                if(j>=w[i])dp[1][j]=(dp[0][j-w[i]]+c[i]>dp[1][j]?dp[0][j-w[i]]+c[i]:dp[1][j]);
            }
            for(int j=1;j<=m;j++)dp[0][j]=dp[1][j];
        }
    }
    printf("%d",dp[0][m]);
    return 0;
}