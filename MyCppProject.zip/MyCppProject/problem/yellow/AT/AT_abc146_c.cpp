#include <cstdio>
long long a,b,c,ans;
bool check(int x){
    int t=x,w=0;
    while(t)t/=10,w++;
	return (x*a+w*b)<=c;
}
int main(){
	scanf("%lld%lld%lld",&a,&b,&c);
	int l=0,r=1e9;
	while(l<=r){
		int mid=(l+r)/2;
		if(check(mid))ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d",r);
	return 0;
}