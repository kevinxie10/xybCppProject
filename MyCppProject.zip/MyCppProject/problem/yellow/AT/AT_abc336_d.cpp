#include <iostream>
using namespace std;
const int N=200010;
int k,s[N],dp1[N],dp2[N],ans=1;
int main(){
    scanf("%d",&k);
    for(int i=1;i<=k;i++)scanf("%d",s+i),dp1[i]=min(dp1[i-1]+1,s[i]);
    for(int i=k;i>=1;i--)dp2[i]=min(dp2[i+1]+1,s[i]);
    for(int i=1;i<=k;i++)ans=max(ans,min(dp1[i],dp2[i]));
    printf("%d",ans);
    return 0;
}