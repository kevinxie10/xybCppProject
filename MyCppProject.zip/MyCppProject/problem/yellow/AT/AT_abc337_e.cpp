#include <iostream>
#include <bitset>
#include <cmath>
using namespace std;
bitset<20>bs;
int n,ans,k,cnt,a[200010];
char c;
int main(){
    scanf("%d",&n);
    k=ceil(log2(n));
    printf("%d\n",k);
    for(int i=1;i<=k;i++,cnt=0){
        for(int j=1;j<=n;j++){
            bs=j;
            if(bs[i-1]==1)a[++cnt]=j;
        }
        printf("%d ",cnt);
        for(int j=1;j<=cnt;j++)printf("%d ",a[j]);
        printf("\n");
    }
    for(int i=0;i<k;i++){
        cin>>c;
        if(c-48)ans+=(1<<i);
    }
    if(!ans)printf("%d",n);
    else printf("%d",ans);
    return 0;
}