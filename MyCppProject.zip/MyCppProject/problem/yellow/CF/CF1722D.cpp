#include <iostream>
#include <algorithm>
using namespace std;
struct People{
	char pos;
	long long id;
	long long cnt;
	bool operator<(const People &a)const{
		return (cnt==a.cnt?pos<a.pos:cnt<a.cnt);
	} 
}a[200010];
long long t,n,ans;
char c[200010];
int main(){
	scanf("%lld",&t);
	while(t--){
		scanf("%lld",&n),ans=0;
		scanf("%s",c+1);
		for(int i=1;i<=n;i++)a[i]={c[i],i,(c[i]=='L'?i-1:n-i)},ans+=a[i].cnt;
		sort(a+1,a+1+n);
		//for(int i=1;i<=n;i++)printf("%c %d %d\n",a[i].pos,a[i].id,a[i].cnt);
		for(int i=1;i<=n;i++){
			if(n-a[i].cnt-1>a[i].cnt)ans+=n-a[i].cnt-1-a[i].cnt;
			printf("%lld ",ans);
		}
		puts("");
	}
	return 0;
}