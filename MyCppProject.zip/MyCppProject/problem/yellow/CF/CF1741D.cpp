#include <iostream>
int t,m,a[300010],cnt;
bool dfs(int l,int r){
	int mid=(l+r)>>1;
	if(r-l>1){
		if(!(dfs(l,mid)&&dfs(mid+1,r))||abs(a[l]-a[mid+1])!=(mid+1-l))return false;
		if(a[l]-a[mid+1]==mid+1-l){
			for(int i=l;i<=mid;i++)
				std::swap(a[i],a[i+r-mid]);
			cnt++;
			return true;
		}
	}
	else{
		if(std::abs(a[l]-a[r])>1)return false;
		if(a[r]<a[l]){std::swap(a[l],a[r]),cnt++;return true;}
	}
	return 1;
}
int main(){
	scanf("%d",&t);
	while(t--){
		scanf("%d",&m);
		for(int i=1;i<=m;i++)scanf("%d",a+i);
		if(m==1){printf("0\n");continue;}
		cnt=0;
		printf("%d\n",(dfs(1,m)?cnt:-1));
	}
	return 0;
}