#include<algorithm>
#include<iostream>
using namespace std;
long long t,n,h,nh,a[200010],ans;
int nxt[3][3]={{2,2,3},{2,3,2},{3,2,2}};
int main(){
    scanf("%lld",&t);
    while(t--){
        scanf("%lld%lld",&n,&h);
        for(int i=1;i<=n;i++)scanf("%lld",a+i);
        std::sort(a+1,a+1+n);
		for(int cnt=0;cnt<3;cnt++){
			int w=0,i=1;
            nh=h;
			while(w<=3){
				while(a[i]<nh&&i<=n)nh+=a[i++]/2;
				if(w==3){ans=max((int)ans,i);break;}
                nh*=nxt[cnt][w++];
			}
		}
		printf("%lld\n",ans-1);
        ans=0;
    }
    return 0;
}
