#include<cstdio>
#include<cstring>
//int n,w[12],v[120000];
int main() {
    scanf("%d%d%d%d",&n,w+1,w+2,w+3);
    memset(v,-1,sizeof v),v[0]=0;
    for(int i=1;i<=3;i++)
        for(int j=w[i];j<=n;j++){
            if(v[j-w[i]]==-1)continue;
            v[j]=(v[j-w[i]]+1>v[j]?v[j-w[i]]+1:v[j]);
        }
    printf("%d",v[n]);
    return 0;
}