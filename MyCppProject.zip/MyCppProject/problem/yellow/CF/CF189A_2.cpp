#include <cstdio>
const int N=4010;
int n,m,dp[N],w;
int main(){
    dp[0]=1;
    scanf("%d",&m);
    for(int i=1;i<=3;i++){
        scanf("%d",&w);
        for(int j=w;j<=m;j++)
            if(dp[j-w]||j-w==0)dp[j]=(dp[j-w]+1>dp[j]?dp[j-w]+1:dp[j]);
    }
    printf("%d",dp[m]-1);
    return 0;
}