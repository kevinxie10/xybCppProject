#include <cstdio>
int t,c,q,l,r,sum[300010],cnt1[300010];
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&c,&q);
        for(int i=1;i<=c;i++)scanf("%d",sum+i),sum[i]+=sum[i-1],cnt1[i]=cnt1[i-1]+(sum[i]-sum[i-1]==1);
        while(q--){
            scanf("%d%d",&l,&r);
            if(r-l+1==1)printf("NO\n");
            else if(sum[r]-sum[l-1]-(r-l+1)>=cnt1[r]-cnt1[l-1])printf("YES\n");
            else printf("NO\n");
        }
    }
    return 0;
}