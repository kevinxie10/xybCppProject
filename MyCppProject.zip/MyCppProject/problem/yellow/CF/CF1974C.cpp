#include <iostream>
#include <map>
#include <tuple>
using namespace std;
map<tuple<int,int,int>,int>mp;
int T,n,a[200010];
long long ans;
int main(){
    scanf("%d",&T);
    while(T--){
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            scanf("%d",a+i);
            if(i>2){
                ans+=(mp[{a[i-2],a[i-1],-1}]++)
                    +(mp[{-1,a[i-1],a[i]}]++)
                    +(mp[{a[i-2],-1,a[i]}]++)
                    -(mp[{a[i-2],a[i-1],a[i]}]++)*3;
            }
        }
        printf("%lld\n",ans);
        ans=0,mp.clear();
    }
    return 0;
}