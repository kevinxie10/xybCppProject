#include <iostream>
#include <vector>
using namespace std;
int n,m,u,v,ans;
bool w[100010];
vector<int> g[100010];
void dfs(int x,int fa,int cnt){
    if(cnt>m)return ;
    if(x!=1&&g[x].size()==1)ans++;
    for(int i=0;i<g[x].size();i++){
        if(g[x][i]==fa)continue;
        if(w[g[x][i]])dfs(g[x][i],x,cnt+1);
        else dfs(g[x][i],x,0);
    }
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",(int*)(w+i));
    for(int i=1;i<n;i++)scanf("%d%d",&u,&v),g[u].push_back(v),g[v].push_back(u);
    dfs(1,0,w[1]);
    printf("%d",ans);
    return 0;
}