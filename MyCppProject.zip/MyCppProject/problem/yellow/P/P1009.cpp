#include <cstdio>
int a[1010],b[1010],n,i;
int main(){
    scanf("%d",&n),a[0]=b[0]=1;
    for(i=2;i<=n;i++){
        for(int j=0;j<100;j++)b[j]*=i;
        for(int j=0;j<100;j++)if(b[j]>9){b[j+1]+=b[j]/10,b[j]%=10;}
        for(int j=0;j<100;j++){
            a[j]+=b[j];
            if(a[j]>9)a[j+1]+=a[j]/10,a[j]%=10;
        }
    }
    for(i=100;i>=0&&!a[i];i--);
    for(;i>=0;i--)printf("%d",a[i]);
    return 0;
}