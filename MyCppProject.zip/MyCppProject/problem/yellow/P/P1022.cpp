#include <iostream>
using namespace std;
int k,b,f0=1,x,flag=1;
bool f1=true;
char op;
string s,s1,s2;
int main(){
    cin>>s;
    for(auto i:s)if(i>='a'&&i<='z'){op=i;break;}
    for(auto i:s){
        if(i>='0'&&i<='9'){x=(x<<3)+(x<<1)+(i^48),f1=false;continue;}
        if(i>='a'&&i<='z'){
            if(f1)k+=f0*flag;
            else k+=f0*flag*x,x=0;
            f1=true;
            continue;
        }
        b+=flag*f0*x,x=0,f1=true;
        switch(i){
            case '+':f0=1;break;
            case '-':f0=-1;break;
            case '=':f0=1,flag=-1,f1=true;break;
        }
    }
    b+=flag*f0*x;
    if(-1.0*b/k==-0){printf("%c=0.000",op);return 0;}
    printf("%c=%.3lf",op,-1.0*b/k);
    return 0;
}
