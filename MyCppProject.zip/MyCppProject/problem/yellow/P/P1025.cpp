#include <cstdio>
int n,k,cnt;
void dfs(int x,int n,int k){
	if(k==1){
		cnt++;
		return ;
	}
	for(int i=x,t=n/k;i<=t;i++)dfs(i,n-i,k-1);
}
int main(){
	scanf("%d%d",&n,&k),dfs(1,n,k);
	printf("%d",cnt);
	return 0;
}