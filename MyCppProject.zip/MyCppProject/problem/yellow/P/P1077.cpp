#include <cstdio>
int n,m,x,dp[110][110];
int main(){
    scanf("%d%d",&n,&m);
    dp[0][0]=1;
    for(int i=1;i<=n;i++){
        scanf("%d",&x);
        for(int j=0;j<=m;j++)dp[i][j]=dp[i-1][j];
        for(int j=0;j<=m;j++)
            for(int k=1;k<=x;k++){
                if(k*1>j)continue;//w=1
                dp[i][j]+=dp[i-1][j-k*1];
                dp[i][j]%=1000007;
            }
    }
    printf("%d",dp[n][m]);
    return 0;
}