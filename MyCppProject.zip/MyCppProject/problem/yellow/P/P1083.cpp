#include <cstdio>
#include <cstring>
const int N=1000010;
long long n,m,a[N],c[N],x[N],y[N],d[N];
bool check(int k){
    memset(c,0,sizeof c);
    for(int i=1;i<=k;i++){
        c[x[i]]+=d[i],c[y[i]+1]-=d[i];
    }
    for(int i=1;i<=n;i++){
        c[i]+=c[i-1];
        if(c[i]>a[i])return true;
    }
    return false;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    for(int i=1;i<=m;i++)scanf("%d%d%d",d+i,x+i,y+i);
    int l=1,r=m+1,ans=0;
    while(l<=r){
        int mid=(l+r)>>1;
        if(check(mid))r=(ans=mid)-1;
        else l=mid+1;
    }
    if(!ans)puts("0");
    else printf("-1\n%d",ans);
    return 0;
}