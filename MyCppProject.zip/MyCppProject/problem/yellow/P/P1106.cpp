#include <iostream>
#include <vector>
using namespace std;
vector<char>a;
string s;
int k,tk;
bool flag=0;
int main(){
    cin>>s>>k;
    tk=k;
    for(int i=0;i<s.length();i++)
        if(a.empty())a.push_back(s[i]);
        else{
            while(a.back()>s[i]&&k>0)a.pop_back(),k--;
            a.push_back(s[i]);
        }
    for(int i=0;i<(s.length()-tk);i++){
        if(a[i]!='0')flag=true;
        if(flag)cout<<a[i];
    }
    if(!flag)printf("0");
    return 0;
}