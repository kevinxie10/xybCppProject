#include <iostream>
#include <algorithm>
using namespace std;
struct edge{
    int x,y,t;
    bool operator<(const edge &a){
        return t<a.t;
    }
}e[200010];
int n,m,fa[2010];
int find(int x){
    return (x==fa[x]?x:(fa[x]=find(fa[x])));
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1;i<=m;i++)scanf("%d%d%d",&e[i].x,&e[i].y,&e[i].t);
    sort(e+1,e+1+m);
    for(int i=1;i<=m;i++){
        int fx=find(e[i].x),fy=find(e[i].y);
        if(fx!=fy)fa[fx]=fy,n--;
        if(n==1){printf("%d",e[i].t);return 0;}
    }
    printf("-1");
    return 0;
}