#include <iostream>
#include <queue>
#include <vector>
using namespace std;
vector<int>g[1000010];
int n,m,x,y,dep[1000010],ans[1000010];
bool vis[1000010];
queue<int>q;
void bfs(){
    dep[1]=0,q.push(1),vis[1]=true,ans[1]=1;
    while(!q.empty()){
        int k=q.front();
        q.pop();
        for(auto i:g[k]){
            if(!vis[i]){vis[i]=true,dep[i]=dep[k]+1,q.push(i);}
            if(dep[i]==dep[k]+1){ans[i]=(ans[i]+ans[k])%100003;}
        }
    }
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&x,&y);
        g[x].push_back(y);
        g[y].push_back(x);
    }
    bfs();
    for(int i=1;i<=n;i++)printf("%d\n",ans[i]);
    return 0;
}