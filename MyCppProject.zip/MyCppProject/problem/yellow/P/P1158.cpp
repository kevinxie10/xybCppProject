#include<cstdio>
#include<cstring>
#include<algorithm>
#define MAX(x,y) ((x)>(y)?(x):(y))
#define MIN(x,y) ((x)<(y)?(x):(y))
using namespace std;
int xx1,yy1,xx2,yy2,n,mn=0x3f3f3f3f,x[100010],y[100010];
struct DAODAN{
    int dis1,dis2,num;
    bool operator<(const DAODAN &a)const{return dis1<a.dis1;}
}dis[100010];
int main(){
    scanf("%d%d%d%d%d",&xx1,&yy1,&xx2,&yy2,&n);
    memset(dis,0,sizeof dis);
    for(int i=1;i<=n;i++)scanf("%d%d",x+i,y+i),dis[i].dis1=(x[i]-xx1)*(x[i]-xx1)+(y[i]-yy1)*(y[i]-yy1),dis[i].num=i;
    sort(dis+1,dis+n+1);
    for(int i=n;i>0;i--)dis[i].dis2=MAX(((x[dis[i].num]-xx2)*(x[dis[i].num]-xx2)+(y[dis[i].num]-yy2)*(y[dis[i].num]-yy2)),(dis[i+1].dis2));
    for(int i=0;i<=n;i++)mn=MIN((dis[i].dis1+dis[i+1].dis2),mn);
    printf("%d",mn);
    return 0;
}