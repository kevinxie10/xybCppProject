#include <cstdio>
#include <algorithm>
int n,t[5010],y1,m1,d1,h1,mi1,y2,m2,d2,h2,mi2,month[]={0,31,28,31,30,31,30,31,31,30,31,31,30};;

int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d",t+i);
    std::sort(t,t+n);
    scanf("%d-%d-%d-%d:%d",&y1,&m1,&d1,&h1,&mi1);
    scanf("%d-%d-%d-%d:%d",&y2,&m2,&d2,&h2,&mi2);

}





















/*
#include<bits/stdc++.h>//万能头文件
using namespace std;
int n,ti[5001];
int day[13]={0,31,28,31,30,31,30,31,31,30,31,31,30};//12个月
int a[10],b[10];//两个数组
long long t;//分钟
int ans;//答案
bool panding(int x){//其实这里有歧义，科学点讲应该更详细
    if(x%100==0){if(x%400==0)return 1;}
    else{if(x%4==0)return 1;}
    return 0;
}
int main(){
    cin>>n;
    for(int i=1;i<=n;i++)
       cin>>ti[i];
    sort(ti+1,ti+n+1);//排序
    scanf("%d-%d-%d-%d:%d",&a[1],&a[2],&a[3],&a[4],&a[5]);
    scanf("%d-%d-%d-%d:%d",&b[1],&b[2],&b[3],&b[4],&b[5]);
    for(int i=a[1];i<b[1];i++)
       if(panding(i))t-=366;//全反了
       else t-=365;
    for(int i=1;i<a[2];i++)t+=day[i];
    for(int i=1;i<b[2];i++)t-=day[i];
    if(panding(a[1])&&a[2]>2)t++;//闰年
    if(panding(b[1])&&b[2]>2)t--;
    t+=a[3];
    t-=b[3];
    t*=1440;
    t+=60*a[4]+a[5];
    t-=60*b[4]+b[5];
    t*=-1;//写反啦 
    for(int i=1;i<=n;i++){
        if(t>=ti[i])t-=ti[i],ans++;
        else break;//判断能不能刷完这道题
    }
    cout<<ans;//输出
    return 0;
*/