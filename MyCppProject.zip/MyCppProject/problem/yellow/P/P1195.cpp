#include <iostream>
#include <algorithm>
using namespace std;
int n,m,k,fa[10010],x,y,cnt,ans;
struct EDGE{
    int x,y,l;
    bool operator<(const EDGE &a){
        return l<a.l;
    }
}e[10010];
int find(int x){
    return fa[x]==x?x:fa[x]=find(fa[x]);
}
int main(){
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1;i<=m;i++)scanf("%d%d%d",&e[i].x,&e[i].y,&e[i].l);
    sort(e+1,e+1+m);
    for(int i=1;i<=m;i++){
        x=find(e[i].x),y=find(e[i].y);
        if(x==y)continue;
        fa[x]=y;
        ans+=e[i].l;
        cnt++;
        if(cnt>=n-k)break;
    }
    if(cnt>=n-k)printf("%d",ans);
    else puts("No Answer");
    return 0;
}