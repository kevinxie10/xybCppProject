#include <cstdio>
int n,ans[30],cnt;
bool x1[30],x2[30],l[30];
void dfs(int k){
    if(k>n){
        cnt++;
        if(cnt<=3){
            for(int i=1;i<=n;i++)printf("%d ",ans[i]);
            printf("\n");
            return ;
        }
    }
    for(int i=1;i<=n;i++){
        if(!l[i]&&!x1[k-i+n]&&!x2[k+i]){
            ans[k]=i;
            l[i]=x1[k-i+n]=x2[k+i]=1;
            dfs(k+1);
            ans[k]=l[i]=x1[k-i+n]=x2[k+i]=0;
        }
    }
}
int main(){
    scanf("%d",&n);
    dfs(1);
    printf("%d",cnt);
    return 0;
}