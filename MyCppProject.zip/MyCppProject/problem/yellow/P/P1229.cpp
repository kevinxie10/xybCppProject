#include<cstdio>
#include<cstring>
using namespace std;
char s1[500],s2[500];
int main(){
    scanf("%s%s",s1,s2);
    int ans=1,len1=strlen(s1),len2=strlen(s2);
    for(int i=0;i<len1;i++)
        for(int j=1;j<len2;j++)
            if(s1[i]==s2[j]&&s1[i+1]==s2[j-1])ans<<=1;
    printf("%d",ans);
    return 0;
}