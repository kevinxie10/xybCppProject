#include <cstdio>
#include <algorithm>
using namespace std;
struct node{
    int num,s,w;
}result[200010],winner[200010],loser[200010];//result,winner,loser
int n,r,q;
bool cmp(const node&a,const node&b){return (a.s==b.s)?(a.num<b.num):(a.s>b.s);}
void solve(){
    int ai=1,bi=1;
    for(int i=1;i<=n+n;i+=2){
        if(result[i].w>result[i+1].w){
            result[i].s++;
            winner[ai++]=result[i];
            loser[bi++]=result[i+1];
        }
        else{
            result[i+1].s++;
            winner[ai++]=result[i+1];
            loser[bi++]=result[i];
        }
    }
    int i=1,j=1,k=1;
    while(i<ai&&j<bi){
        if(cmp(winner[i],loser[j]))result[k++]=winner[i++];
        else result[k++]=loser[j++];
    }
    while(i<ai)result[k++]=winner[i++];
    while(j<bi)result[k++]=loser[j++];
}
int main(){
    scanf("%d%d%d",&n,&r,&q);
    for(int i=1;i<=n+n;i++)scanf("%d",&result[i].s),result[i].num=i;
    for(int i=1;i<=n+n;i++)scanf("%d",&result[i].w);
    sort(result+1,result+1+n+n,cmp);
    for(int i=1;i<=r;i++)solve();
    printf("%d",result[q].num);
    return 0;
}