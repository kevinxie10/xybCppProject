#include <iostream>
#include <cstring>
int n,a,b,k,t,d[110][110];
int main(){
    memset(d,0x3f,sizeof d);
    scanf("%d%d%d",&n,&a,&b);
    for(int i=1;i<=n;i++)d[i][i]=0;
    for(int i=1;i<=n;i++){
        scanf("%d",&k);
        for(int j=1;j<=k;j++)scanf("%d",&t),d[i][t]=(j!=1);
    }
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)d[i][j]=std::min(d[i][j],d[i][k]+d[k][j]);
    printf("%d",(d[a][b]==0x3f3f3f3f?-1:d[a][b]));
    return 0;
}
