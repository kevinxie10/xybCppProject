#include <iostream>
using namespace std;
int n,w,u,v;
int main(){
    
}