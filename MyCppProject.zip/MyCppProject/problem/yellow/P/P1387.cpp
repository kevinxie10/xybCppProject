#include <iostream>
using namespace std;
int n,m,dp[110][110],mx;
//bool mp[110][110];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)scanf("%d",&dp[i][j]);
    //dp[1][1]=mp[1][1];
    //for(int i=2;i<=n;i++)dp[1][i]=mp[1][i];
    //for(int i=2;i<=m;i++)dp[i][1]=mp[i][1];
    for(int i=2;i<=n;i++)
        for(int j=2;j<=m;j++){
            if(dp[i][j])dp[i][j]=min(dp[i-1][j],min(dp[i-1][j-1],dp[i][j-1]))+1;
        }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            mx=max(dp[i][j],mx);
    //for(int i=1;i<=n;i++,puts(""))
    //    for(int j=1;j<=m;j++)printf("%d ",dp[i][j]);
    printf("%d",mx);
    return 0;
}