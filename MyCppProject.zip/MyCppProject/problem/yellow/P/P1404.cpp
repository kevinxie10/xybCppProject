#include <cstdio>
long long n,m,a[100010],sum[100010];
bool check(int x){
    long long mn=(long long)1<<62;
    for(int i=1;i<=n;i++){
        sum[i]=sum[i-1]+a[i]-x;
        if(i>=m){
            mn=(sum[i-m]<mn?sum[i-m]:mn);
            if(sum[i]>=mn)return true;
        }
    }
    return false;
}
int main(){
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=n;i++)scanf("%lld",a+i),a[i]*=1000;
    long long l=0,r=2000*100000;
    while(l<r){
        int mid=(l+r)>>1;
        if(check(mid))l=mid+1;
        else r=mid-1;
    }
    if(!check(l))l--;
    printf("%lld",l);
    return 0;
}