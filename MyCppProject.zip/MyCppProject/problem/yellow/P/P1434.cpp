#include <iostream>
using std::max;
int r,c,h[110][110],step[110][110],mx;
const int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
int dfs(int x,int y){
    if(step[x][y])return step[x][y];
    step[x][y]=1;
    for(int i=0;i<4;i++){
        int xx=x+dx[i],yy=y+dy[i];
        if(xx>=0&&xx<r&&yy>=0&&yy<c&&h[x][y]>h[xx][yy])dfs(xx,yy),step[x][y]=max(step[x][y],step[xx][yy]+1);
    }
    return step[x][y];
}
int main(){
    scanf("%d%d",&r,&c);
    for(int i=0;i<r;i++)
        for(int j=0;j<c;j++)scanf("%d",&h[i][j]);
    for(int i=0;i<r;i++)
        for(int j=0;j<c;j++)
            mx=max(mx,dfs(i,j));
    printf("%d",mx);
    return 0;
}