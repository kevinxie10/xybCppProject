#include <iostream>
#include <algorithm>
using namespace std;
string s,rs;
int dpl[1010],dpn[1010];
int main(){
    cin>>s;
    rs=s;
    reverse(rs.begin(),rs.end());
    for(int i=1;i<=s.length();i++){
        for(int j=1;j<=s.length();j++)
            dpl[j]=(s[i-1]==rs[j-1]?dpn[j-1]+1:max(dpl[j-1],dpn[j]));
        for(int k=0;k<=s.length();k++)dpn[k]=dpl[k];
    }
    printf("%d",(int)s.length()-dpl[s.length()]);
    return 0;
}