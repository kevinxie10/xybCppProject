#include <cstdio>
#include <queue>
#include <utility>
#include <cstring>
using namespace std;
const int mx[10]={0,2,-2,2,-2,-1,1,-1,1},my[10]={0,1,1,-1,-1,2,2,-2,-2};
int n,m,x,y,mp[500][500];
queue<pair<int,int>> q;
int main(){
	scanf("%d%d%d%d",&n,&m,&x,&y);
	memset(mp,-1,sizeof mp),mp[x][y]=0;
	q.push(make_pair(x,y));
	while(!q.empty()){
		pair<int,int> k=q.front();
		for(int i=1;i<=8;i++){
			int xx=k.first+mx[i],yy=k.second+my[i];
			if(xx>=1&&xx<=n&&yy>=1&&yy<=m&&mp[xx][yy]==-1){
				mp[xx][yy]=mp[k.first][k.second]+1;
				q.push(make_pair(xx,yy));
			}
		}
		q.pop();
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)printf("%-5d",mp[i][j]);
		printf("\n");
	}
	return 0;
} 