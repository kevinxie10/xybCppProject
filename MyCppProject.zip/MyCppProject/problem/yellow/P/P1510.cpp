#include <iostream>
using namespace std;
int v,n,c,k,m;
