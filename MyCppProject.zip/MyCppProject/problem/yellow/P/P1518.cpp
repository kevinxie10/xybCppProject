#include<iostream>
using std::cin;
char mp[12][12];
bool vis[160010];
int f,fx,fy,c,cx,cy,tm,num;
void move(int x,int y,int m,bool h){
	if(m==0){
		if(mp[x-1][y]=='*')(h?c:f)=1;
		else (h?cx:fx)--;
	}
    else if(m==1){
		if(mp[x][y+1]=='*')(h?c:f)=2;
		else (h?cy:fy)++;
	}
    else if(m==2){
		if(mp[x+1][y]=='*')(h?c:f)=3;
		else (h?cx:fx)++;
	}
    else{
		if(mp[x][y-1]=='*')(h?c:f)=0;
		else (h?cy:fy)--;
	}
    return ;
}
bool check(){return(fx!=cx||fy!=cy);}
int main(){
	for(int i=0;i<=11;i++)mp[i][0]='*',mp[i][11]='*';
	for(int i=1;i<=11;i++)mp[0][i]='*',mp[11][i]='*';
    for(int i=1;i<=10;i++){
    	for(int j=1;j<=10;j++){
    		cin>>mp[i][j];
    		if(mp[i][j]=='F')fx=i,fy=j;
    		if(mp[i][j]=='C')cx=i,cy=j;
		}
	}
	while(check()){
		num=fx+fy*10+cx*100+cy*1000+f*10000+c*4*10000;
		if(vis[num]){printf("0");return 0;}
		vis[num]=1,move(fx,fy,f,0),move(cx,cy,c,1),tm++;
	}
	printf("%d",tm);
    return 0;
}
/*#include<bits/stdc++.h>
using namespace std;
char mp[12][12];
int f,fx,fy,c,cx,cy,tm,num;//农夫，奶牛，秒数，专属值
bool vis[160005];//记录专属值是否出现
void mv(int x,int y,int mp,bool h){//移动函数
	if(m==0){
		if(mp[x-1][y]=='*'){
            (h?c;
)            else f=1;
        }
		else{
            (h?cx;
 )           else fx--;
        }
	}
    else if(m==1){
		if(mp[x][y+1]=='*'){
            (h?c;
)            else f=2;
        }
		else{
            (h?cy;
 )           else fy++;
        }
	}
    else if(m==2){
		if(mp[x+1][y]=='*'){
            (h?c;
)            else f=3;
        }
		else{
            (h?cx;
 )           else fx++;
        }
	}
    else{
		if(mp[x][y-1]=='*'){
            (h?c;
)            else f=0;
        }
		else{
            (h?cy;
 )           else fy--;
        }
	}
    return ;
}
bool check(){ //判断循环终止条件：如果奶牛坐标与农夫坐标相等，则他们重叠，返回0，退出循环
	if(fx==cx&&fy==cy)return 0;
	else return 1;
}
//
int main(){
	for(int i=0;i<=11;i++)mp[i][0]='*',mp[i][11]='*';
	for(int i=1;i<=11;i++)mp[0][i]='*',mp[11][i]='*';
    for(int i=1;i<=10;i++){
    	for(int j=1;j<=10;j++){
    		scanf("%c",&mp[i][j]);
    		if(mp[i][j]=='F')fx=i,fy=j;
    		if(mp[i][j]=='C')cx=i,cy=j;
		}
	}
	while(check()){
		num=fx+fy*10+cx*100+cy*1000+f*10000+c*40000;
		if(vis[num]){
            
			printf("0");
			return 0;
		}
		vis[num]=1;//标记
        mv(cx,cy,c,1);
		mv(fx,fy,f,0);
		tm++;//记录秒数
	}
	printf("%d",tm);//输出
    return 0;
}*/