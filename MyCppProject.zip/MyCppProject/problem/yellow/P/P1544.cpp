#include <iostream>
#include <cstring>
using namespace std;
long long n,k,dp[110][110][110],a[110][110],mx=-2147483648;
int main(){
    scanf("%lld%lld",&n,&k);
    if(k>n)k=n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=i;j++)cin>>a[i][j];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=i;j++)
            for(int x=0;x<=k;x++)dp[i][j][x]=-2147483648;
    dp[1][1][0]=a[1][1];
    dp[1][1][1]=3*a[1][1];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=i;j++)
            for(int x=0;x<=k;x++){
                dp[i+1][j][x]=max(dp[i+1][j][x],dp[i][j][x]+a[i+1][j]);
                dp[i+1][j+1][x]=max(dp[i+1][j+1][x],dp[i][j][x]+a[i+1][j+1]);
                dp[i+1][j][x+1]=max(dp[i+1][j][x+1],dp[i][j][x]+3*a[i+1][j]);
                dp[i+1][j+1][x+1]=max(dp[i+1][j+1][x+1],dp[i][j][x]+3*a[i+1][j+1]);
            }
    for(int i=1;i<=n;i++)
        for(int j=0;j<=k;j++)mx=max(mx,dp[n][i][j]);
    printf("%lld",mx);
    return 0;
}