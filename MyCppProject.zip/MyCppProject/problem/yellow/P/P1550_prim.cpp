#include <iostream>
#include <algorithm>
using namespace std;
int a,b,m,fa[1010],x,y,ans,cnt;
struct EDGE{
    int x,y,z;
    bool operator<(const EDGE &a){
        return z<a.z;
    }
}e[90010];
int find(int x){
    return (x==fa[x]?x:fa[x]=find(fa[x]));
}
int main(){
    scanf("%d%d",&a,&b),ans=a;
    for(int i=1;i<=b;i++,fa[i]=i)
        for(int j=1;j<=b;j++){
            scanf("%d",&e[++m].z),e[m].x=i,e[m].y=j;
            if(!e[m].z)e[m].z=a;
            if(e[m].z>a)e[m].z=a;
        }
    sort(e+1,e+1+m);
    for(int i=1;i<=m;i++){
        x=find(e[i].x),y=find(e[i].y);
        if(x==y)continue;
        fa[x]=y,ans+=e[i].z;
        cnt++;
    }
    printf("%d",ans);
    return 0;
}