#include <cstdio>
int n,k,l[10010];
float t;
bool check(int x){
    int cnt=0;
    for(int i=0;i<n;i++)cnt+=l[i]/x;
    return cnt>=k;
}
int main(){
    scanf("%d%d",&n,&k);
    for(int i=0;i<n;i++)scanf("%f",&t),l[i]=t*100;
    int l=0,r=1e9;
    while(l<=r){
        int mid=(l+r)>>1;
        if(!mid)break;
        if(check(mid))l=mid+1;
        else r=mid-1;
    }
    printf("%.2f",(l-1)/100.0);
    return 0;
}