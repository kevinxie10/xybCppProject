#include <cstdio>
#include <algorithm>
int n,a[2][410][410],sum;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            scanf("%d",&a[0][i][j]),a[1][i][j]=a[0][i][j],a[0][i][j]+=a[0][i-1][j-1],a[1][i][j]+=a[1][i-1][j+1];
    for(int k=1;k<=n;k++)
		for(int i=k;i<=n;i++)
			for(int j=k;j<=n;j++)sum=std::max(sum,(a[0][i][j]-a[0][i-k][j-k])-(a[1][i][j-k+1]-a[1][i-k][j+1]));
    printf("%d",sum);
    return 0;
}