#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
const int N=160;
int n,m,dfn[N],low[N],tms,cnt,x,y;
bool cut[N];
vector<int>g[N];
pair<int,int>bri[N];
void tarjan(int x,int root){
    dfn[x]=low[x]=++tms;
    for(auto y:g[x]){
        if(!dfn[y]){
            tarjan(y,x);
            low[x]=min(low[y],low[x]);
            if(low[y]>dfn[x])cnt++,bri[cnt]=make_pair(x,y);
        }
        else if(y!=root)low[x]=min(low[x],dfn[y]);
    }
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&x,&y);
        g[x].push_back(y);
        g[y].push_back(x);
    }
    tarjan(1,1);
    sort(bri+1,bri+1+cnt);
    for(int i=1;i<=cnt;i++)printf("%d %d\n",bri[i].first,bri[i].second);
    return 0;
}