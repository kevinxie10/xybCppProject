#include <iostream>
using namespace std;
int n,m,dp[1510][1510][2],mx;
bool mp[1510][1510];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)scanf("%d",&mp[i][j]);
    bool t=mp[1][1]; 
    for(int i=1;i<=n;t=t=mp[++i][1])
        for(int j=1;j<=m;t=mp[i][++j]){
            dp[i][j][t]=min(dp[i-1][j-1][t],min(dp[i-1][j][!t],dp[i][j-1][!t]))+1;
            mx=max(dp[i][j][t],mx);
        }
    printf("%d",mx);
    return 0;
}