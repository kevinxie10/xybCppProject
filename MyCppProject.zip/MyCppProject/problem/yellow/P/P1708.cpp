#include <cstdio>
#include <cstring>
int T,n,k;
long long dp[110][110],ans;
int main(){
    scanf("%d",&T);
    while(T--){
        scanf("%d%d",&n,&k);
        memset(dp,0,sizeof dp);
        ans=0,dp[0][0]=1;
        for(int i=1;i<=n;i++)
            for(int j=0;j<=k;j++)
                for(int cnt=0;cnt<=9;cnt++)
                    if(j-cnt>=0)dp[i][j]+=dp[i-1][j-cnt];
        for(int i=1;i<=k;i++)ans+=dp[n][i];
        printf("%lld\n",ans);
    }
    return 0;
}