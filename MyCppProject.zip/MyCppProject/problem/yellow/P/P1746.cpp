#include <iostream>
#include <queue>
using namespace std;
struct node{
    int x,y,step;
};
queue<node>q;
const int fx[]={-1,0,1,0},fy[]={0,1,0,-1};
bool vis[1010][1010];
char mp[1010][1010];
int n,x1,y1,x2,y2,mn=2147483647;
void bfs(){
    vis[x1][y1]=true,q.push({x1,y1,0});
    while(!q.empty()){
        struct node k=q.front();
        q.pop();
        for(int i=0;i<4;i++){
            int xx=k.x+fx[i],yy=k.y+fy[i];
            if(xx==x2&&yy==y2)mn=min(mn,k.step+1);
            if(mp[xx][yy]=='0'&&!vis[xx][yy]&&xx>=1&&yy>=1&&xx<=n&&yy<=n)q.push(node{xx,yy,k.step+1}),vis[xx][yy]=true;
        }
    }
}
int main(){
    cin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)cin>>mp[i][j];
    cin>>x1>>y1>>x2>>y2;
    bfs();
    printf("%d",mn);
    return 0;
}