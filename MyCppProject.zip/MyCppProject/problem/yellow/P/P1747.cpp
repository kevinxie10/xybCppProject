#include <cstring>
#include <iostream>
#include <queue>
using namespace std;
struct node{
    int x,y,step;
};
queue<node>q;
const int dx[]={1,1,-1,-1,2,2,-2,-2,2,2,-2,-2},dy[]={2,-2,2,-2,1,-1,1,-1,2,-2,2,-2};
bool vis[50][50];
int x1,y1,x2,y2;
void bfs(int x,int y){
    memset(vis,0,sizeof vis);
    while(!q.empty())q.pop();
    vis[x][y]=true,q.push({x,y,0});
    while(!q.empty()){
        struct node k=q.front();
        q.pop();
        for(int i=0;i<12;i++){
            int xx=k.x+dx[i],yy=k.y+dy[i];
            if(xx==1&&yy==1){printf("%d\n",k.step+1);return ;}
            if(xx>=1&&xx<=50&&yy>=1&&yy<=50&&!vis[xx][yy])vis[xx][yy]=true,q.push({xx,yy,k.step+1});
        }
    }
    return ;
}
int main(){
    scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
    bfs(x1,y1);
    bfs(x2,y2);
    return 0;
}