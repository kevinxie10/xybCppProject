#include <algorithm>
#include <cstdio>
#include <cstring>
int dp[310][310],m[310],n,sum[310];
int main(){
    memset(dp,0x3f,sizeof(dp));
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",m+i),sum[i]=sum[i-1]+m[i],dp[i][i]=0;
    for(int len=2;len<=n;len++)
        for(int i=1;i<=n-len+1;i++){
            int j=i+len-1;
            for(int k=i;k<j;k++)dp[i][j]=std::min(dp[i][k]+dp[k+1][j]+sum[j]-sum[i-1],dp[i][j]);
        }
    printf("%d",dp[1][n]);
    return 0;
}