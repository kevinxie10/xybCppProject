#include <cstdio>
int a[10][10];
bool flag,h[10][10],l[10][10],g[10][10];
int xg[9][9]={
    {1,1,1,2,2,2,3,3,3},
    {1,1,1,2,2,2,3,3,3},
    {1,1,1,2,2,2,3,3,3},
    {4,4,4,5,5,5,6,6,6},
    {4,4,4,5,5,5,6,6,6},
    {4,4,4,5,5,5,6,6,6},
    {7,7,7,8,8,8,9,9,9},
    {7,7,7,8,8,8,9,9,9},
    {7,7,7,8,8,8,9,9,9}
};
void dfs(int k){
    if(flag)return ;
    if(k>80){
        for(int i=0;i<9;i++){
            for(int j=0;j<9;j++)printf("%d ",a[i][j]);
            printf("\n");
        }
        flag=true;
        return ;
    }
    int x=k/9,y=k%9;
    if(a[x][y])dfs(k+1);
    else
        for(int i=1;i<=9;i++){
            if(!h[x][i]&&!l[y][i]&&!g[xg[x][y]][i]){
                h[x][i]=l[y][i]=g[xg[x][y]][i]=1;
                a[x][y]=i;
                dfs(k+1);
                h[x][i]=l[y][i]=g[xg[x][y]][i]=a[x][y]=0;
            }
        }
}
int main(){
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++){
            scanf("%d",&a[i][j]);
            int k=a[i][j];
            h[i][k]=l[j][k]=g[xg[i][j]][k]=1;
        }
    dfs(0);
    return 0;
}