#include<iostream>
#include<map>
#include<algorithm>
using namespace std;
int n;
map<string,int>mp;
struct node{
	string name,doing,ndoing;
	long long num;
	int level,id;
}a[115];
int cmp1(node x,node y){return(x.num==y.num?x.id<y.id:x.num>y.num);}
int cmp2(node x,node y){return(mp[x.ndoing]==mp[y.ndoing]?(x.level==y.level?x.id<y.id:x.level>y.level):mp[x.ndoing]<mp[y.ndoing]);}
int main(){
    mp["BangZhu"]=0,mp["FuBangZhu"]=1,mp["HuFa"]=2,mp["ZhangLao"]=3,mp["TangZhu"]=4,mp["JingYing"]=5,mp["BangZhong"]=6;
    scanf("%d",&n);
	for(int i=1;i<=n;i++)cin>>a[i].name>>a[i].doing>>a[i].num>>a[i].level,a[i].id=i;
	sort(a+4,a+1+n,cmp1);
	for(int i=1;i<=n;i++){
		if(i==1)a[i].ndoing="BangZhu";
		else if(i>=2&&i<=3)a[i].ndoing="FuBangZhu";
		else if(i>=4&&i<=5)a[i].ndoing="HuFa";
		else if(i>=6&&i<=9)a[i].ndoing="ZhangLao";
		else if(i>=10&&i<=16)a[i].ndoing="TangZhu";
		else if(i>=17&&i<=41)a[i].ndoing="JingYing";
		else a[i].ndoing="BangZhong";
	}
	sort(a+1,a+1+n,cmp2);
	for(int i=1;i<=n;i++)cout<<a[i].name<<" "<<a[i].ndoing<<" "<<a[i].level<<endl;
    return 0;
}