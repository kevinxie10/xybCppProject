#include <cstdio>
int n,m,u[8848],v[8848],fa[2024],tot,ans[2024];
int find(int x){return (x==fa[x]?x:fa[x]=find(fa[x]));}
void merge(int x,int y){
    int fx=find(x),fy=find(y);
    if(fx!=fy)fa[fx]=fy;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)scanf("%d%d",u+i,v+i);
    for(int i=2;i<n;i++){
        for(int i=1;i<=n;i++)fa[i]=i;
        for(int j=1;j<=m;j++)
            if(u[j]!=i&&v[j]!=i)merge(u[j],v[j]);
        if(find(1)!=find(n))ans[++tot]=i;
    }
    printf("%d\n",tot);
    for(int i=1;i<=tot;i++)printf("%d ",ans[i]);
    return 0;
}
