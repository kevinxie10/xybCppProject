#include <iostream>
#include <string>
#include <cstring>
using namespace std;
int n,num[50][50],dp[50][100010];
string s;
int main(){
    cin>>s;
    scanf("%d",&n);
    for(int i=1;i<s.length();i++)
        for(int j=i;j<=s.length();j++)dp[i][j]=(dp[i][j-1]<<1)+(dp[i][j-1]<<3)+(s[j-1]^'0');
    memset(dp,0x3f3f3f3f,sizeof dp),dp[0][0]=-1;
    for(int i=1;i<s.length();i++)
        for(int j=0;j<=n;j++){
            for(int j=i-1;j>=0&&num[j+1][i]<=n;j--)
        }
}