#include<cstdio>
#include<queue>
using namespace std;
deque <int> q;
int a[1000010],mn[1000010],mx[1000010],n,k;
int main(){
    scanf("%d%d",&n,&k);
	for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
		while(!q.empty()&&a[i]<=a[q.back()])q.pop_back();
		q.push_back(i);
		mn[i]=a[q.front()];
		if(q.front()+k<=i+1&&i+1>=k)q.pop_front();				
	}
	for(int i=k-1;i<n;i++)printf("%d ",mn[i]);
	while(!q.empty())q.pop_back();
	printf("\n");
	for(int i=0;i<n;i++){
		while(!q.empty()&&a[q.back()]<=a[i])q.pop_back();
        q.push_back(i);
		mx[i]=a[q.front()];
		if(q.front()+k<=i+1&&i+1>=k)q.pop_front();
	}		
	for(int i=k-1;i<n;i++)printf("%d ",mx[i]);	
	return 0;
}