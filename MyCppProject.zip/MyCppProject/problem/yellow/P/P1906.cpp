#include<iostream>
#include<map>
#include<vector>
using namespace std;
map<char,int>cnt;
string s,st;
vector<string>txt;
int t;
int findt(string s){
	long long maxv=-1,maxk=0;
	for(map<char,int>::iterator iter=cnt.begin();iter!=cnt.end();iter++)if(iter->second>maxv){maxv=iter->second,maxk=iter->first;}
	return maxk-'E';
}
string translate(string s,int t){
	for(int i=0;i<s.length();i++)
		if(s[i]>='A'&&s[i]<='Z'){
			s[i]-=t,(s[i]>'Z'?s[i]-=26:s[i]=s[i]),(s[i]<'A'?s[i]+=26:s[i]=s[i]);
		}
	return s;
}
int main(){
	while(true){
		cin>>st;
		if(st=="ENDOFINPUT")break;
		getline(cin,s);
		getline(cin,s);
		for(int i=0;i<s.length();i++)if(s[i]>='a'&&s[i]<='z')s[i]-=32;
		for(int i=0;i<s.length();i++)cnt[s[i]]+=(s[i]>='A'&&s[i]<='Z');
		txt.push_back(s);
		cin>>st;
	}
	t=findt(s);
	for(int i=0;i<txt.size();i++)cout<<translate(txt[i],t)<<'\n';
	return 0;
}