#include <cstdio>
int n,a[500010],b[500010];
long long ans;
void msort(int l,int r){
    if(l==r)return ;
    int mid=(l+r)>>1;
    msort(l,mid);
    msort(mid+1,r);
    for(int i=l,j=mid+1,k=l;i<=mid||j<=r;){
        if(i<=mid&&(j>r||a[i]<=a[j])){b[k++]=a[i++];ans+=j-mid-1;}
        else b[k++]=a[j++];
    }
    for(int i=l;i<=r;i++)a[i]=b[i];
    return ;
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    msort(1,n);
    printf("%lld",ans);
    return 0;
}