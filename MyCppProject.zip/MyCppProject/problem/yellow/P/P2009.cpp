#include <iostream>
#include <cstring>
using namespace std;
int n,k,t,d[110][110],l;
char a,b;
int main(){
    scanf("%d%d",&n,&k);
    memset(d,0x3f,sizeof d);
    for(int i=1;i<=n;i++){
        scanf("%d",&t);
        d[i][i%n+1]=d[i%n+1][i]=(d[i][i%n+1]==0x3f3f3f3f?t:max(t,d[i][i%n+1]));
    }
    for(int i=1;i<=k;i++){
        cin>>a>>b>>l;
        a-='A'-1,b-='A'-1;
        d[a][b]=d[b][a]=(d[a][b]==0x3f3f3f3f?l:max(l,d[a][b]));
    }
    cin>>a>>b;
    a-='A'-1,b-='A'-1;
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
    printf("%d",d[a][b]);
    return 0;
}