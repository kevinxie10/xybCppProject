#include <iostream>
#include <vector>
using namespace std;
const int N=1000010;
struct node{
    long long x,len;
};
vector<node>g[1000010];
long long n,a,b,c,ans,size[N];
void dfs(int x,int y){
    size[x]=1;
    for(auto i:g[x]){
        if(i.x!=y){
            dfs(i.x,x);
            size[x]+=size[i.x];
            ans+=i.len*abs(size[i.x]-(n-size[i.x]));
        }
    }
}
int main(){
    scanf("%lld",&n);
    for(int i=1;i<n;i++){
        scanf("%lld%lld%lld",&a,&b,&c);
        g[a].push_back({b,c});
        g[b].push_back({a,c});
    }
    dfs(1,0);
    printf("%lld",ans);
    return 0;
}