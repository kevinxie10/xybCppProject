#include<iostream>
int n,mn=1e9;
void search(int x,int y,int cnt){
    if(cnt>mn)return ;
    if(x==1&&y==1){mn=std::min(mn,cnt);return ;}
    if(x<1||y<1)return ;
    if(x>y)search(x-y,y,cnt+1);
    else if(y>x)search(x,y-x,cnt+1);
    return ;
}
int main(){
    scanf("%d",&n);
    for(int i=2;i<n;i++)search(i,n,0);
    printf("%d",mn);
    return 0;
}