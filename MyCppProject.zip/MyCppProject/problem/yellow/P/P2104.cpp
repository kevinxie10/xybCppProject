#include<cstdio>
char s[100000000],op[5000010];
int n,m;
int main(){
	scanf("%d%d%s%s",&n,&m,s,op);
	for(int i=0;i<m;i++){
		switch(op[i]){
			case '*':s[n++]='0';break;
			case '/':s[n--]=0;break;
			case '+':for(int k=n;s[k--]!='0'&&(s[k]='0')||!(s[k]='1'););break;
			case '-':for(int k=n;s[k--]!='1'&&(s[k]='1')||!(s[k]='0'););break;
		}
    }
	puts(s);
    return 0;
}