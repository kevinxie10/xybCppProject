#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,k,fa[100010],ans;
struct node{
    int u,v,w;
}a[100010];
bool comp (const node &a,const node&b){return a.w>b.w;}
int find(int x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
int main(){
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=m;i++)scanf("%d%d%d",&a[i].u,&a[i].v,&a[i].w);
    sort(a+1,a+m+1,comp);
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1,cnt=0;i<=m&&cnt<k;i++)
        if(find(a[i].u)!=find(a[i].v))fa[find(a[i].u)]=find(a[i].v),ans+=a[i].w,cnt++;
    printf("%d",ans);
    return 0;
}