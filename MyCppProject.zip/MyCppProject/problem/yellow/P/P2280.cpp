#include <iostream>
using namespace std;
int n,m,x,y,v,sum[5010][5010];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("%d%d%d",&x,&y,&v);
        sum[x][y]=
    }
}