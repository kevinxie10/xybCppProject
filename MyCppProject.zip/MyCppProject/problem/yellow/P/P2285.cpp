#include <iostream>
using namespace std;
struct node{
    int t,x,y;
}a[10010];
int n,m,dp[10010],ans;
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)scanf("%d%d%d",&a[i].t,&a[i].x,&a[i].y);
    for(int i=1;i<=m;i++){
        dp[i]=1;
        for(int j=1;j<i;j++)
            if(a[i].t-a[j].t>=abs(a[i].x-a[j].x)+abs(a[i].y-a[j].y))dp[i]=max(dp[i],dp[j]+1);
    }
    for(int i=1;i<=m;i++)ans=max(ans,dp[i]);
    printf("%d",ans);
    return 0;
}