#include <iostream>
#include <queue>
using namespace std;
struct node{
    int x,y,step;
};
int n,m,sum,mx,my,dx,dy,mncnt=1141919810,movex[]={-1,1,0,0},movey[]={0,0,-1,1};
char mp[2010][2010];
bool vis[2010][2010];
queue<node>q;
void bfs(){
    q.push({mx,my,0}),vis[mx][my]=true;
    while(!q.empty()){
        node k=q.front();
        q.pop();
        for(int i=0;i<4;i++){
            int xx=k.x+movex[i],yy=k.y+movey[i];
            if(xx==dx&&yy==dy)mncnt=min(mncnt,++k.step);
            if(mp[xx][yy]=='.'&&!vis[xx][yy])q.push({xx,yy,k.step+1}),vis[xx][yy]=true;
        }
    }
    if(mncnt==1141919810)printf("No Way!");
    else printf("%d",mncnt);
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++){
            while(true){
                scanf("%c",&mp[i][j]);
                if(!isspace(mp[i][j]))break;
            }
            if(mp[i][j]=='m')mx=i,my=j;
            if(mp[i][j]=='d')dx=i,dy=j;
        }
    bfs();
    return 0;
}