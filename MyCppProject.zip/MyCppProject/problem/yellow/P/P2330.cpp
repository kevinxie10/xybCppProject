#include <algorithm>
#include <cstdio>
int fa[100010];
struct node{
    int u,v,c;
    bool operator<(const node &a)const{
        return c<a.c;
    }
}e[100010];
int find(int x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
void merge(int x,int y){
    int fx=find(x),fy=find(y);
    if(fx!=fy)fa[fx]=fy;
    return ;
}
int n,m,mxc,cnt;
int main(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)fa[i]=i;
    for(int i=0;i<m;i++)scanf("%d%d%d",&e[i].u,&e[i].v,&e[i].c);
    std::sort(e,e+m);
    for(int i=0;i<m;i++)
        if(find(e[i].u)!=find(e[i].v)){
            mxc=e[i].c,merge(e[i].u,e[i].v),cnt++;
            if(cnt+1==n)break;
        }
    printf("%d %d",n-1,mxc);
    return 0;
}