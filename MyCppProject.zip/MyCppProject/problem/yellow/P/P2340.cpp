#include <cstdio>
#include <cstring>
#define MAX(x,y) ((x)>(y)?(x):(y))
using namespace std;
int dp[800010],n,s,f,ans;
int main(){
	memset(dp,-0x3f,sizeof dp);
	dp[400000]=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&s,&f);
		if(s>=0)
			for(int j=800000;j>=s;j--)
				dp[j]=MAX(dp[j],dp[j-s]+f);
		else
			for(int j=0;j<=800000+s;j++)
				dp[j]=MAX(dp[j],dp[j-s]+f);
	}
	for(int i=400000;i<=800000;i++)
		if(dp[i]>0)ans=MAX(ans,i+dp[i]-400000);
	printf("%d",ans);
	return 0;
}