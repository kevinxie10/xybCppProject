#include<cstdio>
int t,m,a[30],sum;
bool flag;
void dfs(int i,int w,int x,int y,int z){
	if(flag||w>sum||x>sum||y>sum||z>sum)return;
	if(i>m){
		if(w==x&&x==y&&y==z)printf("yes\n"),flag=true;
        return ;
    }
	dfs(i+1,w+a[i],x,y,z),dfs(i+1,w,x+a[i],y,z),dfs(i+1,w,x,y+a[i],z),dfs(i+1,w,x,y,z+a[i]);
}
int main(){
	scanf("%d",&t);
	while(t--){
		scanf("%d",&m),sum=0,flag=0;
		for(int i=1;i<=m;i++)scanf("%d",a+i),sum+=a[i];
		if(sum%4){printf("no\n");continue;}
	    sum/=4,dfs(1,0,0,0,0);
		if(!flag)printf("no\n");
	}
	return 0;
}