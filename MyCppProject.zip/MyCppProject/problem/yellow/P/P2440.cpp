#include<bits/stdc++.h>
using namespace std;
long long n,k,m=0,a[1000010],cnt,x=0;
int main(){
    scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%lld",a+i);
		m=(a[i]>m?a[i]:m);
	}
	for(x=m;x>=1;x-=1000000){
		cnt=0;
		for(int i=1;i<=n;i++){
			cnt+=a[i]/x;
		}
		if(cnt >=k)
			break;
	}
	x+=1000000;
	for(;x>=1;x-=10000){
		cnt=0;
		for(int i=1;i<=n;i++){
			cnt+=a[i]/x;
		}
		if(cnt >=k){
			break;
		}
	}
	x+=10000;
	for(;x>=1;x-=100){
		cnt=0;
		for(int i=1;i<=n;i++){
			cnt+=a[i]/x;
		}
		if(cnt >=k){
			break;
		}
	}
	x+=100;
	for(;x>=1;x-=1){
		cnt=0;
		for(int i=1;i<=n;i++){
			cnt+=a[i]/x;
		}if(cnt >=k){
			cout << x <<endl;
			return 0;
		}
		
	}
	cout << 0;
	return 0;
}