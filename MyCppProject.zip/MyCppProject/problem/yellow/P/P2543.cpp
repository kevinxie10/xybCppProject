#include <iostream>
using namespace std;
string x,y;
int dp[10010][2];
int main(){
    cin>>x>>y;
    for(int i=1;i<=x.size();i++)
        for(int j=1;j<=y.size();j++)
            dp[j][i&1]=(x[i-1]==y[j-1]?dp[j-1][(i-1)&1]+1:max(dp[j][(i-1)&1],dp[j-1][i&1]));
    printf("%d",dp[y.size()][x.size()&1]);
    return 0;
}