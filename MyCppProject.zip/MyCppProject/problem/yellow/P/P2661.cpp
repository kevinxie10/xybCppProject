#include<iostream>
using namespace std;
int n,t,cnt,len[200010],fa[200010],ans=2147483647;
int find(int x){
    if(fa[x]==x)return x;
    int fx=find(fa[x]);
	len[x]+=len[fa[x]];
	fa[x]=fx;
	cnt=len[x]+1;
	return fa[x];
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1;i<=n;i++){
        scanf("%d",&t),cnt=0;
        if(find(t)==i)ans=(cnt<ans?cnt:ans);
        else len[i]=1,fa[i]=t;
    }
    printf("%d",ans);
    return 0;
}