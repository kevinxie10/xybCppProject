#include <iostream>
#include <cstring>
using std::min;
int n,m,op,a,b,c,d[110][110];
int main(){
    memset(d,0x3f3f3f3f,sizeof d);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)d[i][i]=0;
    while(m--){
        scanf("%d%d%d",&op,&a,&b);
        if(op){
            scanf("%d",&c);
            if(d[a][b]>c){
                d[a][b]=d[b][a]=c;
                for(int i=1;i<=n;i++)
                    for(int j=1;j<=n;j++)
                        d[i][j]=min(d[i][j],min(d[i][a]+d[a][b]+d[b][j],d[i][b]+d[b][a]+d[a][j]));
            }
        }
        else printf("%d\n",(d[a][b]==0x3f3f3f3f?-1:d[a][b]));
    }
    return 0;
}
