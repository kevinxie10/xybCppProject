#include <queue>
#include <iostream>
#include <vector>
using namespace std;
int n,m,a[500010],cnt,k,rd[500010],y;
bool t[500010];
vector<int> g[500010];
queue<int> q;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d%d",a+i,&m);
        t[a[i]]=true;
        for(int j=1;j<=m;j++){
            scanf("%d",&y);
            g[a[i]].push_back(y);
            rd[y]++;
        }
    }
    for(int i=1;i<=n;i++)
        if(!rd[a[i]]){
            cnt++;
            q.push(a[i]);
        }
    while(q.size()){
        int x=q.front();q.pop();
        for(auto i:g[x]){
            rd[i]--;
            if(!rd[i]){
                if(t[i])cnt++;
                q.push(i);
            }
        }
    }
    if(n==cnt){printf("YES");return 0;}
    printf("%d",n-cnt);
    return 0;
}