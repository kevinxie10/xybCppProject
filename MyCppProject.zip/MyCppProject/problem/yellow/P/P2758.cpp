#include <iostream>
using namespace std;
string a,b;
int dp[2010][2010];
int main(){
    cin>>a>>b;
    for(int i=0;i<=a.length();i++)dp[i][0]=i;
    for(int j=0;j<=b.length();j++)dp[0][j]=j;
    for(int i=1;i<=a.length();i++)
        for(int j=1;j<=b.length();j++)dp[i][j]=(a[i-1]==b[j-1]?dp[i-1][j-1]:min(dp[i-1][j-1],min(dp[i-1][j],dp[i][j-1]))+1);
    printf("%d",dp[a.length()][b.length()]);
    return 0;
}