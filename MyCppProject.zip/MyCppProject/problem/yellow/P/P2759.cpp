#include<cstdio>
#include<cmath>
long long x,l=1,r=3e9,mid;
int main(){
    scanf("%lld",&x);
    while(l<r){
        mid=(l+r)>>1;
        if(mid*log10(1.0*mid)+1<x)l=mid+1;
        else r=mid;
    }
    printf("%lld",l);
    return 0;
}