#include <cstdio>
#include <algorithm>
struct Point{
    int x,y;
    bool operator<(const Point &a)const{
        return (y==a.y?x>a.x:y>a.y);
    }
}p[500010];
int n,x;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d%d",&p[i].x,&p[i].y);
    std::sort(p+1,p+1+n),x=p[1].x;
    printf("(%d,%d)",p[1].x,p[1].y);
    for(int i=2;i<=n;i++)
        if(p[i].x>x)printf(",(%d,%d)",p[i].x,p[i].y),x=p[i].x;
    return 0;
}