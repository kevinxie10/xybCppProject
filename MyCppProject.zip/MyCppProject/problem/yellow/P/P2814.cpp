#include <iostream>
#include <map>
using namespace std;
char op;
string s,fs;
map<string,string>fa;
string find(string x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
int main(){
    while(true){
        cin>>op>>s;
        switch(op){
            case '$':return 0;
            case '#':fs=s;if(fa[s]=="")fa[s]=s;break;
            case '+':fa[s]=fs;break;
            default:cout<<s<<' '<<find(s)<<'\n';
        }
    }
    return 0;
}