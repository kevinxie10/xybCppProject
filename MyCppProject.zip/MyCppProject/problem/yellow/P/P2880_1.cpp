#include <iostream>
#include <cmath>
int n,m,dp1[100010][18],dp2[100010][18],l,r;
int find(int l,int r){
    int k=log2(r-l+1);
    return fmax(dp1[l][k],dp1[r-(1<<k)+1][k])-fmin(dp2[l][k],dp2[r-(1<<k)+1][k]);
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",&dp1[i][0]),dp2[i][0]=dp1[i][0];
    for(int j=1;j<=17;j++)
        for(int i=1;i<=n;i++){
            if(i+(1<<(j-1))>n)break;
            dp1[i][j]=fmax(dp1[i][j-1],dp1[i+(1<<(j-1))][j-1]);
            dp2[i][j]=fmin(dp2[i][j-1],dp2[i+(1<<(j-1))][j-1]);
        }
    while(m--)scanf("%d%d",&l,&r),printf("%d\n",find(l,r));
    return 0;
}