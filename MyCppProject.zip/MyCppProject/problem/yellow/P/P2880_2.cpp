#include <cstring>
#include <iostream>
#include <cmath>
using namespace std;
const int N=50010,M=300;
int n,q,a[N],len,t,l[M],r[M],pos[N],mx[M],mn[M];
void nxt(){
    memset(mn,0x3f,sizeof mn);
    len=sqrt(n);
    t=n/len;
    if(n%len)t++;
    for(int i=1;i<=t;i++)l[i]=(i-1)*len+1,r[i]=i*len+len;
    r[t]=n;
    for(int i=1;i<=t;i++)
        for(int j=l[i];j<=r[i];j++){
            mx[i]=max(mx[i],a[j]);
            mn[i]=min(mn[i],a[j]);
            pos[j]=i;
        }
    return ;
}
int query(int x,int y){
    int mxans=0,mnans=2147483647;
    if(pos[x]==pos[y])
        for(int i=x;i<=y;i++)mxans=max(a[i],mxans),mnans=min(a[i],mnans);
    else{
        for(int i=x;i<=r[pos[x]];i++)mxans=max(a[i],mxans),mnans=min(a[i],mnans);
        for(int i=pos[x]+1;i<=pos[y]-1;i++)mxans=max(mx[i],mxans),mnans=min(mn[i],mnans);
        for(int i=l[pos[y]];i<=y;i++)mxans=max(a[i],mxans),mnans=min(a[i],mnans);
    }
    return mxans=mnans;
}
int main(){
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    nxt();
    while(q--){
        int x,y;
        scanf("%d%d",&x,&y);
        printf("%d\n",query(x,y));
    }
    
}
