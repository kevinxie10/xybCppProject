#include<bits/stdc++.h>
using namespace std;
const int N=500010;
int n,t,q,c[N];
int lowbit(int x){return x&-x;}
void add(int x,int k){
	for(int i=x;i<=n;i+=lowbit(i))c[i]+=k;
}
int find(int x){
	int sum=0;
	for(int i=x;i>0;i-=lowbit(i))sum+=c[i];
	return sum;
}
int main(){
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)scanf("%d",&t),add(i,t);
	while(q--){
		int op,x,l,r,k;
		scanf("%d",&op);
		if(op==1)scanf("%d%d",&x,&k),add(x,k);
		else scanf("%d%d",&l,&r),printf("%d\n",find(r)-find(l-1));
	}
	return 0;
}
