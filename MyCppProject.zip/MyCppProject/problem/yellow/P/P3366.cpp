#include <cstdio>
#include <algorithm>
using namespace std;
struct node{
    int x,y,z;
}e[200010];
int fa[5010],n,m,ans;
inline bool cmp(const node&a,const node&b){return a.z<b.z;}
int find(int x){
    if(fa[x]==x)return x;
    return fa[x]=find(fa[x]);
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)scanf("%d%d%d",&e[i].x,&e[i].y,&e[i].z);
    for(int i=1;i<=n;i++)fa[i]=i;
    sort(e+1,e+m+1,cmp);
    for(int i=1;i<=m;i++){
        int x=find(e[i].x),y=find(e[i].y);
        if(x==y)continue;
        ans+=e[i].z;
        fa[x]=y;
    }
    for(int i=2;i<=n;i++)
        if(find(1)!=find(n)){printf("orz");return 0;}
    printf("%d",ans);
    return 0;
}