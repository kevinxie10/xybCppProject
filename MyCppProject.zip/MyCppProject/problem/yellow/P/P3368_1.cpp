#include<bits/stdc++.h>
using namespace std;
const int N=500010;
long long n,q,a[N],ans;
struct node{
	int l,r;
	long long v;
}tree[N<<2];
void build(int i,int l,int r){
	tree[i].l=l;
	tree[i].r=r;
	if(l==r){
		tree[i].v=a[l];
		return ;
	}
	int mid=(l+r)>>1;
	build(i<<1,l,mid);
	build(i<<1|1,mid+1,r);
}
void add(int i,int l,int r,long long k){//这里相当于只传了一个参数i 
	if(tree[i].l>=l&&tree[i].r<=r){//完全覆盖则标记返回 
		tree[i].v+=k;// 某个段数树内所有节点均添加了k 
		return ;
	}
	if(tree[i<<1].r>=l)add(i<<1,l,r,k);//如果该层区间做儿子和查找区间有交集,递归 
	if(tree[i<<1|1].l<=r)add(i<<1|1,l,r,k);
}
void find(int i,int x){//单点查询 
	ans+=tree[i].v;
	if(tree[i].l==tree[i].r)return ;
	if(tree[i<<1].r>=x)find(i<<1,x);
	if(tree[i<<1|1].l<=x)find(i<<1|1,x);
}
int main(){
	scanf("%lld%lld",&n,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",a+i);
	}
	build(1,1,n);
	while(q--){
		int op,l,r,k;
		scanf("%d",&op);
		if(op==1){
			scanf("%d%d%d",&l,&r,&k);
			add(1,l,r,k);
		}
		else{
			scanf("%d",&k);
			ans=0;
			find(1,k);
			printf("%lld\n",ans);
		}
	}
	return 0;
}