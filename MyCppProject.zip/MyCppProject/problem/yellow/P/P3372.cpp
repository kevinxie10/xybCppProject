#include <bits/stdc++.h>
using namespace std;
int op,x,y,k;
long long n,m,a[500010];
struct node{
    int l,r,flag;
}tree[100010<<2];
void build(int i,int l,int r){
    tree[i].l=l,tree[i].r=r;
    int mid=(l+r)>>1;
    build(i<<1,l,mid),build(i<<1|1,mid+1,r);
    tree[i].sum=tree[i<<1].sum+tree[i<<1|1].sum;
    return ;
}
void add(int i,int l,int r,int k){
    if(l<=tree[i].l&&tree[i].r<=r){
        tree[i].sum+=k;
        return ;
    }
    int mid=(tree[i].l+tree[i].r)>>1;
    if(l<=mid)add(i<<1,l,r,k);
    if(mid+1<=r)add(i<<1|1,l,r,k);
    tree[i].sum=tree[i<<1].sum+tree[i<<1|1].sum;
    return ;
}
long long query(int i,int x){
    if(tree[i].l==tree[i].r)return tree[i].sum;
    int mid=(tree[i].l+tree[i].r)>>1;
    long long ans;
    if(x<=mid)ans=query(i<<1,x);
    else ans=query(i<<1|1,x);
    return ans;
}
int main(){
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=n;i++)scanf("%lld",a+i);
    build(1,1,n);
    for(int i=1;i<=n;i++){
        scanf("%d",&op);
        if(op==1){
            scanf("%d%d%d",&x,&y,&k);
            add(1,x,y,k);
        }
        else{
            scanf("%d",&x);
            ans=0;
            printf("%d\n")
        }
    }
}