#include <cstdio>//wrong TLE 80
int n,p,x,y;
char c;
void exgcd(int a,int b){
    if(!b){x=1,y=0;return;}
    exgcd(b,a%b);
    int xx=x;
    x=y;
    y=xx-a/b*y;
}
void read(int &n){
    c=getchar();
    while(c<'0'||c>'9')c=getchar();
    while(c>='0'&&c<='9')n=(n<<3)+(n<<1)+(c^48),c=getchar();
    return ;
}
void write(int x){
    if(x>9)write(x/10);
    putchar(x%10^48);
}
int main(){
    read(n),read(p);
    for(int i=1;i<=n;i++)exgcd(i,p),write((x%p+p)%p),putchar('\n');
    return 0;
}