#include <cstdio>//wrong TLE 64
long long n,p;
long long power(long long a,long long p,long long mod){
    a%=p;
    long long ans=1;
    while(p){
        if(p&1)ans=ans*a%mod;
        a=a*a%mod;
        p>>=1;
    }
    return ans%mod;
}
int main(){
    scanf("%lld%lld",&n,&p);
    for(int i=1;i<=n;i++)printf("%lld\n",power(i,p-2,p));
    return 0;
}