#include <iostream>
using namespace std;
struct Country{
    int id,v;
}dp[10][150];
inline Country max(const Country &a,const Country &b){
    return (a.v>b.v?Country{a.id,a.v}:Country{b.id,b.v});
}
inline int min(const Country &a,const Country &b){
    return (a.v<b.v?a.id:b.id);
}
int n;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=1<<n;i++)scanf("%d",&dp[0][i].v),dp[0][i].id=i;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=1<<(n-i);j++)dp[i][j]=max(dp[i-1][j<<1],dp[i-1][(j<<1)-1]);
    printf("%d",min(dp[n-1][1],dp[n-1][2]));
    return 0;
}