#include <iostream>
#include <stack>
#include <queue>
using namespace std;
int t,n,temp,pu[100010];
stack<int> s;
queue<int> q;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=0;i<n;i++)scanf("%d",pu+i);
        for(int i=0;i<n;i++)scanf("%d",&temp),q.push(temp);
        for(int i=0,j=1;i<n;i++){
            s.push(pu[i]);
            while(s.top()==q.front()){
                s.pop(),q.pop();
                if(s.empty())break;
            }
        }
        printf("%s\n",(s.empty()?"Yes":"No"));
        while(!s.empty())s.pop();
        while(!q.empty())q.pop();
    }
    return 0;
}