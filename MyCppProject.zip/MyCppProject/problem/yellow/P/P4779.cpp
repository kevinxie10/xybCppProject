#include <cstring>
#include <iostream>
#include <queue>
#include <utility>
#include <vector>
#define pii pair<int,int>
using namespace std;
const int N=200010;
int n,m,s,vis[N],dis[N],x,y,z;
vector<pii>g[N];
priority_queue<pii,vector<pii>,greater<pii>>q;
void dij(){
    q.push({0,s});
    while(q.empty()){
        pii k=q.top();
        q.pop();
        if(vis[k.second])continue;
        vis[k.second]=1;
        for(auto i:g[k.second]){
            dis[i.second]=min(dis[k.second]+i.first,dis[i.second]);
            if(vis[i.second])continue;
            q.push({dis[i.second],i.second});
        }
    }
    return ;
}
int main(){
    scanf("%d%d%d",&n,&m,&s);
    for(int i=1;i<=m;i++)scanf("%d%d%d",&x,&y,&z),g[x].push_back({z,y});
    memset(dis,0x3f,sizeof dis);
    dis[s]=0;
    dij();
    for(int i=1;i<=n;i++)printf("%d ",dis[i]);
    return 0;
}