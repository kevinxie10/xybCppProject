#include<cstdio>
struct node{
	int lft;
    int rght;
}t[1000010];
int mx=-1000000,n;
void dfs(int root,int deep){
	if(!root)return;
	mx=(deep>mx?deep:mx);
    deep++;
	dfs(t[root].lft,deep);
	dfs(t[root].rght,deep);
}
int main(){
    scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d%d",&t[i].lft,&t[i].rght);
	dfs(1,1); 
    printf("%d",mx);
	return 0;
}