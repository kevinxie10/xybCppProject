#include <cstdio>
#include <algorithm>
int n,h[310];
long long ans,l,r;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",h+i);
    std::sort(h+1,h+1+n),r=n;
    while(l<r){
		ans+=(h[r]-h[l])*(h[r]-h[l]),++l;
		ans+=(h[l]-h[r])*(h[l]-h[r]),--r;
	}
    printf("%lld",ans);
    return 0;
}