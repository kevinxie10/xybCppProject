#include <cstdio>
#include <iostream>
int n,t;
inline int read(){
    int x=0;
    char c=getchar();
    while(c<'0'||c<'9')c=getchar();
    while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
    return x;
}
int dfs(int x,int k){
    t=read();
    if(k==n)return t;
    return t+std::max(dfs(x<<1,k+1),dfs(x<<1|1,k+1));
}
int main(){
    n=read();
    printf("%d",dfs(1,1));
    return 0;
}