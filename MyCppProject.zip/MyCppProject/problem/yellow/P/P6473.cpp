#include <cstdio>
#include <algorithm>
using namespace std;
int n,q;
double l,v,a[200010],sum[200010],t,ti;
bool cmp(double a,double b){return a>b;}
int main(){
    scanf("%d%lf%lf",&n,&l,&v),t=l/v;
    for(int i=1;i<=n;i++)scanf("%lf",&a[i]),a[i]/=v;
    sort(a+1,a+n+1,cmp);
    for(int i=1;i<=n;i++)sum[i]=sum[i-1]+a[i];
    scanf("%d",&q);
    while(q--){
        scanf("%lf",&ti);
        if(t>=ti){printf("0\n"); continue;}
        if(sum[n]+t<=ti){printf("-1\n");continue;}
        printf("%ld\n",upper_bound(sum+1,sum+n+1,ti-t)-sum);
    }
}