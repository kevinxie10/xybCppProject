#include <iostream>
#include <algorithm>
int n,a[3];
int main(){
	scanf("%d",&n);
	while(n--){
		scanf("%d%d%d",a,a+1,a+2);
		std::sort(a,a+3);
		if(a[0]==0){
			if(a[1]==0)puts("0");
			else if(a[1]==a[2])puts("1");
			else puts("2");
		}
		else if(a[0]==a[1]||a[1]==a[2])puts("2");
		else if(a[0]+a[1]==a[2])puts("2");
		else puts("3");
	} 
	return 0;
}
/*
6
0 0 8
0 5 3
9 9 0
6 2 4
1 7 4
5 8 5
*/