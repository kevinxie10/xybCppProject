#include <iostream>
#include <algorithm>
using namespace std;
int n,m,b[10010];
struct node{
    int w,id;
}a[10010];
bool cmp(node a,node b){return (a.w==b.w?a.id<b.id:a.w<b.w);}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",&a[i].w),a[i].id=i;
    sort(a+1,a+1+n,cmp);
    for(int i=1;i<=n;i++)b[a[i].id]=i;
    while(m--){
        int op,x,v;
        scanf("%d",&op);
        if(op==1){
            scanf("%d%d",&x,&v);
            a[b[x]].w=v;
            for(int i=n;i>=2;i--)
				if(cmp(a[i],a[i-1])){
					node t=a[i];
					a[i]=a[i-1];
					a[i-1]=t;
				}
			for(int i=2;i<=n;i++)
				if(cmp(a[i],a[i-1])){
					node t=a[i];
					a[i]=a[i-1];
					a[i-1]=t;
				}
            for(int i=1;i<=n;i++)b[a[i].id]=i;
        }
        else{
            scanf("%d",&x);
            printf("%d\n",b[x]);
        }
    }
    return 0;
}