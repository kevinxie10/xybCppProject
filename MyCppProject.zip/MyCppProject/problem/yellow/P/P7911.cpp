#include <iostream>
#include <cstring>
#include <map>
#define is(t) ((t)<0||(t)>255)
using namespace std;
map<string,int>tong;
string op,ad;
char t[110];
int n,a,b,c,d,e;
bool check(string s){
	memset(t,0,sizeof t);
	a=b=c=d=e=114514;
	int len=sscanf(s.c_str(),"%d.%d.%d.%d:%d",&a,&b,&c,&d,&e);
	if(len!=5||is(a)||is(b)||is(c)||is(d)||e<0||e>65535)return true;
	sprintf(t,"%d.%d.%d.%d:%d",a,b,c,d,e);
	bool flag=false;
	for(int i=0;i<s.length();i++)if(s[i]!=t[i])flag=true;
	return flag;
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        cin>>op>>ad;
		if(op=="Server"){
        	if(check(ad)){printf("ERR\n");continue;}
			if(tong.tong(ad)){printf("FAIL\n");continue;}
			printf("OK\n");
			tong[ad]=i;
		}
		else{
			if(check(ad)){printf("ERR\n");continue;}
			if(!tong.tong(ad)){printf("FAIL\n");continue;}
			printf("%d\n",tong[ad]);
		}
    }
	return 0;
}
