#include<bits/stdc++.h>
using namespace std;
int t,n,a[1010],b[1010],aa[1010],bb[1010];
int read(){
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')ch=getchar();
    while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
    return x;
}
void solve(){
	n=read();
	for(int i=1;i<=n;i++)scanf("%d",a+i),aa[i]=a[i];
	for(int i=1;i<=n;i++)scanf("%d",b+i),bb[i]=b[i];
	sort(aa+1,aa+n+1),sort(bb+1,bb+n+1);
	for(int i=1;i<=n;i++)if(aa[i]!=bb[i]){puts("NO");return;}
	puts("YES");
	for(int i=1,x;i<=n;i++){
		for(int j=i;j<=n;j++)
			if(a[j]==b[i]){x=j;break;}
		for(int j=x;j>i;j--)swap(a[j],a[j-1]),printf("%d %d\n",j,j-1);
	}
    printf("0 0\n");
}
int main(){
	t=read();
	while(t--)solve();
    return 0;
}