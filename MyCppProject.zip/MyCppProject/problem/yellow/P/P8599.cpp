#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;
int shu[9]={1,2,3,4,5,6,7,8,9};
int n,ans;
vector<int> a;
int solve(int l,int r){
	int ans=0;
	for(int i=l;i<=r;i++)ans=ans*10+shu[i];
	return ans;
}
int main(){
    scanf("%d",&n);
    do{
        for(int i=0;i<10;i++){
            int num=solve(0,i);
            for(int j=i+1;j<8;j++)ans+=(num+solve(i+1,j)/solve(j+1,8)==n&&!(solve(i+1,j)%solve(j+1,8)));
        }
    }while(next_permutation(shu,shu+9));
    printf("%d",ans);
    return 0;
}