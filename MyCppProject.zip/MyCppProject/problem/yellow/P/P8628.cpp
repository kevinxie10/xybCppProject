#include <iostream>
#include <queue>
using namespace std;
struct node{
	int x,y,step;
};
int n,fx,fy,dx[]={1,0,0,-1},dy[]={0,1,-1,0};
char mp[110][110];
bool vis[110][110];
queue<node>q;
void bfs(){
	q.push({fx,fy,0});
	vis[fx][fy]=true;
	while(!q.empty()){
		node k=q.front();
		q.pop();
		for(int i=0;i<4;i++){
			int xx=k.x+dx[i],yy=k.y+dy[i];
			if(xx>=1&&xx<=n&&yy>=1&&yy<=n&&mp[k.x][k.y]!=mp[xx][yy]&&!vis[xx][yy]){
				if(mp[xx][yy]=='B'){printf("%d",k.step+1);return;}
				vis[xx][yy]=true;
				q.push({xx,yy,k.step+1});
			}
		}
	}
    printf("-1");
}
int main(){
    scanf("%d",&n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
			cin>>mp[i][j];
			if(mp[i][j]=='A')fx=i,fy=j;
		}
	bfs();
	return 0;
}