#include <iostream>
#include <algorithm>
#define MOD 1000000009
using namespace std;
int n,k,sign=1,l,r;
long long a[100010],ans=1;
int main(){
    scanf("%d%d",&n,&k);
    for(int i=0;i<n;i++)scanf("%lld",a+i);
    sort(a,a+n),l=0,r=n-1;
    if(k&1){
        ans=a[r--],k--;
        if(ans<0)sign=-1;
    }
    while(k){
        if(sign*a[l]*a[l+1]>sign*a[r]*a[r-1])ans=a[l]*a[l+1]%MOD*ans%MOD,l+=2;
        else ans=a[r]*a[r-1]%MOD*ans%MOD,r-=2;
        k-=2;
    }
    printf("%lld",ans);
    return 0;
}