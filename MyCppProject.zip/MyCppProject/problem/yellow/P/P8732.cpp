#include <cstdio>
#include <algorithm>
int n;
long long sum[1010],ans;
struct STUDENT{
	int s,a,e;
	bool operator<(const STUDENT &t)const{
		return s+a+e<t.s+t.a+t.e;
	}
}st[1010];
int main(){
	scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d%d%d",&st[i].s,&st[i].a,&st[i].e);
	std::sort(st,st+n);
	sum[0]=st[0].s+st[0].a;
	for(int i=1;i<n-1;i++)sum[i]=sum[i-1]+st[i-1].e+st[i].s+st[i].a;
	sum[n-1]=sum[n-2]+st[n-2].e+st[n-1].s+st[n-1].a;
	for(int i=0;i<n;i++)ans+=sum[i];
	printf("%lld",ans);
	return 0;
}