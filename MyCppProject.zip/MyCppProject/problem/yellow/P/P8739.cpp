#include <iostream>
using namespace std;
int k,n,ans;
string s;
int main(){
    cin>>k>>s;
    if(s.length()%k!=0){printf("-1");return 0;}
    n=s.length()/k;
    for(int i=0;i<n;i++){
        int t[30]={0},mx=0;
        for(int j=i;j<s.length();j+=n)t[s[j]-'a']++;
        for(int j=0;j<26;j++)mx=(t[j]>mx?t[j]:mx);
        ans+=k-mx;
    }
    printf("%d",ans);
    return 0;
}