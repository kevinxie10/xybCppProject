#include <cstring>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;
struct node{
    int x,y,cnt;
};
int n,m,k,x,y,ans=1141919810,step1=-1,step2=-1,h[3010][3010],dx[]={0,0,1,-1},dy[]={1,-1,0,0};
bool mp[3010][3010],vis[3010][3010];
queue<node>q;
vector<int>front,back;
bool check(int x,int y){return (x>=1&&x<=n&&y>=1&&y<=m&&!vis[x][y]&&h[x][y]);}
void bfs1(){
    q.push({1,1}),vis[1][1]=true;
    while(!q.empty()){
        node k=q.front();
        q.pop();
        if(mp[k.x][k.y]){
            if(step1==-1)front.push_back(h[k.x][k.y]),step1=k.cnt;
            else if(step1==k.cnt)front.push_back(h[k.x][k.y]);
        }
        if(k.x==n&&k.y==m){ans=k.cnt;return ;}
        for(int i=0;i<4;i++){
            int xx=k.x+dx[i],yy=k.y+dy[i];
            if(check(xx,yy)){
                vis[xx][yy]=true;
                q.push({xx,yy,k.cnt+1});
            }
        }
    }
}
void bfs2(){
    while(!q.empty())q.pop();
    memset(vis,0,sizeof vis);
    q.push({n,m}),vis[n][m]=true;
    while(!q.empty()){
        node k=q.front();
        q.pop();
        if(mp[k.x][k.y]){
            if(step2==-1)back.push_back(h[k.x][k.y]),step2=k.cnt;
            else if(step2==k.cnt)back.push_back(h[k.x][k.y]);
        }
        for(int i=0;i<4;i++){
            int xx=k.x+dx[i],yy=k.y+dy[i];
            if(check(xx,yy))vis[xx][yy]=true,q.push({xx,yy,k.cnt+1});
        }
    }
}
int main(){
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)scanf("%d",&h[i][j]);
    for(int i=1;i<=k;i++){
        scanf("%d%d",&x,&y);
        mp[x][y]=1;
    }
    bfs1();
    bfs2();
    for(auto i:front)
        for(auto j:back)
            if(i==j)ans=min(ans,step1+step2+1);
            else ans=min(ans,step1+step2+2);
    if(ans!=1141919810)printf("%d",ans);
    else printf("-1");
    return 0;
}