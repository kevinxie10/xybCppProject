#include <cstdio>
#include <cmath>
int t,m,a,b,c,delta,k,gcd;int GCD(int m,int n){return n?GCD(n,m%n):m;}
int main(){
    scanf("%d%d",&t,&m);
    while(t--){
        scanf("%d%d%d",&a,&b,&c);
        if(a<0)a=-a,b=-b,c=-c;
        delta=b*b-4*a*c,k=1;
        if(delta<0){printf("NO\n");continue;}
        for(int i=2;i*i<=delta;i++)
            while(!(delta%(i*i)))k*=i,delta/=i*i;
        if(delta==0||delta==1){
            gcd=abs(GCD(2*a,-b+k*delta));
            printf("%d",(-b+k*delta)/gcd);
            if(2*a/gcd!=1)printf("/%d",2*a/gcd);
            printf("\n");
            continue;
        }
        gcd=abs(GCD(-b,2*a));
        if(-b/gcd){
            printf("%d",-b/gcd);
            if(2*a/gcd!=1)printf("/%d",2*a/gcd);
            printf("+");
        }
        gcd=abs(GCD(k,2*a));
        if(k/gcd!=1)printf("%d*",k/gcd);
        printf("sqrt(%d)",delta);
        if(2*a/gcd!=1)printf("/%d",2*a/gcd);
        printf("\n");
    }
    return 0;
}