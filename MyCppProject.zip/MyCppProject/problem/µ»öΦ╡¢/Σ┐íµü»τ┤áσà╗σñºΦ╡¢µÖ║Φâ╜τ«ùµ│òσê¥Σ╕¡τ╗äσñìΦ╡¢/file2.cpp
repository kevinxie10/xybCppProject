#include<iostream>
#include<string>
using namespace std;
string s1,s2,s1_z,s1_s,s2_z,s2_s;
int comstr(string s1, string s2){
    if(s1.length()>s2.length())return 1;
    else if(s1.length()==s2.length())return s1.compare(s2);
    else return -1;
}
int main(){
    cin>>s1>>s2;
    int n;
    bool isErr=false;
    if((n=s1.find('.'))!=string::npos){
        if(n==0||n==s1.size()-1)isErr=true;
        else s1_z=s1.substr(0,n),s1_s=s1.substr(n+1);
    }
    else s1_z=s1,s1_s="";
    if((n=s2.find('.'))!=string::npos){
        if(n==0||n==s1.size()-1)isErr=true;
        else s2_z=s2.substr(0,n),s2_s=s2.substr(n+1);
    }
    else s2_z=s2,s2_s="";
    if(isErr){
        printf("error");
        return 0;
    }
    if(comstr(s1_z,s2_z)>0)cout<<s1;
    else if(comstr(s1_z,s2_z)==0){
        if(comstr(s1_s,s2_s)>0)cout<<s1;
        else if(comstr(s1_s,s2_s)==0)printf("equation");
        else cout<<s2;
    }
    else cout<<s2;
    return 0;
}
