#include<iostream>
using namespace std;
string s;
int k;
int main(){
    cin>>s>>k;
    for(int i=0;i<s.length()-1;){
        if(s[i]>s[i+1]&&k){
            s.erase(s.begin()+i);
            if(i>0)i--;
            k--;
        }
        else i++;
    }
    while(k--)s.pop_back();
    while(s[0]=='0'&&s.length()>1)s.erase(s.begin());
    cout<<s;
    return 0;
}