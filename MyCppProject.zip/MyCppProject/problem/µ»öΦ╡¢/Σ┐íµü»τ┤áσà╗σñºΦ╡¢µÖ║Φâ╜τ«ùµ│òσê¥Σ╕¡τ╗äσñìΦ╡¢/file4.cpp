#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
long long n,m,x,y,z,sx,sy,ans,a[N];
bool vis[N];
bool flag=0;
vector<long long>g[N];
void dfs(long long x,long long res){
    if(x>n||x<0)return ;
    if(x==sx&&vis[sx]&&flag){
        ans=max(ans,res);
        return ;
    }
    if(vis[x])return ;
    vis[x]=1;
    if(x==sy)flag=1;
    for(long long i:g[x])dfs(i,res+a[i]);
    flag=0;
    return ;
}
int main(){
    cin>>n>>m;
    for(int i=1;i<=m;++i){
        scanf("%lld%lld%lld",&x,&y,&z);
        g[x].push_back(y);
        a[i]=z;
    }
    cin>>sx>>sy;
    dfs(sx,0);
    cout<<ans;
	return 0;
}
/*
3 5
1 2 4
2 1 6
1 3 11
3 1 3
2 3 2
1 2
*/