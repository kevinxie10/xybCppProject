#include <cstdio>
#include <cmath>
int n,a[10],b[10],t,sum;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d%d",a+i,b+i),sum+=100/a[i]*b[i];
    scanf("%d",&t);
    if(sum>=t){printf("Already Au.");return 0;}
    for(int i=0;i<n;i++)
        if(a[i]==b[i])printf("NaN\n");
        else printf("%d\n",(int)ceil((t-sum)/(100.0/a[i])));
}