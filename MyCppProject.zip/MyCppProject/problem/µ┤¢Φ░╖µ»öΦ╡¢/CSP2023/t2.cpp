#include <cstdio>
#include <algorithm>
int n,a[2000010];
bool flag=true;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i),flag=(!a[i]&&flag?true:false);
    if(flag){
        for(int i=1;i<=(n>>1);i++)printf("1 ");
        for(int i=(n>>1)+1;i<=n;i++)printf("0 ");
        return 0;
    }
    for(int i=1;i<=n;i++)
        for(int l=1,r=i;l<=r;l++,r--)std::swap(a[l],a[r]),a[l]=!a[l],a[r]=!a[r];
    for(int i=1;i<=n;i++)printf("%d ",a[i]);
}