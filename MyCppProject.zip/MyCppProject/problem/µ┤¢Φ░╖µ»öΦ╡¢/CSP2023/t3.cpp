#include <cstdio>
#include <cstring>
#include <algorithm>
struct USER{
    int r,c,a;
    bool operator<(const USER &a)const{
        return c>a.c;
    }
}user[200010];
int t,n,tong[200010];
long long sum;
bool cmp(const USER &a,const USER &b){return a.c>b.c;}
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=1;i<=n;i++)scanf("%d",&user[i].r);
        for(int i=1;i<=n;i++)scanf("%d",&user[i].c),sum+=user[i].c;
        for(int i=1;i<=n;i++)user[i].a=i;
        std::stable_sort(user+1,user+1+n,cmp);
        printf("%lld",sum-user[n].c);
        /*
        for(int i=1,j;i<=n;i++){
            j=user[i].a;
            if(user[i].a==1){tong[1]=1;continue;}
            while(--j)
                if(tong[j]==0){tong[j]=user[i].a;sum+=user[i].c;break;}
            if(j==0){
                j=user[i].a;
                if(tong[j]==0){tong[j]=j;}
                else
                    while(j++<n)
                        if(tong[j]==0){tong[j]=user[i].a;sum-=user[i].c;break;}
            }
        }
        printf("%lld\n",sum),sum=0;
        memset(tong,0,sizeof tong);
        */
    }
    return 0;
}