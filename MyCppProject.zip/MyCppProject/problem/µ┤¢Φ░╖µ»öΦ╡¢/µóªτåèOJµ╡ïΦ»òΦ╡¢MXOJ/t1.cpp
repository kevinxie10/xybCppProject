#include <algorithm>
#include <iostream>
#include <utility>
using namespace std;
const int N=100010;
int T,n,k;
pair<int,int> a[N];
int main(){
    scanf("%d",&T);
    while(T--){
        scanf("%d%d",&n,&k);
        for(int i=1;i<=n;i++)scanf("%d%d",&a[i].first,&a[i].second);
        sort(a+1,a+1+n);
        bool flag=false;
        for(int i=1;i<=n;i++){
            if(a[i].second==k){
                auto p=lower_bound(a+1,a+1+n,make_pair(k,0));
                if((*p).first==k){flag=true;break;}
            }
        }
        puts(flag?"YES":"NO");
    }
    return 0;
}