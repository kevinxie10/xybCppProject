#include <iostream>
#include <algorithm>
using namespace std;
struct node{
    long long x;
    int i,j;
    bool operator<(const node &t){
        return x<t.x;
    }
}a[1001010];
long long h,w,c,t,n,ans=9223372036854775807;
int main(){
    scanf("%lld%lld%lld",&h,&w,&c),n=h*w;
    for(int i=1;i<=n;i++)
        scanf("%lld",&a[i].x),a[i].i=(i-1)/w,a[i].j=(i-1)%w;
    sort(a+1,a+1+h*w);
    n=min(3000LL,h*w);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){
            if(i==j)continue;
            ans=min(ans,a[i].x+a[j].x+c*(abs(a[i].i-a[j].i)+abs(a[i].j-a[j].j)));
        }
    printf("%lld",ans);
    return 0;
}