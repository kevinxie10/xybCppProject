#include <cstdio>
long long a,b,c,d;
int main(){
    scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
    printf("%s\n",(a+b+c+d<=1315?"Yes":"No"));
    printf("%s\n",(a<=1422?"Yes":"No"));
    printf("%s\n",(d>=1529?"Yes":"No"));
    printf("%s\n",(a*b*c*d>=1339?"Yes":"No"));
    return 0;
}