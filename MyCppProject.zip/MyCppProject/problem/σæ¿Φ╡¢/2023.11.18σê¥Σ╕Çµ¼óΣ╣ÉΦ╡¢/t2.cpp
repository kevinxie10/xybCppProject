#include <cstdio>
long long n;
int main(){
    scanf("%lld",&n);
    printf("%lld %lld %lld",n,n<<1,n<<2);
    return 0;
}