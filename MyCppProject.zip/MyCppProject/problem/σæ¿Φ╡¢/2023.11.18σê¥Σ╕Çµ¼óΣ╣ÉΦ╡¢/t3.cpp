#include <cstdio>
long long a;
int main(){
    scanf("%lld",&a);
	printf("%lld",(a<100)?(100-a):(100-a%100));
	return 0;
}