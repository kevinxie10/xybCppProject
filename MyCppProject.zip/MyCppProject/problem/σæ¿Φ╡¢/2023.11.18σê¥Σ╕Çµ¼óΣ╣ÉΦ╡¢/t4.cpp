#include <iostream>
using namespace std;
int a;
int main(){
    scanf("%d",&a);
	a=(a%12?a%12:12);
	a=(a-3>0?a-3:a+9);
	switch(a){
		case 1:printf("rat");break;
		case 2:printf("ox");break;
		case 3:printf("tiger");break;
		case 4:printf("rabbit");break;
		case 5:printf("dragon");break;
		case 6:printf("snake");break;
		case 7:printf("horse");break;
		case 8:printf("sheep");break;
		case 9:printf("monkey");break;
		case 10:printf("rooster");break;
		case 11:printf("dog");break;
		case 12:printf("pig");break;
	}
	return 0;
}