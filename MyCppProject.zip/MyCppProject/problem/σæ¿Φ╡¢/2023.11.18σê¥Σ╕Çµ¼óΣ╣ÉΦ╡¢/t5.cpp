#include <cstdio>
int a,b,c,d,m,score;
int main(){
    scanf("%d%d%d%d%d",&a,&b,&c,&d,&m);
    if(c*10<=m)score=(c<<1)+(c<<3)-(b-d)*30;
    else score=c*10+d*50-(b-d)*30;
    if(score<0)score=0;
    printf("%d",score);
    return 0;
}