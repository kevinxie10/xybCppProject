#include <cstdio>
const int power[]={0,1,2,6,24,120,720,5040,40320,362880,3628800,39916800};
long long n;
int main(){
    scanf("%lld",&n);
    if(n<=11)printf("%d",power[n]);
    else printf("-1");
    return 0;
}