#include <cstdio>
long long m,n,ans;
int main(){
    scanf("%lld%lld",&m,&n),ans=n;
	if(m==1){printf("%lld",n);return 0;}
	for(int i=2;i<=m;i++)ans*=(n-1);
    printf("%lld",ans);
    return 0;
} 