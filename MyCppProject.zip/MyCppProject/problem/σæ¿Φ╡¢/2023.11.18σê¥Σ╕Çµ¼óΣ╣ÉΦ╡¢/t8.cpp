#include <cstdio>
int l,h,a,mx=-2147483648,tmx;
int main(){
    scanf("%d%d",&l,&h);
    for(int i=0;i<l;i++){
        scanf("%d",&a);
        if(a<h)tmx++;
        else mx=(tmx>mx?tmx:mx),tmx=0;
    }
    printf("%d",(tmx>mx?tmx:mx));
    return 0;
}