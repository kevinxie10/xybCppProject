#include <cstdio>
#define TAKE 5
long long n,ans1,ans2;
int main(){
    scanf("%lld",&n);
    for(int i=1;;i++){
        if(!n)break;
        (!ans2&&n%TAKE==1?ans2=i:0);
        n-=(!(n%TAKE)?n/TAKE:n/TAKE+1);
        ans1++;
    }
    printf("%lld %lld",ans1,ans2);
    return 0;
}