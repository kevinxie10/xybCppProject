#include <cstdio>
int main(){
    printf("China");
    return 0;
}