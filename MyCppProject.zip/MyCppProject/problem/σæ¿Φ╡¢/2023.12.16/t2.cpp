#include <cstdio>
int t,cnt;
int main(){
    for(int i=0;i<8;i++)scanf("%d",&t),cnt+=(t<1000);
    printf("%d",cnt);
    return 0;
}