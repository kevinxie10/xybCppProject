#include <cmath>
#include <cstdio>
using std::abs;
int n,a[110],mx=-2147483648;
int main(){
    scanf("%d%d",&n,a);
    for(int i=1;i<n;i++)scanf("%d",a+i),mx=(abs(a[i]-a[i-1])>mx?abs(a[i]-a[i-1]):mx);
    printf("%d",mx);
    return 0;
}