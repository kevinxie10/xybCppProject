#include <iostream>
int n,x,y,z,mn=2147483647;
int main(){
    scanf("%d%d%d%d",&n,&x,&y,&z);
    for(int i=0;i<20;i++)
        for(int j=0;j<15;j++)
            for(int k=0;k<10;k++)
                if(6*i+8*j+12*k>=n)mn=std::min(i*x+j*y+k*z,mn);
    printf("%d",mn);
    return 0;
}