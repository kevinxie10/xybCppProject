#include <algorithm>
#include <cmath>
#include <iostream>
long long n,a,v,mn=2147483647;
int main(){
    scanf("%lld",&n);
    for(int i=0;i<3;i++)scanf("%lld%lld",&a,&v),mn=std::min(ceil(n*1.0/a)*v,(double)mn);
    printf("%lld",mn);
    return 0;
}