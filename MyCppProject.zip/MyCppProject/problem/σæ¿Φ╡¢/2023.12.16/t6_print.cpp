#include <cstdio>
int cnt=1,n;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        printf("\"");
        for(int j=1;j<=i;j++)
            printf("%d ",cnt++);
        printf("\",\n");
    }
    return 0;
}