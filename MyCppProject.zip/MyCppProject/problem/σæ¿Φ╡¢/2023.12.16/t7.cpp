#include <iostream>
int n,q,cnt;
long long a[1000010],l,r;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%lld",a+i);
    scanf("%d",&q);
    while(q--){
        scanf("%lld%lld",&l,&r);
        if(l>r)std::swap(l,r);
        for(int i=0;i<n;i++)
            if(a[i]>=l&&a[i]<=r)cnt++;
        printf("%d\n",cnt);
        cnt=0;
    }
}