#include <cstdio>
int n,m,l,r,a[1000010];
long long sum[1000010];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i),sum[i]=sum[i-1]+a[i];
    scanf("%d",&m);
    while(m--){
        scanf("%d%d",&l,&r);
        printf("%lld\n",sum[r]-sum[l-1]);
    }
    return 0;
}