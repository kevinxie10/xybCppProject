#include <cstdio>
int n,m,t,l,r;
long long c[1000010];
int lowbit(int x){return x&(-x);}
void add(int x, int k){for(int i=x;i<=n;i+=lowbit(i))c[i]+=k;}
long long find(int x){
    long long sum=0;
    for(int i=x;i>0;i-=lowbit(i))sum+=c[i];
    return sum;
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",&t);
        add(i,t);
    }
    scanf("%d",&m);
    while(m--){
        scanf("%d%d",&l,&r);
        printf("%lld",find(r)-find(l-1));
    }
    return 0;
}