#include <bits/stdc++.h>
using namespace std;
int n,a[100010],q,op,l,r,k;

class STREE{
    #define LC (p<<1)
    #define RC (p<<1|1)
private:
    struct NODE{
        int l,r;
        long long sum,tag;
    }*tr;
    
    inline void build(NODE tr[],int arr[],int p,int l,int r){
        tr[p]={l,r,arr[l],0};
        if(l==r)return ;
        int mid=(l+r)>>1;
        build(tr,arr,LC,l,mid),build(tr,arr,RC,mid+1,r);
        tr[p].sum=tr[LC].sum+tr[RC].sum;
        return ;
    }

    inline void pushdown(int p){
        tr[LC].sum+=tr[p].tag*(tr[LC].r-tr[LC].l+1);
        tr[RC].sum+=tr[p].tag*(tr[RC].r-tr[RC].l+1);
        tr[LC].tag+=tr[p].tag,tr[RC].tag+=tr[p].tag;
        tr[p].tag=0;
        return ;
    }

    inline void add(int p,int l,int r,int k){
        if(l<=tr[p].l&&tr[p].r<=r){
            tr[p].sum+=(tr[p].r-tr[p].l+1)*k;
            tr[p].tag+=k;
            return ;
        }
        int mid=(tr[p].l+tr[p].r)>>1;
        pushdown(p);
        if(l<=mid)add(LC,l,r,k);
        if(mid+1<=r)add(RC,l,r,k);
        tr[p].sum=tr[LC].sum+tr[RC].sum;
        return ;
    }

    inline long long query(int p,int l,int r){
	    if(l<=tr[p].l&&tr[p].r<=r)return tr[p].sum;
	    pushdown(p);
	    int mid=(tr[p].l+tr[p].r)>>1;
	    long long ans=0;
	    if(l<=mid)ans+=query(LC,l,r);
	    if(r>=mid+1)ans+=query(RC,l,r); 
	    return ans;
    }

public:

    STREE(int arr[],int p,int l,int r){
        tr=new struct NODE [r<<2];
        build(tr,arr,p,l,r);
    }

    inline void add(int l,int r,int k){
        add(1,l,r,k);
        return ;
    }

    inline long long query(int l,int r){
        return query(1,l,r);
    }

};

int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    STREE tree(a,1,1,n);
    scanf("%d",&q);
    while(q--){
        scanf("%d%d",&l,&r),printf("%lld\n",tree.query(l,r));
    }
    return 0;
}