#include <cstdio>
int n;
double ans=130;
int main(){
    scanf("%d",&n);
    for(int i=1;i<n;i++)ans*=1.2;
    printf("%dEFLOPS",(int)ans);
}