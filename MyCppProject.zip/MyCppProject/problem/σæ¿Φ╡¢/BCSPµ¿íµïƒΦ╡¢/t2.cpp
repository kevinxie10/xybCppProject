#include <cstdio>
#include <cmath>
float n;
int main(){
    scanf("%f",&n);
    printf("%d",(int)log2(n)+1);
    return 0;
}