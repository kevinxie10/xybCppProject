#include <iostream>
using namespace std;
const int N=10;
long long a[N+10],b[N+10],m,n,t,ans;

int main(){
    for(int i=1;i<=N;i++){
        scanf("%lld%lld",a+i,b+i),ans=0;
        m=max(a[i],b[i]),n=min(a[i],b[i]);
        while(m!=0){
            t=m;
            ans+=n/m*m;
            m=n%m;
            n=t;
        }
        printf("%lld\n",ans);
    }
    return 0;
}