#include <cstdio>
int main(){
    printf("Dragon");
    return 0;
}