#include <cstdio>
long long n,a,b;
int main(){
    scanf("%lld",&n);
    for(int i=1;i<=n;i++){
        scanf("%lld%lld",&a,&b);
        printf("%s\n",(a==b?"YES":"NO"));
    }
    return 0;
}