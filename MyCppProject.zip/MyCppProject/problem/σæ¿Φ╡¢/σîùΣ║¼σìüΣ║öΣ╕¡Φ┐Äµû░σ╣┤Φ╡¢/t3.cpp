#include <cstdio>
int a,b;
int main(){
    scanf("%d%d",&a,&b);
    printf("%s",((int)(a*3*0.35)==(int)(b*2*0.5)?"ALL":((int)(a*3*0.35)>(int)(b*2*0.5)?"R":"S")));
    return 0;
}