#include <iostream>
#include <string>
using namespace std;
long long n;
string s;
bool flag[100010];
int main(){
    scanf("%lld",&n);
    if(n==1){printf("1\n");return 0;}
    for(long long i=2;i*i<=n;i++){
        if(n/(double)i==n/i){
            if(n/i%i==0){
                s+="("+to_string(i),n/=i;
                while(n%i==0)s+=' '+to_string(i),n/=i;
                s+=')';
            }
            else if(n%i==0)while(n%i==0)s+=to_string(i)+' ',n/=i;
        }
    }
    if(n>1)s+=to_string(n);
    for(int i=0;i<s.length();i++)
        if(s[i]=='('&&s[i-1]==' ')flag[i-1]=true;
    for(int i=0;i<s.length();i++)
        if(!flag[i])printf("%c",s[i]);
    return 0;
}