#include <iostream>
#include <cstdio>
using namespace std;

int main(){
    //freopen("coprime.in","r",stdin);
    //freopen("coprime.out","w",stdout);
    
    return 0;
}
