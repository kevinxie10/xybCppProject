#include<cstdio>
#include<unordered_map>
#include<cstring>
#include<algorithm>

using hash_t=unsigned int;
using ll=long long;

const hash_t p=0x7fffffffu;
const int maxn=125;

// 字符串hash，但是O(n)
hash_t toHash(char *s){
	hash_t hash_=0u;
	for(int i=0;s[i];i++){
		hash_=(hash_*131u+s[i])%p;
	}
	return hash_;
}

std::unordered_map<hash_t,int> typeName; // 类型名hash -> 类型编号
std::unordered_map<hash_t,int> elemName; // 元素名hash -> 元素编号

int qcnt; // 询问次数
int tcnt; // 类型个数
int ecnt; // 元素个数

struct Type{
	int n; // 子元素个数
	int type[maxn]; // 子元素 类型编号
	std::unordered_map<hash_t,int> name; // 子元素名hash -> 子元素编号 用于操作3
	char names[maxn][12]; // 子元素名 用于操作4
	ll Size; // 类型大小
	ll Req; // 类型对齐要求
	ll Pos[maxn]; // 注意是相对位置
}type[maxn];

void init(){
	type[1].n=type[2].n=type[3].n=type[4].n=0;

	typeName.emplace(toHash((char*)"byte"), 1); // 等同于 typeName[toHash("byte")]=1
	typeName.emplace(toHash((char*)"short"),2);
	typeName.emplace(toHash((char*)"int"),  3);
	typeName.emplace(toHash((char*)"long"), 4);

	type[1].Size=type[1].Req=1ll;
	type[2].Size=type[2].Req=2ll;
	type[3].Size=type[3].Req=4ll;
	type[4].Size=type[4].Req=8ll;

	tcnt=4;
}

char s[12345],t1[12],t2[12];
int k,op;
ll Address; // 绝对头指针 用于操作2

void defType(){
	tcnt++;
	scanf("%s%d",s,&k);
	type[tcnt].n=k;
	typeName.emplace(toHash(s),tcnt);
	ll pos=0,mmod;
	for(int i=1;i<=k;i++){
		scanf("%s%s",t1,t2);
		// 对名字的操作
		int ind1=typeName.find(toHash(t1))->second; // 等同于 typename[toHash(t1)]
		type[tcnt].type[i]=ind1;
		strcpy(type[tcnt].names[i],t2);
		type[tcnt].name.emplace(toHash(t2),i);
		// 对齐
		mmod=pos%type[ind1].Req;
		if(mmod)pos=pos-mmod+type[ind1].Req;
		// 对位置的操作
		type[tcnt].Pos[i]=pos;
		pos+=type[ind1].Size;
		type[tcnt].Req=std::max(type[tcnt].Req,type[ind1].Req);
	}
	// 此处仍需对齐，注意！！！结构体大小要对齐！！！
	mmod=pos%type[tcnt].Req;
	if(mmod)pos=pos-mmod+type[tcnt].Req;
	type[tcnt].Size=pos;
	printf("%lld %lld\n",type[tcnt].Size,type[tcnt].Req);
}

struct Element{
	int type; // 类型编号
	ll Addr; // 绝对位置~
	char name[12];
}elem[maxn]; 

void defElement(){
	scanf("%s%s",t1,t2);
	ecnt++;
	// 对变量名的操作
	strcpy(elem[ecnt].name,t2);
	elemName.emplace(toHash(t2),ecnt);
	elem[ecnt].type=typeName.find(toHash(t1))->second;
	// 对齐
	ll mmod=Address%type[elem[ecnt].type].Req;
	if(mmod)Address=Address-mmod+type[elem[ecnt].type].Req;
	// 对位置的操作
	printf("%lld\n",Address);
	elem[ecnt].Addr=Address;
	Address+=type[elem[ecnt].type].Size;
}

// 下一个元素
hash_t getNext(int st,int &tong){
	hash_t hash_=0;
	for(int i=st;s[i]!='.' and s[i];i++,tong++){
		hash_=(hash_*131u+s[i])%p;
	}
	return hash_;
}

void findElement(){
	scanf("%s",s);
	int tong=0,st=0;
	int len=strlen(s);
	int eleid=elemName.find(getNext(st,tong))->second;
	int typid=elem[eleid].type;
	ll Addr=elem[eleid].Addr;
	st+=tong+1;
	while(st<len){ // 不能写 s[st]!!! 因为越界，undefined！！！
		tong=0;
		eleid=type[typid].name.find(getNext(st,tong))->second;
		st+=tong+1;
		// 上面讲了
		Addr+=type[typid].Pos[eleid];
		typid=type[typid].type[eleid];
	}
	printf("%lld\n",Addr);
}

void findAddress(){
	ll Addr;
	scanf("%lld",&Addr);
	int eleid,typid;
	bool flag=false;
	if(elem[ecnt].Addr+type[elem[ecnt].type].Size <= Addr)return printf("ERR\n"),void();
	memset(s,0,sizeof s);
	// 第一段——寻找该地址属于哪个变量
	for(eleid=1;eleid<=ecnt;eleid++){
		if(elem[eleid].Addr <= Addr and Addr < elem[eleid].Addr + type[elem[eleid].type].Size){
			// 找到了！！！
			Addr-=elem[eleid].Addr;
			// 注意 Addr 也是相对地址哦！
			strcat(s,elem[eleid].name);
			strcat(s,".");
			typid=elem[eleid].type;
			flag=true;
			break;
		}else if(elem[eleid].Addr > Addr)return printf("ERR\n"),void();// 空隙
	}
	if(flag == false)return printf("ERR\n"),void();
	// 第二段
	while(true){
		flag=false;
		if(type[typid].n==0)break;
		for(eleid=1;eleid<=type[typid].n;eleid++){
			if(type[typid].Pos[eleid] <= Addr and Addr < type[typid].Pos[eleid] + type[type[typid].type[eleid]].Size){
				// 找到了！！！
				Addr-=type[typid].Pos[eleid];
				strcat(s,type[typid].names[eleid]);
				strcat(s,".");
				typid=type[typid].type[eleid];
				flag=true;
				break;
			}else if(type[typid].Pos[eleid] > Addr)return printf("ERR\n"),void(); // 空隙
		}
		if(flag == false)return printf("ERR\n"),void();
	}
	int LLen=strlen(s);
	s[LLen-1]='\0'; // 注意这个，重要
	printf("%s\n",s);
}

int main(){
	//freopen("structin.txt","r",stdin);
	//freopen("struct.out","w",stdout);
	init();
	scanf("%d",&qcnt);
	while(qcnt--){
		scanf("%d",&op);
		if(op==1)defType();
		else if(op==2)defElement();
		else if(op==3)findElement();
		else findAddress();
	}
	return 0;
}
