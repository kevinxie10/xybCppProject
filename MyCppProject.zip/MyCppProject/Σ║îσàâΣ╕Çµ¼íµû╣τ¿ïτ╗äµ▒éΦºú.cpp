#include <iostream>
#include <string>
using namespace std;
int T;
class equation{
private:
    string s;
    inline void sub(char c){
        s=s.substr(s.find(c)+1);
        return ;
    }
public:
    int a,b,c;
    void read(){
        int t=0;
        char f=1;
        cin>>s;
        for(auto i:s){
            if(i=='-')f=-1;
            if(i>='0'&&i<='9')t=(t<<3)+(t<<1)+(i^'0');
            if(i=='x')a=(t?t:1)*f,t=0,f=1;
            if(i=='y')b=(t?t:1)*f,t=0,f=1;
        }
        c=t*f;
        if(!a)a=1;
        if(!b)b=1;
    }
}e1,e2;
class fraction{
private:
    int Gcd(int a,int b){
	    if(a==b)return a;
	    if(a<b)return Gcd(b,a);
	    if(!(a&1))return !(b&1)?Gcd(a>>1,b>>1)<<1:Gcd(a/2,b);
	    return !(b&1)?Gcd(a,b/2):Gcd(b,a-b);
    }
public:
    int a,b;
    fraction(int m=0,int n=1):a(m),b(n){
        if(!n)throw std::invalid_argument("b cannot be zero.");
        simplify();
    }
    void simplify(){
        int k=Gcd(std::abs(a),std::abs(b));
        a/=k,b/=k;
        if(b<0)a=-a,b=-b;
    }
    void print(){
        if(b==1)printf("%lld\n",a);
        else printf("%lld/%lld\n",a,b);
        return ;
    }
};
int main(){
    puts("请输入一个正整数，代表所要输入的方程组组数");
    scanf("%lld",&T);
    puts("接下来，请你按ax+by=c（a,b,c为常数）的格式每行输入一个二元一次方程，每两行构成一个方程组");
    while(T--){
        e1.read();
        e2.read();
        fraction x={e2.b*e1.c-e1.b*e2.c,e2.b*e1.a-e1.b*e2.a},
                 y={e2.a*e1.c-e1.a*e2.c,e2.a*e1.b-e1.a*e2.b};
        printf("x = ");
        x.print();
        printf("y = ");
        y.print();
        puts("");
    }
    return 0;
}
/*
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
int T;
int a1,b1,c1,a2,b2,c2;
void read(int &a,int &b,int &c){
    char f=1;
    string s;
    cin>>s;
    int t=0;
    for(auto i:s){
        if(i=='-')f=-1;
        if(i=='x'){
            if(!t)t=1;
            a=t*f,f=1,t=0;
        }
        if(i=='y'){
            if(!t)t=1;
            b=t*f,f=1,t=0;
        }
        if(i>='0'&&i<='9')t=(t<<3)+(t<<1)+(i^48);
    }
    c=t*f;
    return;
}
int main(){
    scanf("%d",&T);
    while(T--){
        a1=b1=c1=a2=b2=c2=0;
        read(a1,b1,c1);
        read(a2,b2,c2);

        int x1=b2*c1-b1*c2,y1=b2*a1-b1*a2,x2=a2*c1-a1*c2,y2=a2*b1-a1*b2;
        int k1=__gcd(abs(x1),abs(y1)),k2=__gcd(abs(x2),abs(y2));
        x1/=k1,y1/=k1,x2/=k2,y2/=k2;
        if(y1<0)x1=-x1,y1=-y1;
        if(y2<0)x2=-x2,y2=-y2;

        printf("x = ");
        if(y1==1)printf("%d\n",x1);
        else printf("%d/%d\n",x1,y1);
        printf("y = ");
        if(y2==1)printf("%d\n",x2);
        else printf("%d/%d\n",x2,y2);
    }
    return 0;
}
*/