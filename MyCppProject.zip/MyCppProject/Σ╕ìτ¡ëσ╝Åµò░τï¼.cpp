#include <iostream>
#include <cstring>
#include <utility>
#include <vector>
#define N 5
#define fi first
#define se second
using namespace std;
struct NODE{
    int x,y;
    bool operator==(const NODE a){return x==a.x&&y==a.y;}
};
vector<pair<NODE,NODE>>v;//first为较小数，second为较大数
int n,arr[N][N];
bool check(int a[][N],int i,int j,int k){//在a[i][j]处是否可以填k
    for(int x=0;x<N;x++){//在同一行或同一列有相同的数
        if(a[x][j]==k)return false;
        if(a[i][x]==k)return false;
    }
    for(auto it:v){//不满足不等式要求
        if(it.fi==NODE{i,j}&&a[it.se.x][it.se.y]<=a[i][j])return false;
        if(it.se==NODE{i,j}&&a[it.fi.x][it.fi.y]>=a[i][j])return false;
    }
    return true;
}
bool checkall(int a[][N]){//数独是否无误（可省？）
    int tong[N+1];
    for(int i=0;i<N;i++){//每一行无重复
        memset(tong,0,sizeof tong);
        for(int j=0;j<N;j++){
            tong[a[i][j]]++;
            if(tong[a[i][j]]>1)return false;
        }
    }
    for(int i=0;i<N;i++){//每一列无重复
        memset(tong,0,sizeof tong);
        for(int j=0;j<N;j++){
            tong[a[j][i]]++;
            if(tong[a[j][i]]>1)return false;
        }
    }
    for(auto it:v)//不等式条件满足
        if(a[it.fi.x][it.fi.y]>=a[it.se.x][it.se.y])return false;
    return true;
}
void dfs(int a[][N]){
    bool flag=false;
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)flag=(a[i][j]==0);
    if(flag==false){
        if(!checkall(a))return ;//填错了，回退
        for(int i=0;i<N;i++,printf("\n"))//成功了，输出
            for(int j=0;j<N;j++)
                printf("%d ",a[i][j]);
        printf("\n\n");
        return ;//继续枚举
    }
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++){
            for(int k=1;k<=N;k++)
                if(a[i][j]==0&&check(a,i,j,k))a[i][j]=k,dfs(a);//如果空着且可以填k，就试一试，然后深搜填下一个
            if(a[i][j]==0)return ;//什么都填不了，就回退
        }
    return ;
}
int main(){
    printf("请输入数独的数字，空缺处用0代替，每个数之间输入空格\n");
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)scanf("%d",&arr[i][j]);
    printf("\n\n请输入数独的不等式关系个数\n\n");
    scanf("%d",&n);
    printf("\n\n请输入每个\"<\"前面的数的位置（先行数后列数）和后面的数\n\n");
    int i,j,x,y;
    for(int cnt=0;cnt<n;cnt++){
        cin>>i>>j>>x>>y;
        i--,j--,x--,y--;
        v.push_back(pair<NODE,NODE>({i,j},{x,y}));//前面是较小数，后面是较大数
    }
    printf("正在计算中…\n");
    dfs(arr);
    return 0;
}
/*样例1
0 0 0 0 5
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0

7
2 3 1 3
2 2 2 3
1 2 1 3
3 3 3 4
4 2 4 1
2 5 3 5
4 4 4 5
*/