#include <iostream>
#include <queue>
#include <cstring>
using namespace std;
int n,m,cnt;
char c;
int a[1010][1010],flag[1010][1010][2],ans[1010][1010];
struct node{
    int x,y;
};
queue<node>q;
int dx[]={1,-1,0,0},dy[]={0,0,1,-1};
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){cin>>c;a[i][j]=c-'0';}
    while(m--){
        int x,y;
        scanf("%d%d",&x,&y);
        if(flag[x][y][0]){printf("%d\n",ans[flag[x][y][0]][flag[x][y][1]]);continue;}
        q.push({x,y});
        flag[x][y][0]=x;
        flag[x][y][1]=y;
        while(!q.empty()){
            cnt++;
            node k=q.front();
            q.pop();
            for(int i=0;i<4;i++){
                int xx=k.x+dx[i],yy=k.y+dy[i];
                if(xx<1||yy<1||xx>n||yy>n)continue;
                if(a[k.x][k.y]^a[xx][yy]&&!flag[xx][yy][0]){
                    flag[xx][yy][0]=x;
                    flag[xx][yy][1]=y;
                    q.push({xx,yy});
                }
            }
        }
        ans[x][y]=cnt;
        printf("%d\n",cnt);
        cnt=0;
    }
    return 0;
}