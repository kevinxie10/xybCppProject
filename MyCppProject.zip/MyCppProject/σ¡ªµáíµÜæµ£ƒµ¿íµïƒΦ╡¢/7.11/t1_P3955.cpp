#include <iostream>
#include <algorithm>
using namespace std;
int n,q,l;
string s[1010],t;
bool cmp(string a,string b){return (a.length()==b.length()?a<b:a.length()<b.length());}
void slove(string t){
	for(int j=0;j<n;j++){
		unsigned long long temp=s[j].find(t);
		if(s[j].find(t)!=string::npos&&s[j].find(t)+t.length()==s[j].length()){
		//if(temp!=18446744073709551615&&temp+t.length()==s[j].length()){
			cout<<s[j]<<endl;
			return ;
		}
	}
	printf("-1\n");
}
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	//freopen("T1.out","W",stdout);《W》 
	scanf("%d%d",&n,&q);
	for(int i=0;i<n;i++)cin>>s[i];
	sort(s,s+n,cmp);
	for(int i=0;i<q;i++){
		cin>>l>>t;
		slove(t);
	}
	return 0;
}