#include <cstdio>
#include <algorithm>
#define MAX(x,y) ((x)>(y)?(x):(y))
int n,w,a[100010];
bool cmp(int a,int b){return a>b;}
int main(){
	scanf("%d%d",&n,&w);
	for(int i=1;i<=n;i++){
		scanf("%d",a+i);
		for(int j=i;j>1;j--)
			if(a[j-1]<a[j])std::swap(a[j-1],a[j]);
		printf("%d ",a[MAX(1,(i*w/100))]);
	}
	return 0;
}