#include <iostream>
#include <algorithm>
using namespace std;
int n,a[10],tong[20];
long long k=1;
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",a+i),tong[a[i]]++;
	for(int i=0,t=1;i<20;i++,k*=t,t=1)
		for(int j=1;j<=tong[i];j++)t*=j;
	sort(a,a+n);
	do{
		for(int i=0;i<k;i++){
			for(int j=0;j<n;j++)printf("%d ",a[j]);
			printf("\n");
		}
	}while(next_permutation(a,a+n));
	return 0;
}