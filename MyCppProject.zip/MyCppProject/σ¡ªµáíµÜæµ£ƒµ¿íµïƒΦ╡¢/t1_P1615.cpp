#include <cstdio>
long long a,b,c,x,y,z,t;
int main(){
    scanf("%lld:%lld:%lld\n%lld:%lld:%lld\n%lld",&a,&b,&c,&x,&y,&z,&t);
	printf("%lld",((x-a)*3600+(y-b)*60+(z-c))*t);
    return 0;
}