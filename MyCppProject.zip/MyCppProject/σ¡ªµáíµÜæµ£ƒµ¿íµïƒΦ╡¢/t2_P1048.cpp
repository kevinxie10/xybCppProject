#include <cstdio>
int w[110],c[110],dp[1010];
int main(){
    int t,m;    
    scanf("%d%d",&t,&m);
    for(int i=1;i<=m;i++)scanf("%d%d",w+i,c+i);
    for(int i=1;i<=m;i++)
        for(int j=t;j>=0;j--)
            if(j>=w[i])dp[j]=(dp[j-w[i]]+c[i]>dp[j]?dp[j-w[i]]+c[i]:dp[j]);
    printf("%d",dp[t]);
    return 0;
}