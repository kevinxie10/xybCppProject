#include<cstdio>
float x,y,t;
int main(){
    scanf("%f%f%f",&x,&y,&t);
    printf("%f",(x*t/(y-x)*x+x*t));
    return 0;
}