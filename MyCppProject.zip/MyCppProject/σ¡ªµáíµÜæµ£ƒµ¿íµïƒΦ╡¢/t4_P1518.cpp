#include<iostream>
using std::cin;
char mp[12][12];
bool vis[160010];
int f,qmzx,qmzy,c,xybx,xyby,tm,num;
void move(int x,int y,int m,bool h){
	if(m==0){
		if(mp[x-1][y]=='*')(h?c:f)=1;
		else (h?xybx:qmzx)--;
	}
    else if(m==1){
		if(mp[x][y+1]=='*')(h?c:f)=2;
		else (h?xyby:qmzy)++;
	}
    else if(m==2){
		if(mp[x+1][y]=='*')(h?c:f)=3;
		else (h?xybx:qmzx)++;
	}
    else{
		if(mp[x][y-1]=='*')(h?c:f)=0;
		else (h?xyby:qmzy)--;
	}
    return ;
}
bool check(){return(qmzx!=xybx||qmzy!=xyby);}
int main(){
	for(int i=0;i<=11;i++)mp[i][0]='*',mp[i][11]='*';
	for(int i=1;i<=11;i++)mp[0][i]='*',mp[11][i]='*';
    for(int i=1;i<=10;i++){
    	for(int j=1;j<=10;j++){
    		cin>>mp[i][j];
    		if(mp[i][j]=='Q')qmzx=i,qmzy=j;
    		if(mp[i][j]=='X')xybx=i,xyby=j;
		}
	}
	while(check()){
		num=qmzx+qmzy*10+xybx*100+xyby*1000+f*10000+c*4*10000;
		if(vis[num]){printf("0");return 0;}
		vis[num]=1,move(qmzx,qmzy,f,0),move(xybx,xyby,c,1),tm++;
	}
	printf("%d",tm);
    return 0;
}
























































/*



#include <bits/stdc++.h>
using namespace std;
int a[12][12],i,j,k,cx,cy,fx,fy;//坐标，f是农夫的，c是牛的
char w;
int ff,fc;//农夫与牛的朝向,0表示向上,1表示向右,2表示向下,3表示向左
int cs;//统计行走次数，为了保险开到200000次好一些（滑稽）
int pd,ok;//为了防止重复走的东西
int main(){
	for(i=1;i<=10;i++)//记录障碍点，牛与人都不算障碍，因此只要记录它们的坐标就行了
		for(j=1;j<=10;j++)
		{
			cin>>w;
			if(w=='*') a[j][i]=-1;//横坐标对应的是列，纵坐标对应的是行
			if(w=='C') {cx=j;cy=i;}
			if(w=='F') {fx=j;fy=i;}
		}
	while((cx!=fx || cy!=fy) && cs<200000)//统计行走次数，注意判定边界
	{
		ff%=4;fc%=4;
		cs++;
		pd=0;//方便判定是否转向
		ok=0;//使得行走一次后会马上打住
		//农夫行走一次
		if(ff==0 && ok==0)
		{
			ok=1;
			if(a[fx][fy-1]!=-1 && fy>1)
			{pd=1;fy--;}
			if(pd==0)
			ff++;//转向
		}
		if(ff==1 && ok==0)
		{
			ok=1;
			if(a[fx+1][fy]!=-1 && fx<10)
			{pd=1;fx++;}
			if(pd==0)
			ff++;
		}
		if(ff==2 && ok==0)
		{
			ok=1;
			if(a[fx][fy+1]!=-1 && fy<10)
			{pd=1;fy++;}
			if(pd==0)
			ff++;
		}
		if(ff==3 && ok==0)
		{
			ok=1;
			if(a[fx-1][fy]!=-1 && fx>1)
			{pd=1;fx--;}
			if(pd==0)
			ff++;
		}
		//牛开始走
		pd=0;
		ok=0;
		if(fc==0 && ok==0)
		{
			ok=1;
			if(a[cx][cy-1]!=-1 && cy>1)
			{pd=1;cy--;}
			if(pd==0)
			fc++;
		}
		if(fc==1 && ok==0)
		{
			ok=1;
			if(a[cx+1][cy]!=-1 && cx<10)
			{pd=1;cx++;}
			if(pd==0)
			fc++;
		}
		if(fc==2 && ok==0)
		{
			ok=1;
			if(a[cx][cy+1]!=-1 && cy<10)
			{pd=1;cy++;}
			if(pd==0)
			fc++;
		}
		if(fc==3 && ok==0)
		{
			ok=1;
			if(a[cx-1][cy]!=-1 && cx>1)
			{pd=1;cx--;}
			if(pd==0)
			fc++;
		}

	}
	if(cs==200000) cout<<0;//对死循环的判定
	else cout<<cs;
	return 0;
}



翼德天尊  
更新时间：2020-03-09 18:17:47
在 Ta 的博客查看
老规矩，先审题！
每分钟，农夫和牛可以向前移动或是转弯。

1.如果前方无障碍（地图边沿也是障碍），它们会按照原来的方向前进一步。

2.否则它们会用这一分钟顺时针转 90 度。

终止条件：两者相遇，并且在该分钟末尾。然后计算时间。

分析
1.初始化与读入
根据题意，我们首先可以想到用一个整形变量ans储存分钟数，再用一个二维字符数组map（简称m）储存整张地图。

但是问题来了，map需要开多大呢？首先这是一个边长为10的地图，所以至少要开10* 10，但是为了更好的判断越界情况，我们可以开一个12* 12的数组，然后把边框全部变为'* '，这样相当于将边框变为了障碍物，判断更加方便。

但是我们要考虑一个问题，我们不能每次移动都遍历一遍数组，太耗时间了，所以我们可以用两个整型数组储存奶牛和农夫的信息（x,y坐标以及方向），每次移动时只需调整信息即可。既然题中说初始方向为正北，我们就可以将初始方向北设为0（初始），顺时针依次将东、南、西设为1，2，3。

char m[12][12];
int f[3],c[3],ans;
for (int i=0;i<=11;i++) m[i][0]='*',m[i][11]='*';
for (int i=1;i<=11;i++) m[0][i]='*',m[11][i]='*';
for (int i=1;i<=10;i++){
    for (int j=1;j<=10;j++){
    	cin>>m[i][j];
    	if (m[i][j]=='F') f[1]=i,f[2]=j;
    	if (m[i][j]=='C') c[1]=i,c[2]=j;
	}
}
2.移动与转弯
初始环节说完了，下面就迎来了我们的重头戏——移动与转弯。

这一环节其实难度不大，只需设置一个函数处理即可（不设也无所谓），遇到障碍物就拐弯，否则就根据方向移动。

void move(int x,int y,int mi,int h){//x,y为x,y坐标，mi为方向，h为类型：农夫为0，奶牛为1
	if (mi==0){
		if (m[x-1][y]=='*') if (h==0) f[0]=1; else c[0]=1;
		else if (h==0) f[1]--; else c[1]--;
	}else if (mi==1){
		if (m[x][y+1]=='*') if (h==0) f[0]=2; else c[0]=2;
		else if (h==0) f[2]++; else c[2]++;
	}else if (mi==2){
		if (m[x+1][y]=='*') if (h==0) f[0]=3; else c[0]=3;
		else if (h==0) f[1]++; else c[1]++;
	}else{
		if (m[x][y-1]=='*') if (h==0) f[0]=0; else c[0]=0;
		else if (h==0) f[2]--; else c[2]--;
	}
}
3.判断是否可以相遇
怎么判断呢？我们可以想到，如果两个物体先后两次从同一个方向走到同一个地点，我们就可以说它们陷入了死循环，但如何判断是否是死循环？？这是一个难倒众人的问题。

我们可以通过生成专属值的方法来判断：农夫的x坐标+他的y坐标* 10+奶牛的x坐标* 100+奶牛的y坐标* 1000+农夫的方向* 10000+奶牛的方向* 40000（农夫方向最多为4）

bool zt[160005];
tdz=f[1]+f[2]*10+c[1]*100+c[2]*1000+f[0]*10000+c[0]*40000;
if (zt[tdz]){
	cout<<0<<endl;
	return 0;
}
总代码如下：
#include<bits/stdc++.h>
using namespace std;
char m[12][12];//地图
int f[3],c[3],ans,tdz;//农夫，奶牛，秒数，专属值
bool zt[160005];//记录专属值是否出现
void move(int x,int y,int mi,int h){//移动函数
	if (mi==0){
		if (m[x-1][y]=='*') if (h==0) f[0]=1; else c[0]=1;
		else if (h==0) f[1]--; else c[1]--;
	}else if (mi==1){
		if (m[x][y+1]=='*') if (h==0) f[0]=2; else c[0]=2;
		else if (h==0) f[2]++; else c[2]++;
	}else if (mi==2){
		if (m[x+1][y]=='*') if (h==0) f[0]=3; else c[0]=3;
		else if (h==0) f[1]++; else c[1]++;
	}else{
		if (m[x][y-1]=='*') if (h==0) f[0]=0; else c[0]=0;
		else if (h==0) f[2]--; else c[2]--;
	}
}
bool pd(){ //判断循环终止条件：如果奶牛坐标与农夫坐标相等，则他们重叠，返回0，退出循环
	if (f[1]==c[1]&&f[2]==c[2]) return 0;
	else return 1;
}
int main(){
	for (int i=0;i<=11;i++) m[i][0]='*',m[i][11]='*';
	for (int i=1;i<=11;i++) m[0][i]='*',m[11][i]='*';
    for (int i=1;i<=10;i++){
    	for (int j=1;j<=10;j++){
    		cin>>m[i][j];
    		if (m[i][j]=='F') f[1]=i,f[2]=j;
    		if (m[i][j]=='C') c[1]=i,c[2]=j;
		}
	}
	while (pd()){//模拟每秒
		tdz=f[1]+f[2]*10+c[1]*100+c[2]*1000+f[0]*10000+c[0]*40000;
		if (zt[tdz]){//死循环了就输出0并结束程序
			cout<<0<<endl;
			return 0;
		}
		zt[tdz]=1;//标记
		move(f[1],f[2],f[0],0);
		move(c[1],c[2],c[0],1);//依次移动农夫和奶牛
		ans++;//记录秒数
	}
	cout<<ans<<endl;//输出
    return 0;
}
看的这么认真，不点个赞多可惜啊！
 957    94 条评论 收起 

早右昕
更新时间：2017-12-03 17:30:13
在 Ta 的博客查看
An amazing Tijie.其实我是来水贡献的
完全没有把题做得很复杂的必要，我通过以下几个方面来精简代码以及维护可读性：

使用struct维护状态，定义俩操作
把地图越界的地方都看作障碍
判无解，数据服务小可以使用vis[i][j][k][l]来表示（i,j),(k,l)的次数，若大于4，很明显至少有两次方向一样==>无解
代码：

#include<cstdio>
#include<algorithm>
using namespace std;
const int dx[]={-1,0,1,0};
const int dy[]={0,1,0,-1};
struct one { int x,y,face; };
char map[12][12];
int vis[11][11][11][11];
void operator++(one& a) {
    int nx=a.x+dx[a.face];
    int ny=a.y+dy[a.face];
    if(map[nx][ny]!='\*') a.x=nx,a.y=ny;
    else a.face++,a.face%=4;
}
bool operator!=(const one&a,const one&b) {
    return a.x!=b.x||a.y!=b.y;
}
int main(){
    one jhon,cow;
    fill(map[0],map[0]+12,'\*');
    fill(map[11],map[11]+12,'\*');
    for(int i=1;i<=10;i++) {
        scanf("%s\n",&map[i][1]);
        map[i][0]=map[i][11]='\*';
        for(int j=1;j<=10;j++) {
            if(map[i][j]=='C') cow=(one) {i,j,0};
            if(map[i][j]=='F') jhon=(one) {i,j,0};
        }
    }
    int ans=0;
    while(jhon!=cow) {
        if(vis[jhon.x][jhon.y][cow.x][cow.y]++==4) {
            printf("0");
            return 0;
        }
        ans++,++jhon,++cow;
    }
    printf("%d\n",ans);
    return 0;
}
至此，问题以完美解决。

 77    27 条评论 收起 

beacon_cwk
更新时间：2018-07-21 13:50:15
在 Ta 的博客查看
这题没有什么坑点，主要问题是判断他们是否能够相遇。一种做法是在移动次数达到一定值时判定为无法相遇，但还有另一种思路：给每个状态设定一个值，如果这个值之前已经出现过，说明他们陷入了循环，不能相遇。每个状态都要保存农夫和牛的x、y坐标（各10种可能）和方向（各4种可能），其中为了避免重复，可以将特征值设为

f
a
r
m
e
r
.
x
+
f
a
r
m
e
r
.
y
∗
10
+
c
o
w
.
x
∗
100
+
c
o
w
.
y
∗
1000
+
f
a
r
m
e
r
.
f
a
c
i
n
g
∗
10000
+
c
o
w
.
f
a
c
i
n
g
∗
40000
farmer.x+farmer.y∗10+cow.x∗100+cow.y∗1000+farmer.facing∗10000+cow.facing∗40000

可以用bool数组来实现以O(1)的复杂度来查询该值是否已经出现。

代码：

#include<cstdio>
bool zt[160005];//10*10*10*10*4*4=160000，开大一点以防万一
char mp[11][11];
int cx,cy,cf,fx,fy,ff,xx[4]={-1,0,1,0},yy[4]={0,1,0,-1},nt,stp;
int main()
{
    for(int i=0;i<10;i++)
    scanf("%s",mp[i]);//读入
    for(int i=0;i<10;i++)
    for(int j=0;j<10;j++)
    {
        if(mp[i][j]=='F')//遇到农夫
        fx=i,fy=j;//设定初始坐标
        if(mp[i][j]=='C')//遇到牛
        cx=i,cy=j;//设定初始坐标
    }
    while(1)
    {
        if(fx==cx&&fy==cy)//相遇了
        {
            printf("%d",stp);//输出步数
            return 0;//退出
        }
        nt=fx+fy*10+cx*100+cy*1000+ff*10000+cf*40000;//生成特征值
        if(zt[nt])//如果出现过了，则无解
        {
            printf("0");
            return 0;
        }
        zt[nt]=1;//保存特征值
        if(fx+xx[ff]<0||fx+xx[ff]>=10||fy+yy[ff]<0||fy+yy[ff]>=10||mp[fx+xx[ff]][fy+yy[ff]]=='*')//判断农夫是否还能向前走
        ff=(ff+1)%4;//如果不行，转向
        else fx=fx+xx[ff],fy=fy+yy[ff];//否则继续向前
        if(cx+xx[cf]<0||cx+xx[cf]>=10||cy+yy[cf]<0||cy+yy[cf]>=10||mp[cx+xx[cf]][cy+yy[cf]]=='*')//判断牛是否还能向前走
        cf=(cf+1)%4;//如果不行，转向
        else cx=cx+xx[cf],cy=cy+yy[cf];//否则继续向前
        stp++;//增加步数
    }
    return 0;
}

 57    21 条评论 收起 

Diamiko  
更新时间：2020-03-13 11:03:00
在 Ta 的博客查看
题目不难，只要细心思考，有耐心地去模拟，就可以做出来

核心算法：模拟（？）
我看有些大佬用了搜索，其实不必

我感觉自己的思想可能是最好理解的

我们用两个
f
l
a
g
flag记录奶牛和FJ的方向

1
1向上，
2
2向右，
3
3向下，
4
4向左

没错，就是顺时针排列

再分别用两个变量记录当前
F
J
FJ和奶牛的坐标

只要坐标不同（即还没有相遇），那么就一直循环，直到相遇，输出步数

在循环时进行判断，只要撞墙或者超出地图范围，就转弯

怎么转弯？

对了，让
f
l
a
g
flag++

撞不了墙，就朝着当前的方向继续走一步

需要注意的一点
转弯之后，是不用走下一步的，因为题目中描述转弯也消耗一分钟

具体请看代码注释

哦对了，是用
P
y
t
h
o
n
Python实现的，但是用别的语言的各位同学也可以看下，因为语法差别对理解的阻碍并不是很大，而且最重要的是思想

a=list()

#建立列表，大体上相当于某些语言的数组

for i in range(10):
	a.append(input())
	for j in range(10):
		if a[i][j]=='F':
      		  	#记录FJ的位置
			fx=i
			fy=j
		if a[i][j]=='C':
      			#记录奶牛的位置
			cx=i
			cy=j
            
#上面那段是输入，就相当于建立了一个二维数组

flagf=flagc=1

#分别是FJ和奶牛的初始方向（向上）

cnt=0

#记录步数（分钟数）

while not(cx==fx and cy==fy):
	#只要坐标不重合，就继续循环
	if flagf==1:
    
    		#向上走，就是横坐标减一
            
		if fx-1<0 or a[fx-1][fy]=='*':
        
        		#如果越界，就转向，不走
                
			flagf=2
		else:
			fx-=1
            
           		 #否则就走
                 
	elif flagf==2:
    
    			#向右走，就是纵坐标加一
                
		if fy+1>=10 or a[fx][fy+1]=='*':
			flagf=3
		else:
			fy+=1
	elif flagf==3:
    
    			#向下走，就是横坐标加一
                
		if fx+1>=10 or a[fx+1][fy]=='*':
			flagf=4
		else:
			fx+=1
	else:
    
    			#向左走，就是纵坐标减一
                
		if fy-1<0 or a[fx][fy-1]=='*':
			flagf=1
		else:
			fy-=1  
	
 	#以上是FJ的判断，下面是奶牛，同理，改变量名就行了

	if flagc==1:
		if cx-1<0 or a[cx-1][cy]=='*':
			flagc=2
		else:
			cx-=1
	elif flagc==2:
		if cy+1>=10 or a[cx][cy+1]=='*':
			flagc=3
		else:
			cy+=1
	elif flagc==3:
		if cx+1>=10 or a[cx+1][cy]=='*':
			flagc=4
		else:
			cx+=1
	else:
		if cy-1<0 or a[cx][cy-1]=='*':
			flagc=1
		else:
			cy-=1  
	cnt+=1
    
    	#步数加一
        
	if cnt>=100000:
    
    	#这是个技巧性的判断，
        #如果走了100000步还抓不到，基本无望了,
        #为了确保正确，可以提高这个数字，
        #但是由于python运行太慢，
        #就不加了，代码是可以通过的
        
		print(0)
        #输出0，到不了
		exit(0)
        #结束程序
print(cnt)
#输出步数
代码到这就结束了，希望大家多多支持

我感觉自己的思想是很好理解的，如果朋友们有问题还可以再询问

写题解不易，求过审

 40    24 条评论 收起 

Thaumaturge
更新时间：2019-03-21 15:35:06
在 Ta 的博客查看
其实就是一道模拟题，还帮助你省去了农夫与牛相撞时的判定过程qwq

看到题后，我们的第一反应是寻找环判重叠来算次数，但这样也太麻烦了，所以考虑更简洁的直接模拟：

由于只有10x10行的地图，因此牛和农夫最多只有400种情况（每个位置有4次，4方向各一次）由乘法原理可知，无论怎么走，最多都只能出现160000种情况，实际上还要小的多（而且160000也非常小了）

那么就可以做了：

#include <bits/stdc++.h>

using namespace std;

int a[12][12],i,j,k,cx,cy,fx,fy;//坐标，f是农夫的，c是牛的
char w;
int ff,fc;//农夫与牛的朝向,0表示向上,1表示向右,2表示向下,3表示向左
int cs;//统计行走次数，为了保险开到200000次好一些（滑稽）
int pd,ok;//为了防止重复走的东西

int main(){
	//freopen("appl.in","r",stdin);
	//freopen("appl.out","w",stdout);
	for(i=1;i<=10;i++)//记录障碍点，牛与人都不算障碍，因此只要记录它们的坐标就行了
		for(j=1;j<=10;j++)
		{
			cin>>w;
			if(w=='*') a[j][i]=-1;//横坐标对应的是列，纵坐标对应的是行
			if(w=='C') {cx=j;cy=i;}
			if(w=='F') {fx=j;fy=i;}
		}
	while((cx!=fx || cy!=fy) && cs<200000)//统计行走次数，注意判定边界
	{
		ff%=4;fc%=4;
		cs++;
		pd=0;//方便判定是否转向
		ok=0;//使得行走一次后会马上打住
		//农夫行走一次
		if(ff==0 && ok==0)
		{
			ok=1;
			if(a[fx][fy-1]!=-1 && fy>1)
			{pd=1;fy--;}
			if(pd==0)
			ff++;//转向
		}
		if(ff==1 && ok==0)
		{
			ok=1;
			if(a[fx+1][fy]!=-1 && fx<10)
			{pd=1;fx++;}
			if(pd==0)
			ff++;
		}
		if(ff==2 && ok==0)
		{
			ok=1;
			if(a[fx][fy+1]!=-1 && fy<10)
			{pd=1;fy++;}
			if(pd==0)
			ff++;
		}
		if(ff==3 && ok==0)
		{
			ok=1;
			if(a[fx-1][fy]!=-1 && fx>1)
			{pd=1;fx--;}
			if(pd==0)
			ff++;
		}
		//牛开始走
		pd=0;
		ok=0;
		if(fc==0 && ok==0)
		{
			ok=1;
			if(a[cx][cy-1]!=-1 && cy>1)
			{pd=1;cy--;}
			if(pd==0)
			fc++;
		}
		if(fc==1 && ok==0)
		{
			ok=1;
			if(a[cx+1][cy]!=-1 && cx<10)
			{pd=1;cx++;}
			if(pd==0)
			fc++;
		}
		if(fc==2 && ok==0)
		{
			ok=1;
			if(a[cx][cy+1]!=-1 && cy<10)
			{pd=1;cy++;}
			if(pd==0)
			fc++;
		}
		if(fc==3 && ok==0)
		{
			ok=1;
			if(a[cx-1][cy]!=-1 && cx>1)
			{pd=1;cx--;}
			if(pd==0)
			fc++;
		}

	}
	if(cs==200000) cout<<0;//对死循环的判定
	else cout<<cs;
	return 0;
}
 32    4 条评论 收起 

Celebrate
更新时间：2018-04-30 19:19:29
在 Ta 的博客查看
这一道题我直接模拟，暴力硬搜，反正不会爆，搜索时记录一下就好了

代码如下：

#include<bits/stdc++.h>
using namespace std;
const int dx[4]={-1,0,1,0};//上、右、下、左四个方向 
const int dy[4]={0,1,0,-1};
int cx,cy,ct;//记录奶牛 
int fx,fy,ft;//记录john 
bool f[21][21],v[21][21][4][21][21][4];//f表示地图是否能走，v表示这种情况是否有出现过 
void dfs(int k)
{
	if(cx==fx && cy==fy)//如果抓到了牛 
	{
		printf("%d\n",k);//输出 
		exit(0);
	}
	if(v[fx][fy][ft][cx][cy][ct]==false)//如果这种情况出现过 
	{
		printf("0\n");
		exit(0);
	}
	v[fx][fy][ft][cx][cy][ct]=false;//把这种情况设置为出现过 
	//找奶牛的方向 
	if(f[cx+dx[ct]][cy+dy[ct]]==false)//如果这个方向不能走 
	{
		ct++;if(ct==4) ct=0;//改变方向 
	}
	else cx=cx+dx[ct],cy=cy+dy[ct];//如果可以走就走 
	//找john的方向 
	if(f[fx+dx[ft]][fy+dy[ft]]==false) 
	{
		ft++;if(ft==4) ft=0;
	}
	else fx=fx+dx[ft],fy=fy+dy[ft];
	dfs(k+1);//往下搜索 
}
int main()
{
	int i,j;char st[21];
	memset(f,false,sizeof(f));//为了方便判断边界，一开始就当做不能走吧 
	for(i=1;i<=10;i++)
	{
		scanf("%s",st+1);//输入 
		for(j=1;j<=10;j++)
		{
			if(st[j]=='.') f[i][j]=true;//如果能走 
			if(st[j]=='F') fx=i,fy=j,f[i][j]=true;//如果是john 
			if(st[j]=='C') cx=i,cy=j,f[i][j]=true;//如果是牛 
		}
	}
	ct=ft=0;//一开始是向北 
	memset(v,true,sizeof(v));//各种情况都是可以的 
	dfs(0);//开始搜索 
	return 0;
}
 27    19 条评论 收起 

Siemens_Thai
更新时间：2019-11-02 17:42:48
在 Ta 的博客查看
本蒟蒻第一篇题解，为CSP普及组小白

本题解为傻子题解，逻辑非常简单，而且其内部含有骗分成分，一般人也可以懂

放代码

#include <bits/stdc++.h> 
using namespace std ;

//基本初始：
char mp[11][11] ; //创建地图
int xa , ya , xb , yb ;	//创建变量表示农夫和牛的位置（ a 为农夫， b 为牛， x 为行， y为列）
int lxa , lya , lxb , lyb ; //创建变量表示农夫和牛移动后的位置（移动可能不成立）
int fa = 1 , fb = 1 ; //创建变量表示农夫和牛的方向（ 1 为北、 2 为东、 3 为南、 4 为西）
int ans = 0 ; //创建变量表示时间（输出结果）

//农夫移动函数：
void yda(){
	//平移区：
	if ( fa == 1 ){ //当方向为北时
		lxa = xa - 1 ; //行向上移动（减 1 ）
		lya = ya ; //列不动
	}
	if ( fa == 2 ){ //当方向为东时
		lxa = xa ; //行不动
		lya = ya + 1 ; //列向右移动（加 1 ）
	}
	if ( fa == 3 ){ //当方向为南时
		lxa = xa + 1 ; //行向下移动（加 1 ）
		lya = ya ; //列不动
	}
	if ( fa == 4 ){ //当方向为西时
		lxa = xa ; //行不动
		lya = ya - 1 ; //列向左移动（减 1 ）
	}
	//判定区：
	if ( lxa >= 1 && lya >= 1 && lya <= 10 && lxa <= 10 && mp[lxa][lya] == '.' ){ //当移动后位置在地图内且为空地
		xa = lxa ; //行位置
		ya = lya ; //列位置
	}
	else{ //不成立 
		fa++ ; //方向转变
		if ( fa > 4 ){ //当方向值大于西侧
			fa = 1 ; //变回北侧
		}
	}
}

//牛移动函数： 
void ydb(){
	//平移区
	if ( fb == 1 ){ //当方向为北时
		lxb = xb - 1 ; //行向上移动（减 1 ）
		lyb = yb ; //列不动
	}
	if ( fb == 2 ){ //当方向为东时
		lxb = xb ; //行不动
		lyb = yb + 1 ; //列向右移动（加 1 ）
	}
	if ( fb == 3 ){ //当方向为南时
		lxb = xb + 1 ; //行向下移动（加 1 ）
		lyb = yb ; //列不动
	}
	if ( fb == 4 ){ //当方向为西时
		lxb = xb ; //行不动
		lyb = yb - 1 ; //列向左移动（减 1 ）
	}
	//判定区：
	if ( lxb >= 1 && lyb >= 1 && lyb <= 10 && lxb <= 10 && mp[lxb][lyb] == '.' ){ //当移动后位置在地图内且为空地
		xb = lxb ; //行位置
		yb = lyb ; //列位置
	}
	else{ //不成立 
		fb++ ; //方向转变
		if ( fb > 4 ){ //当方向值大于西侧
			fb = 1 ; //变回北侧
		}
	}
}

//主函数： 
int main(){
	//输入区：
	for ( int i = 1 ; i <= 10 ; i++ ){ //基本二维输入行
		for ( int j = 1 ; j <= 10 ; j++ ){ //基本二维输入列
			cin >> mp[i][j] ; //输入
			if ( mp[i][j] == 'F' ){ //当输入为农夫位置时，将其存储至农夫的位置
				xa = i ; //储存行
				ya = j ; //储存列
				mp[i][j] = '.' ; //为判断方便，将其变为空地
			}
			if ( mp[i][j] == 'C' ){ //当输入为牛位置时，将其存储至牛的位置
				xb = i ; //储存行
				yb = j ; //储存列
				mp[i][j] = '.' ; //为判断方便，将其变为空地
			}
		}
	}
	//模拟区： 
	while(1){
		yda() ; //农夫移动
		ydb() ; //牛移动
		ans++ ; //时间增加
		if ( ans > 10000 ){ //此处为骗分，如果大于 10000 还是没有重合，即无法重合
			cout << 0 ; //直接输出 0
			return 0 ; //结束程序
		}
		if ( xa == xb && ya == yb ){ //如果重合（行列均相同）
			cout << ans ; //输出时间
			return 0 ; //结束程序
		}
	}
}
 20    6 条评论 收起 

AnicoderAndy  
更新时间：2019-08-19 23:08:08
在 Ta 的博客查看
思路
基本想法

一看就知道是一道模拟题，由于每次行走到的点都是确定的，我们只需要（暴力地）枚举出这次到达的点并且判断是否相遇。

重点问题：如何判断是否有解

这里我想到一个十分巧(pian)妙(fen)的方法。上面的枚举次数如果超过60万那肯定就无解了，所以在上面的循环只要使i从1到600000，如果找到有解，立刻输出并终止程序。

PS：60万这个数字是我随便报的，可能评测机一秒内也就只能运算70万~100万次左右吧嘤嘤嘤

代码
#include <iostream>
#include <string>
#include <utility>
using namespace std;

int op[4][2] = {    //四种操作，由题意，这里必须顺时针排
    {-1, 0},    //0-向上
    {0, 1},     //1-向右
    {1, 0},     //2-向下
    {0, -1}     //3-向左
};

bool no[12][12];//记录某个位置是否有障碍物(true是有障碍物)

pair<int, int> sb, cow;//sb-FarmerJohn的位置,cow-牛的位置

int dirsb = 0, dircow = 0; //二人面向的方向

int ans = 0;

int main()
{
    //输入
    string x[11];
    for (int i = 1; i <= 10; i++) {
        cin >> x[i];
        for (int j = 0; j < 10; j++) {
            //有障碍物
            if (x[i][j] == '*') {
                no[i][j + 1] = true;
            } else if (x[i][j] == 'F') {
                sb = make_pair(i, j + 1); //FJ的位置
            } else if (x[i][j] == 'C') {
                cow = make_pair(i, j + 1);//牛的位置
            }
        }
    }

    //棋盘四周都是障碍物
    for (int i = 0; i <= 11; i++) {
        no[0][i] = no[11][i] = true;
    }
    for (int i = 0; i <= 11; i++) {
        no[i][0] = no[i][11] = true;
    }

    for (int i = 1; i <= 600000; i++) {
        ans++;  //步数+1

        //记录新的位置
        pair<int, int> newsb, newcow;
        newsb = make_pair(sb.first + op[dirsb][0], sb.second + op[dirsb][1]);
        newcow = make_pair(cow.first + op[dircow][0], cow.second + op[dircow][1]);

        //如果有障碍物或没有
        if (no[newsb.first][newsb.second]) dirsb = (dirsb + 1) % 4;
        else sb = newsb;
        
        if (no[newcow.first][newcow.second]) dircow = (dircow + 1) % 4;
        else cow = newcow;

        //如果相遇
        if (sb == cow) {
            cout << ans << endl;
            return 0;
        }
    }
    cout << 0 << endl;
    return 0;
}
 15    13 条评论 收起 

edjzy  
更新时间：2019-07-26 21:17:36
在 Ta 的博客查看
我们可以开一个while循环模拟每一秒John和牛的移动找到后就输出答案
可是如何判断约翰找不到妞牛呢？
这时候就该 骚气 牛逼 的六维数组登场啦！！！
我们来分析一下： 如果当约翰和牛的在同一位置且同一方向重复移动时，那么他们就遇不到（可以自己想一下）
下面上代码:

#include<bits/stdc++.h>
using namespace std;
int a[4]={-1,0,1,0},b[4]={0,1,0,-1},fx,fy,cx,cy,book[12][12][12][12][4][4],ans,i,j;
char s[12][12];
int main()
{
	for(int i=1;i<=10;i++)
	for(int j=1;j<=10;j++){
		cin>>s[i][j];
		if(s[i][j]=='C')cx=i,cy=j;
		if(s[i][j]=='F')fx=i,fy=j;
	}
	book[fx][fy][cx][cy][0][0]=1;
	while(1){
		if(cx==fx&&fy==cy){
			cout<<ans;
			return 0;
		}
		if(cx+a[i]>=1&&cy+b[i]>=1&&cx+a[i]<=10&&cy+b[i]<=10&&s[cx+a[i]][cy+b[i]]!='*'){//牛（约翰）还是否能往前走
			cx+=a[i];
			cy+=b[i];
		}
		else{//否则令他们转向
			if(i==3)i=0;
			else i++;
		}
		if(fx+a[j]>=1&&fy+b[j]>=1&&fx+a[j]<=10&&fy+b[j]<=10&&s[fx+a[j]][fy+b[j]]!='*'){
			fx+=a[j];fy+=b[j];
		}
		else{
			if(j==3)j=0;
			else j++;
		}
		if(book[fx][fy][cx][cy][j][i]){//第一维和第二维为约翰的坐标，三，四维为牛的坐标，5,6分别为约翰和牛的方向
			cout<<0;return 0;
		}
		book[fx][fy][cx][cy][j][i]=1;ans++;
	}
	 
}
也许是 最短 最奇葩 (六维数组而已) 最渣 代码

 16    10 条评论 收起 

Ricardo_Ni
更新时间：2018-06-07 08:11:02
在 Ta 的博客查看
好多人说本题一眼就是模拟题，然后我为什么一眼看是找出一个重复走过的环捏

大致思路：先找出一个路径上的环，然后枚举相遇的点和相遇时的方向，计算时间

这样其实可以过掉1000*1000的数据，我是不是有点小题大做了。。。具体解释看注释

#include <map>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <cstdio>
#include <bitset>
#include <cstring>
#include <iostream>
#include <algorithm>
#define inf 0x3f3f3f3f
// #define maxn 
// #define int long long
using namespace std;
void write(int x){if(x<0){putchar('-');x=-x;}if(x>9) write(x/10);putchar(x%10+'0');}
int read(){int d=0,w=1;char c=getchar();for(;c<'0'||c>'9';c=getchar())if(c==
'-')w=-1;for(;c>='0'&&c<='9';c=getchar())d=(d<<1)+(d<<3)+c-48;return d*w;}
void wln(int x){write(x);putchar('\n');}
void wrs(int x){write(x);putchar(' ');}
int d[4][2]={{-1,0},{0,1},{1,0},{0,-1}},cx,cy,mx,my,tc,tm,f[12][12][5],g[12][12][5],nowm,nowc,t,ans;
//这里d数组是方向数组，这样定义是为了+1后刚好是旋转90度
char s[12][12];
int gcd(int x,int y)
{
	return y?gcd(y,x%y):x;
}
void exgcd(int a,int b,int &x,int &y)
{
	if(!b)
	{
		x=1;
		y=0;
		return;
	}
	exgcd(b,a%b,y,x);
	y-=a/b*x;
	return;
}
signed main()
{
	// freopen("catch.in","r",stdin);
	// freopen("catch.out","w",stdout);
	for(int i=1;i<11;i++)
		gets(s[i]+1);
	for(int i=1;i<11;i++)
		s[i][0]=s[i][11]=s[0][i]=s[11][i]='*';
	for(int i=1;i<11;i++)
		for(int j=1;j<11;j++)
		{
			if(s[i][j]=='C')
			{
				cx=i;
				cy=j;
			}
			if(s[i][j]=='F')
			{
				mx=i;
				my=j;
			}
		}
	//找出F和C在哪，不解释
	nowc=0;
	nowm=0;
	f[cx][cy][0]=g[mx][my][0]=t=1;
	//初始点赋为1是因为标记为0是没有经过的点，会导致第一个点被忽略
	while(1)
	{
		int nx=cx+d[nowc][0],ny=cy+d[nowc][1];
		if(s[nx][ny]!='*')
		{
			cx=nx;
			cy=ny;
		}
		else nowc=(nowc+1)%4;
		if(!f[cx][cy][nowc]) f[cx][cy][nowc]=++t;
			else break;
	}
	//f和g数组是一个时间戳，f[i][j][k]记录最先到[i,j]这个点方向朝k的最少需要时间
	tc=t+1;
	t=1;
	while(1)
	{
		int nx=mx+d[nowm][0],ny=my+d[nowm][1];
		if(s[nx][ny]!='*')
		{
			mx=nx;
			my=ny;
		}
		else nowm=(nowm+1)%4;
		if(!g[mx][my][nowm]) g[mx][my][nowm]=++t;
			else break;
	}
	//由于mx,my,nowm是走过之后才结束的，所以环的大小就是tm-g[mx][my][nowm]，f数组同理
	tm=t+1;
	ans=inf;
	for(int i=1;i<11;i++)
		for(int j=1;j<11;j++)
			for(int k=0;k<4;k++)
				for(int l=0;l<4;l++)
					if(f[i][j][k]&&g[i][j][l])
					{
						if(f[i][j][k]<=f[cx][cy][nowc]&&g[i][j][l]<=g[mx][my][nowm])
						//当这个点既不处于f的环内又不处于g的环内，说明这个点只经过一遍，只要判断两者经过的时间是否相同
						{
							if(f[i][j][k]==g[i][j][l]) ans=min(ans,f[i][j][k]-1);
							continue;
						}
						if(f[i][j][k]<=f[cx][cy][nowc])
						//当这个点不处于f的环内单处于g的环内，判断是否多次绕环可以与f在同一时间相遇
						{
							if(f[i][j][k]>=g[i][j][l]&&(f[i][j][k]-g[i][j][l])%(tm-g[mx][my][nowm])==0) ans=min(ans,f[i][j][k]-1);
							continue;
						}
						if(g[i][j][l]<=g[mx][my][nowm])
						//与上同理
						{
							if(g[i][j][l]>=f[i][j][k]&&(g[i][j][l]-f[i][j][k])%(tc-f[cx][cy][nowc])==0) ans=min(ans,g[i][j][l]-1);
							continue;
						}
						//当这个点处于f的环内又处于g的环内时我们得到若要使两者可以相遇，那么则有 f环的大小*x+第一次f到这个点的时间=g环的大小+第一次g到这个点的时间 ，转化为一个解二元一次不定方程的问题，可以用扩展欧几里得来实现，当然首先要考虑无解与gcd的问题
						int tmx=tc-f[cx][cy][nowc],tmy=tm-g[mx][my][nowm];
						int gd=gcd(tmx,tmy),ch,x,y;
						if(g[i][j][l]>f[i][j][k])
						{
							if((g[i][j][l]-f[i][j][k])%gd!=0) continue;
							ch=(g[i][j][l]-f[i][j][k])/gd;
						}
						else
						{
							if((f[i][j][k]-g[i][j][l])%gd!=0) continue;
							ch=(f[i][j][k]-g[i][j][l])/gd;
						}
						exgcd(tmx,tmy,x,y);
						ans=min(ans,x*ch*tmx+f[i][j][k]-1);
					}
	//上述ans=min(ans,xxx-1);中的-1是因为一开始我们把初始点赋为时间1，而实际是时间0，所以需要-1
	write(ans==inf?0:ans);
	return 0;
}
*/