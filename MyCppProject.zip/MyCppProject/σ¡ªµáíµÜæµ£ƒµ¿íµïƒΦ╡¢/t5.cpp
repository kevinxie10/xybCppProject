#include <algorithm>
#include <cstdio>
#include <iostream>
#include <vector>
#include <cstdio>
#include <string>
using namespace std;
#define MAX 0xFF
//用来存放原始图像和处理后的图像的一个像素
struct IMAGE{
    int in;
    int out;
    IMAGE(int A,int B):in(A),out(B)
    {
    }
};
struct NodeA{
    int ch;
    int cnt;
}tong[MAX+1];//用来排序
bool cmp(struct NodeA x,struct NodeA y){
    return (x.cnt==y.cnt?x.ch>y.ch:x.cnt>y.cnt);
}
int value[16],n,col;//value存放16个灰度值
string str="0123456789ABCDEF",instr[30];
vector<IMAGE> image;
int main(){
    //freopen("data.in", "r", stdin);
    cin>>n;
    for(int i=0;i<n;i++) cin >> instr[i];
    col=instr[0].size()/2;
    //printf("n=%d,col=%d\n",n,col);
    
    for(int i=0;i<n;i++){
        for(int j=0;j<col;j++)
        {
            unsigned int ch;
            sscanf(instr[i].substr(j*2,2).c_str(), "%x", &ch);
            image.push_back(IMAGE(ch,0));
            //printf("%2X ",image.back().in);
        }
        //cout << endl;
    }

    for(int k=0;k<MAX+1;k++) tong[k].ch = k;
    for(int k=0;k<image.size();k++) 
    {
        tong[image[k].in].cnt++;
        //printf("%2X ",image[k].in) ;
        //if((k+1)%col == 0) cout << endl;
    }
    sort(tong, tong+MAX, cmp);
    int m=0;
    for(int k=0;k<16;k++){
        value[m++] = tong[k].ch;
        printf("ch=%d, ch=%X, cnt= %d\n",tong[k].ch,tong[k].ch, tong[k].cnt);
    }
    for(int k=0;k<16;k++)
        printf("%X ",value[k]);
    printf("\n");
    for(int )












    //std::cout << "Hello World!\n";
}