#include <iostream>//地址记得开long long
#include <cstdio>
#include <vector>
#include <map>
using namespace std;
typedef struct newtype{
    string type;
    string name;
    int size;//,dis;//size:该类型大小 dis:该类型相对偏移量
}NewType;
map<string,pair<int,vector<NewType>>>d;//类型向类型成员表的映射
map<string,int>ad;//类型向地址的映射
map<int,string>re;//地址向类型的映射
int tot;//新变量的起始地址
void declare(){//声明
    string s,type,name,nxt="";//s:类型名 type:成员类型 name:成员类型名称 nxt:前缀
    int k,mx=-2147483648,cnt=0,len=0;//k:成员数量 mx:占空间最大的成员 len:结构体空间中一行里所占用的长度
    vector<NewType>v;//s类型映射的成员表
    cin>>s>>k;//s:类型名 k:成员数量
    int tot=0;//测试
    
    for(int cnt=1;cnt<=k;cnt++){//将s的成员加入到成员表中
        cin>>type>>name;//type:成员类型 name:成员类型名称
        vector<NewType>t(d[type].second);//type类型映射的成员表
        if(t.size()==1&&t[0].type==type)//如果type类型是一个基本类型
            v.push_back({type,name,t[0].size});//在成员表中直接加入type类型
        else//type类型是一个结构体类型
            for(auto i:t)
                v.push_back({i.type,name+"."+i.name,i.size});//将type类型中成员全部加入到成员表中，并在成员名称前添加结构体类型变量名+'.'
    }
    
    
    for(auto i:v)//遍历成员表
        mx=max(mx,i.size);//找占空间最大的成员
    
    auto p=v[0].name.rfind(".");
    if(p!=string::npos)nxt=v[0].name.substr(0,p);//将前一个前缀置为第一个基础成员的前缀
    else nxt="basictype";
    
    
    for(auto i:v){//有个坑，一个结构体成员变量后的变量要另起一行
        auto p=i.name.rfind(".");//p:从成员变量名从后往前找出现第一次的'.'
        //cout<<"\nname="<<i.name<<"  p="<<p<<endl;
        string t="";//t:每个基础类型变量的前缀名
        if(p!=string::npos)t=i.name.substr(0,p);//如果有'.'，即其为一个结构体类型的成员变量中的成员，截取它的前缀（不含'.'）
        else t="basictype";
        //if(t==nxt){//如果前缀相同，即为同一个结构体成员变量的成员
            //puts("\nsame or no nxt");
        if(len%i.size)len+=i.size-(len%i.size)+i.size;//成员变量要整除自己的偏移量!!!
        else len+=i.size;
        if(len>mx){//如果超对齐要求
            //puts("\nnewline");
            len=i.size;//另起一行
            cnt++;//行数++
        }
        printf("len=%d cnt=%d   ",len,cnt);//测试
        cout<<v[tot].type<<' '<<v[tot].name<<' '<<v[tot].size<<'\n';//测试
        tot++;//测试
        //}
        //else{//如果不是同一个结构体里的成员
            //puts("\nnotsame");
        //    len=i.size;//另起一行
        //    cnt++;
        //    nxt=t;
        //}
    }
    //因为行数一开始是从0开始排的，所以要加一
    d[s]={(cnt+1)*mx,v};//将类型成员表放进类型映射中
    //for(auto i:v)cout<<i.type<<' '<<i.name<<' '<<i.size<<'\n';//测试:输出成员表中的成员信息
    //printf("cnt=%d mx=%d\n",cnt+1,mx);//测试:输出cnt和mx是否正确
    printf("%d %d\n",(cnt+1)*mx,mx);
}
void build(){//定义
    string t,n;//t:变量类型 n:变量名称
    cin>>t>>n;
    vector<NewType>v(d[t].second);//将该类型的成员表复制到vector中
    //printf("%d\n",tot);
    tot+=d[t].first;
    
}
void address(){//寻址
    string name;
    cin>>name;
    //地址记得开long long
    //地址记得开long long
    //地址记得开long long
    //地址记得开long long
    //地址记得开long long
}
void at(){//取值
    int addr;
    scanf("%d",&addr);
}
int main(){
    //初始化四个基本类型
    //freopen("structin.txt","r",stdin);
    //freopen("structout.txt","w",stdout);
    d["byte"]=make_pair(1,vector<NewType>(1,{"byte","",1}));
    d["short"]=make_pair(2,vector<NewType>(1,{"short","",2}));
    d["int"]=make_pair(4,vector<NewType>(1,{"int","",4}));
    d["long"]=make_pair(8,vector<NewType>(1,{"long","",8}));
    int n,op;
    scanf("%d",&n);
    while(n--){
        scanf("%d",&op);
        switch(op){
            case 1:declare();break;
            case 2:build();break;
            case 3:address();break;
            case 4:at();break;
        }
    }
}
/*

2
1 a 1
long a
1 b 2
a ba
int bb

2
1 a 8
short a
byte b
short c
short d
int e
byte f
short g
short h

1 b 3
a ba
a bg
long bc

2
1 a 8
short a
byte b
short c
short d
int e
byte f
short g
short h

1 b 7
a ba
byte bb
short bc
int bd
short be
long bf
a bg

 */


/*
#include<cstdio>
#include<unordered_map>
#include<cstring>
#include<algorithm>

using hash_t=unsigned int;
using ll=long long;

const hash_t p=0x7fffffffu;
const int maxn=125;

// 字符串hash，但是O(n)
hash_t toHash(char *s){
    hash_t hash_=0u;
    for(int i=0;s[i];i++){
        hash_=(hash_*131u+s[i])%p;
    }
    return hash_;
}

std::unordered_map<hash_t,int> typeName; // 类型名hash -> 类型编号
std::unordered_map<hash_t,int> elemName; // 元素名hash -> 元素编号

int qcnt; // 询问次数
int tcnt; // 类型个数
int ecnt; // 元素个数

struct Type{
    int n; // 子元素个数
    int type[maxn]; // 子元素 类型编号
    std::unordered_map<hash_t,int> name; // 子元素名hash -> 子元素编号 用于操作3
    char names[maxn][12]; // 子元素名 用于操作4
    ll Size; // 类型大小
    ll Req; // 类型对齐要求
    ll Pos[maxn]; // 注意是相对位置
}type[maxn];

void init(){
    type[1].n=type[2].n=type[3].n=type[4].n=0;

    typeName.emplace(toHash((char*)"byte"), 1); // 等同于 typeName[toHash("byte")]=1
    typeName.emplace(toHash((char*)"short"),2);
    typeName.emplace(toHash((char*)"int"),  3);
    typeName.emplace(toHash((char*)"long"), 4);

    type[1].Size=type[1].Req=1ll;
    type[2].Size=type[2].Req=2ll;
    type[3].Size=type[3].Req=4ll;
    type[4].Size=type[4].Req=8ll;

    tcnt=4;
}

char s[12345],t1[12],t2[12];
int k,op;
ll Address; // 绝对头指针 用于操作2

void defType(){
    tcnt++;
    scanf("%s%d",s,&k);
    type[tcnt].n=k;
    typeName.emplace(toHash(s),tcnt);
    ll pos=0,mmod;
    for(int i=1;i<=k;i++){
        scanf("%s%s",t1,t2);
        // 对名字的操作
        int ind1=typeName.find(toHash(t1))->second; // 等同于 typename[toHash(t1)]
        type[tcnt].type[i]=ind1;
        strcpy(type[tcnt].names[i],t2);
        type[tcnt].name.emplace(toHash(t2),i);
        // 对齐
        mmod=pos%type[ind1].Req;
        if(mmod)pos=pos-mmod+type[ind1].Req;
        // 对位置的操作
        type[tcnt].Pos[i]=pos;
        pos+=type[ind1].Size;
        type[tcnt].Req=std::max(type[tcnt].Req,type[ind1].Req);
    }
    // 此处仍需对齐，注意！！！结构体大小要对齐！！！
    mmod=pos%type[tcnt].Req;
    if(mmod)pos=pos-mmod+type[tcnt].Req;
    type[tcnt].Size=pos;
    printf("%lld %lld\n",type[tcnt].Size,type[tcnt].Req);
}

struct Element{
    int type; // 类型编号
    ll Addr; // 绝对位置~
    char name[12];
}elem[maxn];

void defElement(){
    scanf("%s%s",t1,t2);
    ecnt++;
    // 对变量名的操作
    strcpy(elem[ecnt].name,t2);
    elemName.emplace(toHash(t2),ecnt);
    elem[ecnt].type=typeName.find(toHash(t1))->second;
    // 对齐
    ll mmod=Address%type[elem[ecnt].type].Req;
    if(mmod)Address=Address-mmod+type[elem[ecnt].type].Req;     // 对位置的操作
    printf("%lld\n",Address);     elem[ecnt].Addr=Address;
    Address+=type[elem[ecnt].type].Size;
}

// 下一个元素
hash_t getNext(int st,int &tong){
    hash_t hash_=0;
    for(int i=st;s[i]!='.' and s[i];i++,tong++){
        hash_=(hash_*131u+s[i])%p;
    }
    return hash_;
}

void findElement(){
    scanf("%s",s);
    int tong=0,st=0;
    int len=strlen(s);
    int eleid=elemName.find(getNext(st,tong))->second;
    int typid=elem[eleid].type;
    ll Addr=elem[eleid].Addr;
    st+=tong+1;
    while(st<len){ // 不能写 s[st]!!! 因为越界，undefined！！！
        tong=0;
        eleid=type[typid].name.find(getNext(st,tong))->second;
        st+=tong+1;
        // 上面讲了
        Addr+=type[typid].Pos[eleid];
        typid=type[typid].type[eleid];
    }
    printf("%lld\n",Addr);
}

void findAddress(){
    ll Addr;
    scanf("%lld",&Addr);
    int eleid,typid;
    bool flag=false;
    if(elem[ecnt].Addr+type[elem[ecnt].type].Size <= Addr)return printf("ERR\n"),void();
    memset(s,0,sizeof s);
    // 第一段——寻找该地址属于哪个变量
    for(eleid=1;eleid<=ecnt;eleid++){
        if(elem[eleid].Addr <= Addr and Addr < elem[eleid].Addr + type[elem[eleid].type].Size){
            // 找到了！！！
            Addr-=elem[eleid].Addr;
            // 注意 Addr 也是相对地址哦！
            strcat(s,elem[eleid].name);
            strcat(s,".");
            typid=elem[eleid].type;
            flag=true;
            break;
        }else if(elem[eleid].Addr > Addr)return printf("ERR\n"),void();// 空隙
    }
    if(flag == false)return printf("ERR\n"),void();
    // 第二段
    while(true){
        flag=false;
        if(type[typid].n==0)break;
        for(eleid=1;eleid<=type[typid].n;eleid++){
            if(type[typid].Pos[eleid] <= Addr and Addr < type[typid].Pos[eleid] + type[type[typid].type[eleid]].Size){
                // 找到了！！！
                Addr-=type[typid].Pos[eleid];
                strcat(s,type[typid].names[eleid]);
                strcat(s,".");
                typid=type[typid].type[eleid];
                flag=true;
                break;
            }else if(type[typid].Pos[eleid] > Addr)return printf("ERR\n"),void(); // 空隙
        }
        if(flag == false)return printf("ERR\n"),void();
    }
    int LLen=strlen(s);
    s[LLen-1]='\0'; // 注意这个，重要
    printf("%s\n",s);
}

int main(){
    init();
    scanf("%d",&qcnt);
    while(qcnt--){
        scanf("%d",&op);
        if(op==1)defType();
        else if(op==2)defElement();
        else if(op==3)findElement();
        else findAddress();
    }
    return 0;
}

// */
