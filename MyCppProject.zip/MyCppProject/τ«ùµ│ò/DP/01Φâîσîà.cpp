#include <iostream>
using namespace std;
int t,n,w[110],v[110],dp[1010];
int main(){   
    scanf("%d%d",&t,&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d",&w[i],&v[i]);
    for(int i=1;i<=n;i++)
        for(int j=t;j>=0;j--)
            if(j>=w[i])dp[j]=max(dp[j-w[i]]+v[i],dp[j]);
    printf("%d",dp[t]);
    return 0;
}
