#include <cstdio>
#include <cstring>
const int N=15;
int a[N];
long long f[N][N],l,r;//第一维一般是当前枚举到的位数，第二位表示状态（具体问题具体分析） 
long long dp(int pos/*当前枚举到的位*/,/*s代表状态*/,bool lead/*前导0，有些题目需要考察前导0*/,bool limit/*当前位是否可以任选*/)
{
    //递归边界
    if(pos==0) return /*满足条件？1：0*/;
    if(!limit&&!lead&&f[pos][s]!=-1) return f[pos][s];//记忆化,在没有前导0且可以任选的情况下如果当前状态的值已经被计算过则可以直接返回 
    int up=limit?a[pos]:(进制-1);//根据limit判断枚举的上界up,如果前面一直都是取的可以取的最大值，那么当前值最大也是所给数该位的值，反之为要求进制下所能取到的最大值 
    long long ans=0;//记录答案
    for(int i=0;i<=up;i++)//枚举每一位并记录答案 
    {
    	if() return 0;//这个地方有可能会剪枝 
        //这个地方有可能会因为前导0的存在而分类讨论 
        ans+=dp(pos-1,/*状态转移*/,lead&&i==0,limit&&i==a[pos]);//这个仔细想想也比较容易理解 
    }
    if(!limit&&!lead) f[pos][s]=ans;//如果当前可以任选且没有前导0那么就把答案记录下来用于记忆化搜索
    return ans;
}
long long solve(long long x)
{
	if(!x) return ;//一般需要单独讨论x取0的情况，否则有可能在数位DP过程中出现一些不可预知的问题 
    int pos=0;
    while(x)//把数拆分至a数组中 
    {
        a[++pos]=x%进制;
        x/=进制;
    }
    return dp(pos/*从最高位开始枚举*/,/*一系列状态 */,true,true);//刚开始默认为有限制且有前导0 
}
int main()
{
    memset(f,-1,sizeof f);//初始化 
    scanf("%lld%lld",&l,&r);
    printf("%lld\n",solve(r)-solve(l-1));
    return 0;
}