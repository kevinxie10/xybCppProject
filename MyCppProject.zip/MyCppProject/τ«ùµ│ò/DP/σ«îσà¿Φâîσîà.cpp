// 朴素算法 TLE
#include <iostream>
#include <algorithm>
using namespace std;

const int N=1010;
int n, m;
int v[N], w[N];
int f[N][N];

int main(){
  scanf("%d%d",&n,&m);
  for(int i=1; i<=n; i++) 
    scanf("%d%d",&v[i],&w[i]);  //费用，价值
  
  for(int i=1; i<=n; i++)       //阶段：枚举物品
  for(int j=0; j<=m; j++)       //状态：枚举体积
  for(int k=0; k<=j/v[i]; k++)  //决策：枚举个数
    f[i][j]=max(f[i][j], f[i-1][j-v[i]*k]+w[i]*k);
  
  printf("%d\n",f[n][m]);
}