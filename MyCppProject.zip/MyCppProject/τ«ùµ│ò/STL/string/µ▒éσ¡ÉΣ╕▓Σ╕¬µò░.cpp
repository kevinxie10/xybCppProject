#include <iostream>
using namespace std;
string s,sub;
int ans;
int main(){
    cin>>s>>sub;
    for(int i=0;(i=s.find(sub,i))!=string::npos;ans++,i++/*子串不可重叠：i+=len*/);
    printf("%d",ans);
    return 0;
}