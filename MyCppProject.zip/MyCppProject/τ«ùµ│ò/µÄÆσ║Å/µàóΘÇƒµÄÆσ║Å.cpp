#include <iostream>
#include <vector>
 
void slowSort(std::vector<int>& arr, int left, int right) {
    if (left >= right) {
        return;
    }
 
    int mid = (left + right) / 2;
 
    slowSort(arr, left, mid);
    slowSort(arr, mid + 1, right);
 
    if (arr[mid] > arr[right]) {
        std::swap(arr[mid], arr[right]);
    }
 
    slowSort(arr, left, right - 1);
}
 
int main() {
    std::vector<int> arr = {5, 2, 9, 1, 5, 6, 3};
    
    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    
    slowSort(arr, 0, arr.size() - 1);
    
    std::cout << "Sorted array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
 
    return 0;
}