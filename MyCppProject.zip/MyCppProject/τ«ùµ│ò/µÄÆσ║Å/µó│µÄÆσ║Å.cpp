#include <iostream>
#include <time.h>
using namespace std;
 
void combsort(int *arr, int size) 
{
 
  double shrink_factor = 1.247330950103979;
  int gap = size;
  int swapped = 1;
  int swap;
  int i;
 
  while ((gap > 1) || swapped) 
  {
    if (gap > 1) 
	{
		gap = gap / shrink_factor;
	}
 
    swapped = 0; 
    i = 0;
 
    while ((gap + i) < size) 
	{
      if(arr[i]-arr[i+gap] > 0) 
	  {
        swap = arr[i];
        arr[i] = arr[i+gap];
        arr[i+gap] = swap;
        swapped = 1;
      }
      ++i;
    }
  }
}
 
 
void print(int a[],int n)          
{          
    for(int i=0; i<n; i++)          
    {          
        cout<<a[i]<<" ";          
    }          
    cout << endl;          
}          
        
        
void main()          
{          
    int a[10];    
    srand((unsigned)time(NULL));//初始化随机数      
    
    for(int i=0; i<10; i++)    
    {    
        a[i]=rand()%20;    
    }    
    cout << "排序前：";          
    print(a,sizeof(a)/sizeof(a[0]));        
        
    int n=sizeof(a)/sizeof(a[0]);        
    combsort(a,n);     
        
    cout << "排序后：";       
    print(a,sizeof(a)/sizeof(a[0]));          
}      

