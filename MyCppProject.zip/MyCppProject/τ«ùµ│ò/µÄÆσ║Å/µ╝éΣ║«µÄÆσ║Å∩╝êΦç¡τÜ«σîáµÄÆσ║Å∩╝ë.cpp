#include <iostream>
#include <vector>
 
void stoogeSort(std::vector<int>& arr, int left, int right) {
    if (arr[left] > arr[right]) {
        std::swap(arr[left], arr[right]);
    }
 
    if ((right - left + 1) > 2) {
        int t = (right - left + 1) / 3;
 
        stoogeSort(arr, left, right - t);
        stoogeSort(arr, left + t, right);
        stoogeSort(arr, left, right - t);
    }
}
 
int main() {
    std::vector<int> arr = {5, 2, 9, 1, 5, 6, 3};
    
    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    
    stoogeSort(arr, 0, arr.size() - 1);
    
    std::cout << "Sorted array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
 
    return 0;
}