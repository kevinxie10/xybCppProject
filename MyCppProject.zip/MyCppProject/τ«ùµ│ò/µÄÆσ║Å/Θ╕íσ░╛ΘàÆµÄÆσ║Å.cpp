#include <cstdio>
#include <algorithm>
using namespace std;
int n, a[10010];
bool cnt=false;
int main() {
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    while(true){
        bool flag=false;
        cnt=!cnt;
        if(cnt){for(int i=1;i<n;i++)
                if(a[i]<a[i+1])swap(a[i],a[i+1]),flag=true;
            }
        else for(int i=n;i>1;i--){
                if(a[i]>a[i-1])swap(a[i],a[i-1]),flag=true;
            }
        if(!flag)break;
    }
    for(int i=1;i<=n;i++)printf("%d ",a[i]);
    return 0;
}