#include <stdio.h>
  
const int NUM = 17;
void Show(int * p, int len)
{
	for (int i = 0; i < len; ++i)
	{
		printf("%d,", p[i]);
	}
	puts("\b;");
}
void pigeonhole_sort(int* array, int len) 
{
	int a[NUM] = { 0 };
	int i, k, j = 0;
	for (i = 0; i < len; ++i)
		a[array[i]]++;
	for (i = 0; i < NUM; ++i)
		for (k = 0; k < a[i]; ++k)
			array[j++] = i;
}
int main()
{
	int arr[] = { 2,13,7,6,15,9,10,12,3,16,8,11,14,5,1 };
	int len = (int) sizeof(arr) / sizeof(*arr);
	pigeonhole_sort(arr, len);
	Show(arr, len);
	return 0;
}