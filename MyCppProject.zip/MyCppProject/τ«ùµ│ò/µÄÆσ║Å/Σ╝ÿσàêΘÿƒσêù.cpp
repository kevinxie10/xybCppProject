//感慨万千：STL太好用了！
#include  <bits/stdc++.h>
using namespace std;
const int MAXN = 1e8 + 10;
int n;
priority_queue<int, vector<int>, greater<int> >q; //小根堆
int main() {
    scanf("%d", &n); int x;
    for (int i = 1;i <= n; i++) scanf("%d", &x), q.push(x);
    while (!q.empty()) {
        printf("%d ", q.top()); //入队
        q.pop(); //出队
    }
    return 0;
}