#include <bits/stdc++.h>
using namespace std;
bool PatienceSort(datatype *array, int size)
{
    int i, j;
    Node **bucket;
    Node *p;
 
    if(array == NULL) {
        return false;
    }
 
    bucket = (Node **)calloc(size, sizeof(Node *));
    if(bucket == NULL) {
        return false;
    }
 
    for(i = 0; i < size; i++) {
        j = 0;
        //找到第一个最上面的数据比关键字大的桶，如果没找到则指向一个空位置
        while(bucket[j] != NULL && (bucket[j])->data < array[i])
            j++;
 
        p = (Node *)malloc(sizeof(Node));
        if(p == NULL) {
            return false;
        }
        p->data = array[i];
        //将关键字入桶
        if(bucket[j] != NULL) {
            p->next = bucket[j];
        } else {
            p->next = NULL;
        }
 
        bucket[j] = p;
    }
    i = j = 0;
    //顺序的从第一个桶到最后一个桶中取出数据
    while(bucket[j] != NULL) {
        p = bucket[j];
        while(p != NULL) {
            array[i++] = p->data;
            p = p->next;
        }
        j++;
    }
    //进行一次插入排序
    InsertionSort(array, size);
 
    return true;
}