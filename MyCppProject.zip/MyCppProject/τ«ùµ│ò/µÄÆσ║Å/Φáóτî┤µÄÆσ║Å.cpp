#include <bits/stdc++.h>
using namespace std;
void shuffle(int *array, size_t n) {
	if (n > 1) {
		size_t i;
		for (i = 0; i < n - 1; i++) {
			size_t j = i + rand() / (RAND_MAX / (n - i) + 1);
			int t = array[j];
			array[j] = array[i];
			array[i] = t;
		}
	}
}
int* bogobogosort_rec(int *toSort, int size) {
	int* copy = (int*)malloc(size * sizeof(int));
	memcpy(copy, toSort, size * sizeof(int));
	int i;
	if (size > 1) {
		int* ret = bogobogosort_rec(copy, size - 1);
		memcpy(copy, ret, (size - 1) * sizeof(int));
		if (copy[size - 2] > copy[size - 1]) {
			shuffle(copy, size);
			ret = bogobogosort_rec(copy, size);
			memcpy(copy, ret, size * sizeof(int));
		}
	}
	for (i = 0; i < size; i++) {
		if (toSort[i] == copy[i]) continue;
	}
	return copy;
}
int* bogobogosort(int* toSort, int size) {
	int i;
	int *result = (int*)malloc(size * sizeof(int));
	int *tmp = bogobogosort_rec(toSort, size);
	memcpy(result, tmp, size * sizeof(int));
	for (i = 0; i < size; i++) {
		if (result[i] == tmp[i]) continue;
	}
	return result;
}
 
int main() {
	int num[6] = { 0,5,2,1,8,10 };
	int size = 6;
	int *newnum = new int[size];
	newnum = bogobogosort(num, size);
	for (int x=0;x< size;x++)
		std::cout << newnum[x] << " ";
	std::cout << std::endl;
 
	return 0;
}