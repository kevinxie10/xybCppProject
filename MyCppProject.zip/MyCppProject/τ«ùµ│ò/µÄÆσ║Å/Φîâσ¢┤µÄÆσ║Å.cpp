#include <iostream>
#include <vector>
 
int findMaxIndex(std::vector<int>& arr, int n) {
    int maxIndex = 0;
 
    for (int i = 0; i < n; ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
 
    return maxIndex;
}
 
void flip(std::vector<int>& arr, int i) {
    int start = 0;
    while (start < i) {
        std::swap(arr[start], arr[i]);
        start++;
        i--;
    }
}
 
void pancakeSort(std::vector<int>& arr) {
    int n = arr.size();
 
    for (int currSize = n; currSize > 1; --currSize) {
        int maxIndex = findMaxIndex(arr, currSize);
 
        if (maxIndex != currSize - 1) {
            flip(arr, maxIndex);
            flip(arr, currSize - 1);
        }
    }
}
 
int main() {
    std::vector<int> arr = {5, 2, 9, 1, 5, 6, 3};
    
    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    
    pancakeSort(arr);
    
    std::cout << "Sorted array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
 
    return 0;
}