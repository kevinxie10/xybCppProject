#include <iostream>
#include <vector>
 
void cycleSort(std::vector<int>& arr) {
    int n = arr.size();
 
    for (int cycleStart = 0; cycleStart < n - 1; ++cycleStart) {
        int item = arr[cycleStart];
        int pos = cycleStart;
 
        for (int i = cycleStart + 1; i < n; ++i) {
            if (arr[i] < item) {
                pos++;
            }
        }
 
        if (pos == cycleStart)
            continue;
 
        while (item == arr[pos])
            pos++;
 
        if (pos != cycleStart) {
            std::swap(item, arr[pos]);
 
            while (pos != cycleStart) {
                pos = cycleStart;
 
                for (int i = cycleStart + 1; i < n; ++i) {
                    if (arr[i] < item) {
                        pos++;
                    }
                }
 
                while (item == arr[pos])
                    pos++;
 
                if (item != arr[pos])
                    std::swap(item, arr[pos]);
            }
        }
    }
}
 
int main() {
    std::vector<int> arr = {5, 2, 9, 1, 5, 6, 3};
    
    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    
    cycleSort(arr);
    
    std::cout << "Sorted array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
 
    return 0;
}