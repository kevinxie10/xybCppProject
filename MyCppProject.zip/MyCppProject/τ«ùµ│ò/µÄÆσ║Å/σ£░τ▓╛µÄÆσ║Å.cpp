#include <cstdio>
int n,a[10000];
inline void _swap_(int *p,int *q){*p=*p^*q,*q=*p^*q,*p=*p^*q;}
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%d",a+i);
    int i=0;
    while(i<n){
        if(!i)i++;
        if(a[i-1]>a[i]){
            _swap_(a+i-1,a+i);
            i--;
        }
        else i++;
    }
    for(int i=0;i<n;i++)printf("%d ",a[i]);
    return 0;
}