#include<iostream>
using namespace std;
class  index
{
public:
	int start;
	int key;
}newIndex[3];
 
int cmp(const void * a, const void* b)
{
	return (*(index*) a).key > (*(index*)b).key ? 1 : -1;
}
 
int Search(int* arr, int target)
{
	int i = 0;
	while (target > newIndex[i].key)
	{
		i++;
	}
	if (i > 3)//所有分块都找完了
	{
		cout << i << endl;
		return -1;
	}
 
	//顺序查找
	for (int j = newIndex[i].start; j < newIndex[i].start + 6; j++)
	{
		if (arr[j] == target)
		{
			return j;
		}
	}
	return -1;//遍历完整个分块也没找到target
}
int main()
{
	int j = -1;
	int target;
	int a[] = { 33,42,44,38,24,48,22,12,13,8,9,20,60,58,74,49,86,53 };
	//分块
	for (int i = 0; i < 3; i++)
	{
		newIndex[i].start = j+1;//求起始下标
		j += 6;
		for (int k = newIndex[i].start; k < j; k++)
		{
			if (newIndex[i].key < a[k])//寻找该分块中的最大值
			{
				newIndex[i].key = a[k];
			}
		}
	}
 
	qsort(newIndex, 3, sizeof(newIndex[0]), cmp);//对三个分块排序
 
	cout << "输入要查找的值：";
	cin >> target;
	int result = Search(a, target);
	if (result == -1)
	{
		cout << "查不到该值" << endl;
	}
	else
	{
		cout << "它在数组中的位置是:" << result + 1 << endl;
	}
	
	return 0;
}