#include  <bits/stdc++.h>
using namespace std;
int n;
const int MAXN = 1e8 + 10;
int h[MAXN], size;
void down(int u) {
    int t = u;  // t记录最小值
    if (2 * u <= size && h[2 * u] < h[t]) t = 2 * u; // 左儿子
    if (2 * u + 1 <= size && h[2 * u + 1] < h[t]) t = 2 * u + 1; // 右儿子
    if (t != u) { //需要调整
        swap(h[t], h[u]);
        down(t); //递归
    }
}
int main() {
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++) scanf("%d", &h[i]);
    size = n;
    for (int i = n / 2; i >= 1; i--) down(i); //初始化堆
    while (n--) {
        printf("%d ", h[1]);
        h[1] = h[size]; size--;
        down(1); 
    }
    return 0;
}