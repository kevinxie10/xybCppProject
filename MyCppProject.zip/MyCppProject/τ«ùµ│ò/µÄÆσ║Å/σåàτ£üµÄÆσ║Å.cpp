#include <bits/stdc++.h>
using namespace std;
//内省排序算法的实现：
//这里给出一个根据上面的理论分析的最终的排序 cpp 代码
class Solution {
public:
    vector<int> sortArray(vector<int>& nums) {
    nums.push_back(INT_MAX);
        qs(nums, 0, nums.size()-2);
    nums.pop_back();
        return nums;
    }
    
void qs(vector<int>& array, int left, int right){
    int sep;
    if(right-left < 4){
        insertion(array, left, right);
    }
    while(left < right){
        sep = partation(array, left,right);
        swap(array[left], array[sep]);
        qs(array, sep+1, right);
        right = sep-1;
    }
}
inline int partation(vector<int>&a, int lo, int hi) {
    int k = rand() % (hi - lo + 1) + lo;
    swap(a[lo], a[k]);
    int v = a[lo]; k = lo; ++hi; 
    while(true){
        while (a[++lo] < v);
        while(v < a[--hi]);
        if(lo>=hi)return hi;
        swap(a[lo], a[hi]);
    }
}
void insertion(vector<int>&a, int lo, int hi){
    for(int i = lo;i<hi;i++){
        int to_ins = a[i+1];
        int cur = i;
        while(cur >= 0 && a[cur]>to_ins){
            a[cur+1] = a[cur];
            --cur;
        }
        a[cur+1] = to_ins;
    }
}
};