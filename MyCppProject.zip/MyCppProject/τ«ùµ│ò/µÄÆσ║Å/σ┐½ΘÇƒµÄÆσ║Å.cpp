#include<cstdio>
#include<algorithm>
using namespace std;
int n, a[10010];
void qsort(int l, int r){
    if (l>=r)return;
    int i=l,j=r,num=a[l];
    while(i<j){
        while(a[j]>=num&&i<j)j--;
        while(a[i]<=num&&i<j)i++;
        if (i<j)swap(a[i],a[j]);
    }
    a[l]=a[i];a[i]=num;
    qsort(l,i-1);
    qsort(i+1,r);
}
int main(){
    scanf("%d",&n);
    for (int i=1;i<=n;i++)scanf("%d",a+i);
    qsort(1, n);
    for (int i=n;i>=1;i--)printf("%d ",a[i]);
    return 0;
}