#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
 
void sleepSort(std::vector<int>& arr) {
    std::vector<std::thread> threads;
 
    for (int num : arr) {
        threads.emplace_back([num]() {
            std::this_thread::sleep_for(std::chrono::milliseconds(num));
            std::cout << num << " ";
        });
    }
 
    for (std::thread& t : threads) {
        t.join();
    }
}
 
int main() {
    std::vector<int> arr = {5, 2, 9, 1, 5, 6, 3};
    
    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    
    sleepSort(arr);
    
    std::cout << std::endl;
 
    return 0;
}

