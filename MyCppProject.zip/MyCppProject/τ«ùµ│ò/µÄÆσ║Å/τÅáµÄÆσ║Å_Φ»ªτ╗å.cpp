#include <stdio.h>
#include <stdlib.h>
/*
珠子排序
时间复杂度： 约为O(n^2*k) ,空间复杂度：O(n*k+n)

排序过程展示： 
Size:5（数组大小） 
Max:10（数组中的正整数<Max） 

排序前：1  7  4  0  9

0  1  1  1  1  1  1  1  1      珠子数：1
0  0  0  0  0  0  0  1  1      珠子数：7
0  0  0  0  1  1  1  1  1      珠子数：4
1  1  1  1  1  1  1  1  1      珠子数：0
0  0  0  0  0  0  0  0  0      珠子数：9


上方的珠子已全部掉落至第5行
0  1  1  1  1  1  1  1  1
0  0  0  0  1  1  1  1  1
1  1  1  1  1  1  1  1  1
0  0  0  0  0  0  0  1  1
0  0  0  0  0  0  0  0  0


上方的珠子已全部掉落至第4行
0  1  1  1  1  1  1  1  1
1  1  1  1  1  1  1  1  1
0  0  0  0  1  1  1  1  1
0  0  0  0  0  0  0  1  1
0  0  0  0  0  0  0  0  0


上方的珠子已全部掉落至第3行
1  1  1  1  1  1  1  1  1
0  1  1  1  1  1  1  1  1
0  0  0  0  1  1  1  1  1
0  0  0  0  0  0  0  1  1
0  0  0  0  0  0  0  0  0


上方的珠子已全部掉落至第2行
1  1  1  1  1  1  1  1  1
0  1  1  1  1  1  1  1  1
0  0  0  0  1  1  1  1  1
0  0  0  0  0  0  0  1  1
0  0  0  0  0  0  0  0  0

数珠子

1  1  1  1  1  1  1  1  1      珠子数：0
0  1  1  1  1  1  1  1  1      珠子数：1
0  0  0  0  1  1  1  1  1      珠子数：4
0  0  0  0  0  0  0  1  1      珠子数：7
0  0  0  0  0  0  0  0  0      珠子数：9


排序后：0  1  4  7  9

完成排序 
*/ 

void dissort(int t[],int n,int max)
{
	int a=0;
	for(a=0; a<n; a++)
    {
        t[a] = rand()%max;
    }
}
void put(int t[],int n)
{
    int c=0;
    while(c<n)
    {
        printf("%d  ",t[c]);
        c++;
    }
    printf("\n");
}
void BeadSort(int t[],int n)
{
	int t2[n];//用于算盘展示 
	int t3[n];
	int max=0;
	int j,k;
	int tong;
	/**/
	for(j=0;j<n;j++)
	{
		if(t[j]>max)
		{
		max=t[j];
		}
		t3[j]=0;
		t2[j]=t[j];
	} 
	int tt[n][max];
	for(j=0;j<n;j++)//初始化算盘 
	{
		for(k=0;k<max;k++)
		{
			tt[j][k]=1;
		}
	}
	/*for(j=0;j<n;j++)
	{
		t2[j]=max-t[j];
	}*/ 
	for(j=0;j<n;j++)//把珠子放入算盘 
	{
		for(k=0;k<max;k++)
		{
			if(t[j]!=0)
			{
				tt[j][k]=0;//0表示珠子 
				t[j]--;
			}
		}
	}
	for(j=0;j<n;j++)
	{
		tong=0;
		for(k=0;k<max;k++)
		{
			printf("%d  ",tt[j][k]);
			tong++;
			if(tong==max)
			{
				printf("    珠子数：%d",t2[j]);
				printf("\n");
			}
		}
	}
	int j2;
	int j3,k2;
	int tong2=n;
for(j2=0;j2<n-1;j2++)//算盘立起来 
{
	for(j=0;j<n-1;j++)
	{
		for(k=0;k<max;k++)
		{
			if(tt[j][k]==0)
			{
				int tem=tt[j][k];
				tt[j][k]=tt[j+1][k];
				tt[j+1][k]=tem;
			}
		}
	}
	/*printf("\n");printf("j2:%d  flg:%d  \n",j2,flg);*/

	printf("\n");
	printf("\n"); printf("上方的珠子已全部掉落至第%d行\n",tong2);
	for(j3=0;j3<n;j3++)
	{
		
		tong=0;
		for(k2=0;k2<max;k2++)
		{
			printf("%d  ",tt[j3][k2]);
			tong++;
			if(tong==max)
			{
				printf("\n");
			}
		}
	
	}
		tong2--;
}
	for(j=0;j<n;j++)//从第一排开始，数珠子 
	{
		for(k=0;k<max;k++)
		{
			if(tt[j][k]==0)
			{
				t3[j]++;
			}
		}
	}
	printf("\n");printf("数珠子\n");printf("\n");
	for(j=0;j<n;j++)
	{
		tong=0;
		for(k=0;k<max;k++)
		{
			printf("%d  ",tt[j][k]);
			tong++;
			if(tong==max)
			{
				printf("    珠子数：%d",t3[j]);
				printf("\n");
			}
		}
	}
	printf("\n");printf("\n");
	//printf("辅助数组：");put(t3,n);
	
	for(j=0;j<n;j++)
	{
		t[j]=t3[j];
	}
	
}
int main()
{
	int n=5;
	int t[5]={2,6,5,1,4};
	//int n=5;
	//int t[n];
    int max=5;
    printf("Size:%d\n",n);
    printf("Max:%d\n",max);
    dissort(t,n,max);
    printf("\n");printf("\n");
    printf("排序前：");put(t,n);
    printf("\n");printf("\n");
    
	BeadSort(t,n);
	printf("排序后：");put(t,n);
	printf("\n");printf("\n");
	return 0;
}
