#include<bits/stdc++.h>
#define ll long long 
using namespace std;
const int N = 500010;
vector<int > g[N];
int n,fa[N][21],m,s,deep[N],t[N];
void dfs(int x,int f){ 
	fa[x][0] = f; 
	deep[x] = deep[f] + 1;
	for(int i=1;i <= 20 ;i++){
		fa[x][i] = fa[fa[x][i-1]][i-1]; 
	}
	for(int i=0;i<g[x].size();i++){
		if(g[x][i] != f) dfs(g[x][i],x);
	}
}
int lca(int x,int y){
	if(deep[x]<deep[y]) swap(x,y);
	for(int i=20;i>=0;i--){
		if(deep[x] - (1 << i) >= deep[y]){
			x = fa[x][i];
		}
	}
	if(x == y){
		return x;
	}
	for(int i = 20;i>=0;i--){
		while(fa[x][i]!=fa[y][i]){
			x = fa[x][i];
			y = fa[y][i];
		}
	}
	return fa[x][0];
}
int main(){
	cin >> n >> m >> s;
	for(int i=1;i<n;i++){
		int x,y;
		cin >> x >> y;
		g[x].push_back(y);
		g[y].push_back(x);
	}	
	dfs(s,0);
	while(m--){
		int x,y;
		cin >> x >> y;
		cout << lca(x,y) << endl;
	}

	return 0;
}