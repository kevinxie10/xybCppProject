#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
int x,y,n,m,s,deep[500010],fa[500010][20],son[500010],top[500010];
vector<int>g[500010];
void dfs(int x,int f){
    deep[x]=deep[f]+1;
    fa[x][0]=f;
    for(int i=1;i<=18;i++)fa[x][i]=fa[fa[x][i-1]][i-1];
    for(int i:g[x]){
        if(i==f)continue;
        dfs(i,x);
    }
}
void dfs2(int x,int tp){
    top[x]=tp;
    dfs2(son[x],tp);
    for(int i:g[x]){
        if(top[i])continue;

    }
}
int lca(int x,int y){
    if(deep[x]>deep[y])swap(x,y);
    for(int i=18;i>=0;i--)
        if(deep[fa[y][i]]>=deep[x])y=fa[y][i];
    if(x==y)return x;
    for(int i=18;i>=0;i--){
        if(fa[y][i]!=fa[x][i])
            x=fa[x][i],y=fa[y][i];
    return fa[x][0];
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<n;i++){
        scanf("%d%d",&x,&y);
        g[x].push_back(y),g[y].push_back(x);
    }
    dfs(s,0);
    while(m--){
        scanf("%d%d",&x,&y);
        printf("")
    }
    return 0;
}