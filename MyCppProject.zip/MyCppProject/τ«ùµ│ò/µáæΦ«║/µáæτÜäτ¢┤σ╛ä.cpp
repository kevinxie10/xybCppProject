#include <iostream>
#include <vector>
using namespace std;
const int N=100010;
int n,a,b,c,ans;
typedef struct Edge{int v,w;}edge;
vector<edge>g[N];
int dfs(int x,int fa){
	int d1=0,d2=0;
	for(auto i:g[x]){
		int y=i.v,z=i.w;
		if(y==fa)continue;
		int d=dfs(y,x)+z;
		if(d>=d1)d2=d1,d1=d;
		else if(d>d2)d2=d;
	}
	ans=max(ans,d1+d2);
	return d1;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&a,&b,&c);
    	g[a].push_back({b,c});
    	g[b].push_back({a,c});
	}
	dfs(1,-1);
	printf("%d",ans);
	return 0;
}