#include <iostream>
#include <vector>
using namespace std;
const int N=200010;
int n,u,v,w,dis[N],disA[N],A,B;//A:从1号点出发找到的最远点
vector<pair<int,int>>g[N];
void dfs(int u,int f){
	for(auto i:g[u]){
		if(i.second==f)continue;
		dis[i.second]=dis[u]+i.first;
		if(dis[i.second]>dis[A])A=i.second; 
		dfs(i.second,u);
	}
}
void dfsA(int u,int f){
	for(auto i:g[u]){
		if(i.second==f)continue;
		disA[i.second]=disA[u]+i.first;
		if(disA[i.second]>disA[B])B=i.second;
		dfsA(i.second,u);
	}
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&u,&v,&w);
		g[u].push_back({w,v});
		g[v].push_back({w,u});
	}
	dfs(1,0);
	dfsA(A,0);
	printf("%d",disA[B]);
	return 0;
}