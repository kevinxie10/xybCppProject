#include <cstdio>
int n;
struct node{
    int l,r;
}tree[1000010];
void nxt_order(int x){
    printf("%d ",x);
    if(tree[x].l)nxt_order(tree[x].l);
    if(tree[x].r)nxt_order(tree[x].r);
    return ;
}
void in_order(int x){
    if(tree[x].l)in_order(tree[x].l);
    printf("%d ",x);
    if(tree[x].r)in_order(tree[x].r);
}
void post_order(int x){
    if(tree[x].l)post_order(tree[x].l);
    if(tree[x].r)post_order(tree[x].r);
    printf("%d ",x);
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d%d",&tree[i].l,&tree[i].r);
    nxt_order(1);
    printf("\n");
    in_order(1);
    printf("\n");
    post_order(1);
    printf("\n");
    return 0;
}
