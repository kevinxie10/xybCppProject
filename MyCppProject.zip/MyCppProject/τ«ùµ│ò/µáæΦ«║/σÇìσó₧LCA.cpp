#include <iostream>
#include <vector>
using namespace std;
const int N=500010;
int n,m,root,x,y;
vector<int>g[N];
int deep[N],fa[N][21];
void dfs(int x,int f){
    deep[x]=deep[f]+1,fa[x][0]=f;
    for(int i=1;i<=20;i++)fa[x][i]=fa[fa[x][i-1]][i-1];
    for(int y:g[x])
        if(y!=f)dfs(y,x);
}
int lca(int x,int y){
    if(deep[x]<deep[y])swap(x,y);
    for(int i=20;~i/*i>=0*/;i--)
        if(deep[fa[x][i]]>=deep[y])x=fa[x][i];
    if(x==y)return y;
    for(int i=20;~i;i--)
        if(fa[x][i]!=fa[y][i])x=fa[x][i],y=fa[y][i];
    return fa[x][0];
}
int main(){
    scanf("%d%d%d",&n,&m,&root);
    for(int i=1;i<n;i++){
        scanf("%d%d",&x,&y);
        g[x].push_back(y),g[y].push_back(x);
    }
    dfs(root,0);
    while(m--){
        scanf("%d%d",&x,&y);
        printf("%d\n",lca(x,y));
    }
    return 0;
}