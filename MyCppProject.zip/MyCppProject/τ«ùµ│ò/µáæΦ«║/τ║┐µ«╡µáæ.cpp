#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 100010;
int n, m;
ll a[N];
struct node{
	int l, r;
	ll sum, tag;
}tree[N * 4];
void pushdown(int i){
	tree[i << 1].tag += tree[i].tag;
	tree[i << 1 | 1].tag += tree[i].tag;
	tree[i << 1].sum += (tree[i << 1].r - tree[i << 1].l + 1) * tree[i].tag;
	tree[i << 1 | 1].sum += (tree[i << 1 | 1].r - tree[i << 1| 1].l + 1) * tree[i].tag;
	tree[i].tag = 0;
	return ;
}
void build(int i, int l, int r){
	tree[i].l = l;
	tree[i].r = r;
	if(l == r){
		tree[i].sum = a[l];
		return ;
	}
	int mid = l + r >> 1;
	build(i << 1, l, mid);
	build(i << 1 | 1, mid + 1, r);
	tree[i].sum = tree[i << 1].sum + tree[i << 1 | 1].sum;
	return ;
}
void add(int i, int l, int r, ll k){
	if(tree[i].l >= l && tree[i].r <= r){
		tree[i].tag += k;
		tree[i].sum += k * (tree[i].r - tree[i].l + 1);
		return ;
	}
	int mid = tree[i].l + tree[i].r >> 1;
	pushdown(i);
	if(l <= mid) add(i << 1, l , r, k);
	if(r >= mid + 1) add(i << 1 | 1, l, r, k);
	tree[i].sum = tree[i << 1].sum + tree[i << 1 | 1].sum;
	return ;
}
ll query(int i, int l, int r){
	if(tree[i].l >= l && tree[i].r <= r){
		return tree[i].sum;
	}
	pushdown(i);
	int mid = tree[i].l + tree[i].r >> 1;
	ll ans = 0;
	if(l <= mid) ans += query(i << 1, l, r);
	if(r >= mid + 1) ans += query(i << 1 | 1, l, r); 
	return ans;
}
int main(){
	cin >> n >> m;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
	}
	build(1, 1, n);
	while(m--){
		ll op, l, r, k;
		cin >> op >> l >> r;
		if(op == 1){
			cin >> k;
			add(1, l, r, k);
		}else{
			cout << query(1, l, r) << endl;
		}
	}
	return 0;
}  