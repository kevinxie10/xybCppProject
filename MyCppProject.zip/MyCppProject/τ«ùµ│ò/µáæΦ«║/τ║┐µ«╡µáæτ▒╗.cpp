#include <cstdio>
int n,q,op,x,y,k;

class STREE{
private:
    struct NODE{
        int l,r;
        long long sum,tag;
    }*tr=nullptr;
    
    int *a;

    void read(int n){
        a=new int[n+10];
        for(int i=1;i<=n;i++)scanf("%d",a+i);
    }

    void build(int p,int l,int r){
        tr[p]={l,r,a[l],0};
        if(l==r)return ;
        int mid=(l+r)>>1;
        build(p<<1,l,mid),build(p<<1|1,mid+1,r);
        tr[p].sum=tr[p<<1].sum+tr[p<<1|1].sum;
        return ;
    }

    void pushdown(int p){
        tr[p<<1].sum+=tr[p].tag*(tr[p<<1].r-tr[p<<1].l+1);
        tr[p<<1|1].sum+=tr[p].tag*(tr[p<<1|1].r-tr[p<<1|1].l+1);
        tr[p<<1].tag+=tr[p].tag,tr[p<<1|1].tag+=tr[p].tag;
        tr[p].tag=0;
        return ;
    }

    void add(int p,int l,int r,int k){
        if(l<=tr[p].l&&tr[p].r<=r){
            tr[p].sum+=(tr[p].r-tr[p].l+1)*k;
            tr[p].tag+=k;
            return ;
        }
        int mid=(tr[p].l+tr[p].r)>>1;
        pushdown(p);
        if(l<=mid)add(p<<1,l,r,k);
        if(mid+1<=r)add(p<<1|1,l,r,k);
        tr[p].sum=tr[p<<1].sum+tr[p<<1|1].sum;
        return ;
    }

    long long query(int p,int l,int r){
	    if(l<=tr[p].l&&tr[p].r<=r)return tr[p].sum;
	    pushdown(p);
	    int mid=(tr[p].l+tr[p].r)>>1;
	    long long ans=0;
	    if(l<=mid)ans+=query(p<<1,l,r);
	    if(r>=mid+1)ans+=query(p<<1|1,l,r); 
	    return ans;
    }
public:
    STREE(int n){
        tr=new struct NODE [n<<2];
    }

    void init(int p,int l,int r){
        if(tr==nullptr)tr=new struct NODE [r<<2];
        read(r);
        build(p,l,r);
    }
    
    void add(int l,int r,int k){
        add(1,l,r,k);
        return ;
    }

    long long query(int l,int r){
        return query(1,l,r);
    }

    ~STREE(){
        delete [] tr;
        delete [] a;
    }
};

int main(){
    scanf("%d%d",&n,&q);
    STREE tree(n);
    tree.init(1,1,n);
    while(q--){
        scanf("%d",&op);
        if(op==1)scanf("%d%d%d",&x,&y,&k),tree.add(x,y,k);
        else scanf("%d%d",&x,&y),printf("%lld\n",tree.query(x,y));
    }
    return 0;
}