#include <cstdio>
int Gcd(int m,int n){
	if(m==n)return m;
	if(m<n)return Gcd(n,m);
	if(!(m&1))return !(n&1)?Gcd(m>>1,n>>1)<<1:Gcd(m/2,n);
	return !(n&1)?Gcd(m,n/2):Gcd(n,m-n);
}
int GCD(int m,int n){return n?GCD(n,m%n):m;}
int x,y;
int main(){
    scanf("%d%d",&x,&y);
    printf("%d",Gcd(x,y));
    return 0;
}