#include <cstdio>
int t,n,a[10010],sum;
int main(){
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            scanf("%d",a+i);
            if(!a[i])i--,n--;
        }
        for(int i=1;i<=n;i++)sum^=a[i];
        if(sum)printf("Yes\n");
        else printf("No\n");
        sum=0;
    }
    return 0;
}