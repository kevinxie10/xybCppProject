#include <cstdio>
long long a,b,x,y;
void exgcd(long long a,long long b){
    if(b==0){x=1,y=0;return;}
    exgcd(b,a%b);
    long long xx=x;
    x=y;
    y=xx-a/b*y;
}
int main(){
    scanf("%lld%lld",&a,&b);
    exgcd(a,b);
    printf("%lld",(x%b+b)%b);
    return 0;
}