#include <cstdio>
long long n,ans,cnt;
int main(){
    scanf("%lld",&n);
    for(int i=1;i<=n;i=cnt+1)
        cnt=n/(n/i),ans+=(cnt-i+1)*(n/i);
    printf("%lld",ans);
    return 0;
}