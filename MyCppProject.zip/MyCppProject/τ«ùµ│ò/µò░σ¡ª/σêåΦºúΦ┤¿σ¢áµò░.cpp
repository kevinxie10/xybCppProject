#include <cstdio>
long long n;
int main(){
    scanf("%lld",&n);
    if(n==1){printf("1\n");return 0;}
    for(long long i=2;i*i<=n;i++)
        if(n%i==0)
            while(n%i==0)printf("%lld ",i),n/=i;
    if(n>1)printf("%lld",n);
    return 0;
}