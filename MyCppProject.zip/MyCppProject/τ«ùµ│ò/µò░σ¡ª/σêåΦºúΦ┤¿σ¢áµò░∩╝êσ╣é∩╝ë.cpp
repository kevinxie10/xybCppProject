#include <cstdio>
long long n,cnt;
int main(){
    scanf("%lld",&n);
	for(long long i=2;i*i<=n;i++){
		if(!(n%i)){
			while(!(n%i))n/=i,cnt++;
			if(cnt==1)printf("%lld",i);
			else printf("%lld^%lld",i,cnt);
			if(n>1)printf(" * ");
		}
		cnt=0;
	}
	if(n>1)printf("%lld",n);
	return 0;
}