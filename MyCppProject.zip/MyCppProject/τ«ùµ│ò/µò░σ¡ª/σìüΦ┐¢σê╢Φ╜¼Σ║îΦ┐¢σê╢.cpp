#include <cstdio>
long long n;
int i;
char c[10000];
int main(){
	scanf("%lld",&n);
	for(;n;i++){
		c[i]=n&1;
		n>>=1;
	}
	for(i--;i>=0;i--)printf("%d",c[i]);
    return 0;
}