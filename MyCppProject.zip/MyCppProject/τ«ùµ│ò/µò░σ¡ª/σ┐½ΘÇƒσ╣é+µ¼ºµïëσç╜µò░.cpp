#include <cstdio>
long long a,b;
int phi(int n){
    int ans=1;//ans=n
    for(int i=2;i*i<=n;i++){
        if(n%i==0){
            n/=i,ans*=i-1;//ans=ans/i*(i-1);
            while(n%i==0)n/=i,ans*=i;//n/=i;
        }
    }
    if(n>1)ans*=n-1;//ans=ans/n*(n-1);
    return ans;
}
int power(long long a,long long p){
    long long ans=1;
    while(p){
        if(p&1)
            ans=ans*a%b;
        a=a*a%b;
        p>>=1;
    }
    return (int)ans;
}
int main(){
    scanf("%lld%lld",&a,&b);
    printf("%d",power(a,phi(b)-1));
    return 0;
}