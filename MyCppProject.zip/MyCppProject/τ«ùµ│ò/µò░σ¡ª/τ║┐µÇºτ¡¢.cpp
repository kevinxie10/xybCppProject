#include <cstdio>
#include <cstring>
const int N=100000010;
int n,q,k,prime[100000010],cnt;
bool isprime[N];
void init(int n){
    memset(isprime,1,sizeof isprime);
    isprime[0]=isprime[1]=false;
    for(int i=2;i<=n;i++){
        if(isprime[i])prime[++cnt]=i;
        for(int j=1;j<=cnt&&i*prime[j]<=n;j++){
            isprime[i*prime[j]]=false;
            if(i%prime[j]==0)break;
        }
    }
    return ;
}
int main(){
    scanf("%d%d",&n,&q);
    init(n);
    while(q--){
        scanf("%d",&k);
        printf("%d\n",prime[k]);
    }
    return 0;
}