#include <iostream>
int n,m,a[110],b[110];
void dfs(int k){
    if(k>m){
        for(int i=1;i<=m;i++)printf("%3d",a[i]);
        printf("\n");
        return ;
    }
    for(int i=a[k-1]+1;i<=n;i++)
        if(!b[i]){
            b[i]=1,a[k]=i;
            dfs(k+1);
            b[i]=0;
        }
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    dfs(1);
    return 0;
}