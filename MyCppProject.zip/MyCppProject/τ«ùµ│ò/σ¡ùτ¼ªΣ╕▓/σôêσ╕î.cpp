#include <iostream>
using namespace std;
typedef unsigned long long ULL;
const int N=1000010,P=131;
int n,m,a,b,c,d;
char s[N];
ULL p[N],h[N];
void init(){
    p[0]=1,h[0]=0;
    for(int i=1;i<=n;i++){
        p[i]=p[i-1]*P;
        h[i]=h[i-1]*P+s[i];
    }  
}
ULL get(int l,int r){ return h[r]-h[l-1]*p[r-l+1];}
bool substr(int l1,int r1,int l2,int r2){return get(l1,r1)==get(l2,r2);}
int main(){
    cin>>n>>m;
    scanf("%s",s+1);
    init();
    while(m--){
        cin>>a>>b>>c>>d;
        if(substr(a,b,c,d))puts("Yes");
        else puts("No");
    }
    return 0;
}