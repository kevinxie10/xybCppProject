#include <iostream>
#include <vector>
using namespace std;
const int N=100010;
vector<int>g[N];
int dfn[N],low[N],tot,root,n,m,x,y,ans;
bool cut[N];
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    int child=0;
    for(int y:g[x]){
        if(!dfn[y]){
            tarjan(y);
            low[x]=min(low[x],low[y]);
            if(low[y]>=dfn[x]){
                child++;
                if(x!=root||child>=2)ans+=!cut[x],cut[x]=true;
            }
        }
        else low[x]=min(low[x],dfn[y]);
    }
    if(child>=2&&x==root)ans+=!cut[x],cut[x]=true;
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&x,&y);
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i])root=i,tarjan(i);
    printf("%d\n",ans);
    for(int i=1;i<=n;i++)
        if(cut[i])printf("%d ",i);
    return 0;
}