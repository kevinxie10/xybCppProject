#include <iostream>
#include <vector>
using namespace std;
const int N=100010;
int n,m,dfn[N],low[N],tms,cnt,x,y;
bool cut[N];
vector<int>g[N];
void tarjan(int x,int f){
    dfn[x]=low[x]=++tms;
    int son=0;
    for(auto i:g[x]){
        if(!dfn[i]){
            son++;
            tarjan(i,x);
            low[x]=min(low[i],low[x]);
            if(x!=f&&!cut[x]&&low[i]>=dfn[x])cnt++,cut[x]=true;
        }
        else if(i!=f)low[x]=min(low[x],dfn[i]);
    }
    if(x==f&&son>=2&&!cut[x])cnt++,cut[x]=true;
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&x,&y);
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i])tarjan(i,i);
    printf("%d\n",cnt);
    for(int i=1;i<=n;i++)
        if(cut[i])printf("%d ",i);
    return 0;
}