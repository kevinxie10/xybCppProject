#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;
const int N=50010;
vector<int>g[N],newg[N],vdcc[N];
stack<int>s;
int n,m,dfn[N],low[N],tot,root,cnt,u,v;//,num,id[N]
bool cut[N];
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    s.push(x);
    //if(!g[x].size()){vdcc[++cnt].push_back(x);return ;}
    int child=0,k;
    for(int y:g[x]){
        if(!dfn[y]){
            tarjan(y);
            low[x]=min(low[x],low[y]);
            if(low[y]>=dfn[x]){
                child++;
                if(x!=root||child>=2)cut[x]=true;
                cnt++;
                do{
                    k=s.top();
                    s.pop();
                    vdcc[cnt].push_back(k);
                }while(y!=k);
                vdcc[cnt].push_back(x);
            } 
        }
        else low[x]=min(low[x],dfn[y]);
    }
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    while(m--){
        scanf("%d%d",&u,&v);
        g[u].push_back(v);
        g[v].push_back(u);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i])root=i,tarjan(root);
    /*num=cnt;
    for(int i=1;i<=n;i++)
        if(cut[i])id[i]=++num;
    for(int i=1;i<=cnt;i++)
        for(int j=1;j<vdcc[i].size();j++)
            if(cut[vdcc[i][j]]){
                newg[i].push_back((id[vdcc[i][j]]));
                newg[id[vdcc[i][j]]].push_back(i);
            }*/
    for(int i=1;i<=cnt;i++)sort(vdcc[i].begin(),vdcc[i].end());
    sort(vdcc+1,vdcc+1+cnt);
    printf("%d\n",cnt);
    for(int i=1;i<=cnt;i++,puts(""))
        for(auto i:vdcc[i])printf("%d ",i);
    return 0;
}