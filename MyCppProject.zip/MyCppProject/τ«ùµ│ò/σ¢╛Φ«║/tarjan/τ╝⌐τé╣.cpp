#include <iostream>
#include <vector>
using namespace std;
const int N=10010;
vector<int>e[N],ne[N];
int dfn[N],low[N],tot,stk[N],top,scc[N],cnt,a[N],na[N],dp[N],n,m,u,v,ans;
bool in[N];
void tarjan(int x){
    dfn[x]=low[x]=++tot;
    stk[++top]=x,in[x]=true;
    for(auto y:e[x]){
        if(!dfn[y])tarjan(y),low[x]=min(low[x],low[y]);
        else if(in[y])low[x]=min(low[x],dfn[y]);
    }
    if(dfn[x]==low[x]){
        int y;
        cnt++;
        do{
            y=stk[top--];
            in[y]=0;
            scc[y]=cnt;
        }while(y!=x);
    }
    return ;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&u,&v);
        e[u].push_back(v);
    }
    for(int i=1;i<=n;i++)
        if(!dfn[i])tarjan(i);
    for(int x=1;x<=n;x++){
        na[scc[x]]+=a[x];
        for(auto y:e[x])
            if(scc[x]!=scc[y])ne[scc[x]].push_back(scc[y]);
    }
    for(int x=cnt;x;x--){
        if(!dp[x])dp[x]=na[x];
        for(auto y:ne[x])dp[y]=max(dp[y],dp[x]+na[y]);
    }
    for(int i=1;i<=cnt;i++)ans=max(ans,dp[i]);
    printf("%d",ans);
    return 0;
}