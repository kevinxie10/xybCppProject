#include <iostream>
#include <algorithm>
using namespace std;
int n,m,fa[5010],x,y,ans,cnt;
struct EDGE{
    int x,y,z;
    bool operator<(const EDGE &a){
        return z<a.z;
    }
}e[200010];
int find(int x){
    return (x==fa[x]?x:fa[x]=find(fa[x]));
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1;i<=m;i++)scanf("%d%d%d",&e[i].x,&e[i].y,&e[i].z);
    sort(e+1,e+1+m);
    for(int i=1;i<=m;i++){
        x=find(e[i].x),y=find(e[i].y);
        if(x==y)continue;
        fa[x]=y,ans+=e[i].z;
        cnt++;
    }
    if(cnt!=n-1)puts("orz");
    else printf("%d",ans);
    return 0;
}