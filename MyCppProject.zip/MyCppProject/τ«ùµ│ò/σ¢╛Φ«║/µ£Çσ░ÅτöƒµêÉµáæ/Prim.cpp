#include<bits/stdc++.h>
#define INF 0x7f7ff
using namespace std;
int n,m,dist[5010],head[5010],k,ans;
bool vis[5010];
struct EDGE{
    int to,next,w;
}e[400010];
void add(int u,int v,int w){
    e[++k].to=v;
    e[k].w=w;
    e[k].next=head[u];
    head[u]=k;
}
void Prime(){
    fill(dist+1,dist+n+1,INF);
    dist[1]=0;
    for(int j=1;j<=n;j++){
        int u=-1,minn=INF;
        for(int i=1;i<=n;i++){
            if(dist[i]<minn&&!vis[i]){
                u=i;
                minn=dist[i];
            }
        }
        if(u==-1){ans=-1;return;}
        vis[u]=1;
        ans+=dist[u];
        for(int i=head[u];i;i=e[i].next){
            int v=e[i].to;
            if(!vis[v]&&dist[v]>e[i].w)dist[v]=e[i].w;
        }
    }
}
int main(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int a,b,c;
        cin>>a>>b>>c;
        add(a,b,c);
        add(b,a,c);
    }
    Prime();
    if(ans==-1)cout<<"orz"<<endl;
    else cout<<ans;
}