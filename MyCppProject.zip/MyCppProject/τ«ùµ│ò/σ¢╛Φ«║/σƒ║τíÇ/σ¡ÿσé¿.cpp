#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
int n,m,u,v;
vector<int>g[1010];
bool mp[1010][1010];
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&u,&v);
        g[u].push_back(v),g[v].push_back(u);
        mp[u][v]=mp[v][u]=true;
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)printf("%d ",mp[i][j]);
        printf("\n");
    }
    for(int i=1;i<=n;i++){
        printf("%ld ",g[i].size());
        sort(g[i].begin(),g[i].end());
        for(auto it:g[i])printf("%d ",it);
        printf("\n");
    }
    return 0;
}