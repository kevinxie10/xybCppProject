#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
map<int,int>mp;
int n,a[200010],t[200010],m;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;t[i]=a[i],i++)scanf("%d",a+i);
    sort(t+1,t+1+n);
    m=unique(t+1,t+1+n)-t;
    //for(int i=1;i<=n;i++)a[i]=lower_bound(t+1,t+1+n,a[i])-t;
    for(int i=1;i<m;i++)mp[t[i]]=i;
    for(int i=1;i<=n;i++)printf("%d ",mp[a[i]]);
    return 0;
}