#include <iostream>
#include <algorithm>
#include <cmath>
const int N=50010;
struct node{
    int l,r,id;
}q[N];
int n,m,k,a[N],l=1,r,len;
long long cnt[N],answer[N],ans;
int cmp(const node &a,const node &b){return (a.l-1)/len+1==(b.l-1)/len+1?a.r<b.r:a.l<b.l;}
void add(int x){ans+=(2*cnt[a[x]]++-1);}
void del(int x){ans-=(2*--cnt[a[x]]+1);}
int main(){
    scanf("%d%d%d",&n,&m,&k);
    len=std::sqrt(n);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    for(int i=1;i<=m;i++)scanf("%d%d",&q[i].l,&q[i].r),q[i].id=i;
    std::sort(q+1,q+1+m,cmp);
    for(int i=1;i<=m;i++){
        while(l>q[i].l)add(l--);//ans+=2*cnt[a[l--]]++-1;
        while(r<q[i].r)ans+=2*++cnt[a[++r]]-1;
        while(l<q[i].l)ans-=2*--cnt[a[l++]]+1;
        while(r>q[i].r)ans-=2*--cnt[a[r--]]+1;
        answer[q[i].id]=ans;
    }
    for(int i=1;i<=m;i++)printf("%lld\n",answer[i]);
    return 0;
}