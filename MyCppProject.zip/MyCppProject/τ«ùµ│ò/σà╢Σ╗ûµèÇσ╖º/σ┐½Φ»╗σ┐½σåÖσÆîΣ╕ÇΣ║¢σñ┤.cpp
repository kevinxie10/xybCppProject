#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define pb push_back
#define pf push_front
#define pob pop_back
#define pof pop_front
#define pii pair<int,int>
#define pli pair<ll,int>
#define pll pair<ll,ll>
#define pil pair<int,ll>
#define fi first
#define se second
using namespace std;
inline ll read(){
    ll k=0,flag=1;
    char c=getchar();
    while(c<'0'||c>'9'){
        if(c=='-')flag=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9')
        k=(k<<1)+(k<<3)+(c^48),c=getchar();
    return k*flag;
}
inline void print(int n){
    if(n<0){
        putchar('-');
        n*=-1;
    }
    if(n>9)print(n/10);
    putchar(n%10+'0');
}
