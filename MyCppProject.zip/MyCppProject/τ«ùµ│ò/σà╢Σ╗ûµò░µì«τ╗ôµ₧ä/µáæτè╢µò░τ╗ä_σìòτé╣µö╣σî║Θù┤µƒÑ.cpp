#include <bits/stdc++.h>
#define lowbit(x) ((x)&(-(x)))
using namespace std;
int n,m,c[500010],sum,op,x,y,k;
void add(int x,int k){
    for(;x<=n;x+=lowbit(x))c[x]+=k;
}
int find(int x){
    for(sum=0;x>0;x-=lowbit(x))sum+=c[x];
    return sum;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1,x;i<=n;i++)scanf("%d",&x),add(i,x);
    while(m--){
        scanf("%d",&op);
        if(op==1)scanf("%d%d",&x,&k),add(x,k);
        else scanf("%d%d",&x,&y),printf("%d\n",find(y)-find(x-1));
    }
    return 0;
}