#include <cstdio>
#define lowbit(x) ((x)&(-(x))) 
const int N=500010;
long long n,m,op,x,y,k,a[N],c[N],sum;
void add(long long x,long long k){
	for(;x<=n;x+=lowbit(x))c[x]+=k;
}
int query(long long x){
	for(sum=0;x>=1;x-=lowbit(x))sum+=c[x];
	return sum;
}
int main(){
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)scanf("%lld",a+i);
	while(m--){
		scanf("%lld",&op);
		if(op==1){
			scanf("%lld%lld%lld",&x,&y,&k);
			add(x,k);
			add(y+1,-k);
		}
		else{
			scanf("%lld",&x);
			printf("%lld\n",a[x]+query(x));
		}
	}
}