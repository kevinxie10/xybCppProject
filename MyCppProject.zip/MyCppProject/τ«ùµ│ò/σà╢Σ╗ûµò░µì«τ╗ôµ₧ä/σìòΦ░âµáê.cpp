#include <cstdio>
#include <stack>
using namespace std;
stack<int>s;
int n,x;
int main(){
	scanf("%d",&n),s.push(-1);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		while(x<=s.top())s.pop();
		printf("%d ",s.top());
		s.push(x);
	}
	return 0;
}