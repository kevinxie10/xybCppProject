#include<cstdio> 
int z,x,y,fa[200100],n,m;
inline int find(int x){
    if(fa[x]==x)return x;
    else return fa[x]=find(fa[x]);
}
inline void merge(int x,int y){
    fa[find(x)]=find(y);
    return; 
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&z,&x,&y);
        if(z==1)merge(x,y);
        else{
            if(find(x)==find(y))printf("Y\n");
            else printf("N\n");
        }
    }
    return 0;
}