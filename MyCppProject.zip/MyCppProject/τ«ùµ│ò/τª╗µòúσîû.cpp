#include <iostream>
#include <algorithm>
using namespace std;
int n,a[1000010],b[1000010];
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",a+i),b[i]=a[i];
    sort(b+1,b+1+n);
    //法一：
    int w=unique(b+1,b+1+n)-b-1;
    for(int i=1;i<=n;i++)
        a[i]=lower_bound(b,b+1+n,a[i])-b+1;
}